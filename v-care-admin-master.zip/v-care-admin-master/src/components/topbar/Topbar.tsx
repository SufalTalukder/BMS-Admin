import { useRef, useState } from "react";
import { Avatar } from "primereact/avatar";
import { Menu } from "primereact/menu";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import type { Menu as MenuType } from "primereact/menu";
import { useGlobalStore } from "../../store";
import { useNavigate } from "react-router-dom";

const Topbar = () => {
  const { adminDetails, resetAllData, headerName } = useGlobalStore();
  const navigate = useNavigate();

  const menuRef = useRef<MenuType | null>(null);

  const userName = adminDetails?.name || "User";
  const userImage = adminDetails?.image || "/images/doctor1.webp";

  const handleLogoutConfirm = () => {
    confirmDialog({
      message: "Are you sure you want to logout?",
      header: "Logout Confirmation",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      accept: () => {
        resetAllData();
        navigate("/login");
      },
      reject: () => {
        // nothing happens
      },
    });
  };

  const menuItems = [
    {
      label: "Profile",
      icon: "pi pi-user",
      command: () => navigate("/profile"),
    },
    {
      label: "Logout",
      icon: "pi pi-sign-out",
      command: handleLogoutConfirm,
    },
  ];

  return (
    <div className="flex justify-between items-center bg-white shadow-sm p-3 border-b">
      <h1 className="text-xl font-semibold text-gray-800">{headerName}</h1>

      <div className="flex items-center gap-3">
        <span className="hidden sm:inline text-gray-700 font-medium">
          {userName}
        </span>

        <Menu model={menuItems} popup ref={menuRef} className="shadow-lg" />

        <div
          className="cursor-pointer"
          onClick={(event) => menuRef.current?.toggle(event)}
        >
          <Avatar
            image={userImage}
            label={!userImage ? userName[0] : undefined}
            shape="circle"
            size="large"
            className="bg-blue-500 text-white border border-gray-300 hover:ring-2 hover:ring-blue-400 transition-all duration-150"
          />
        </div>
      </div>

      <ConfirmDialog />
    </div>
  );
};

export default Topbar;
