// src/components/SidebarMenu.tsx
import { Sidebar } from "primereact/sidebar";
import { NavLink } from "react-router-dom";
import { Button } from "primereact/button";
import { classNames } from "primereact/utils";
import { Image } from "primereact/image";
import { Toast } from "primereact/toast";
import { useRef } from "react";
import { useGlobalStore } from "../store";
import { useNavigate } from "react-router-dom";

interface SidebarMenuProps {
  visible: boolean;
  onHide: () => void;
}

export default function SidebarMenu({ visible, onHide }: SidebarMenuProps) {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();

  const { resetAllData } = useGlobalStore();
  const sidebarButtons = [
    { label: "Dashboard", path: "/dashboard", icon: "pi pi-home" },
    { label: "Health Data", path: "/health-data", icon: "pi pi-heart" },
    { label: "Appointments", path: "/all-appointment", icon: "pi pi-calendar" },
    { label: "Messages", path: "/messages", icon: "pi pi-comments" },
    { label: "Profile", path: "/profile-details", icon: "pi pi-user" },
    { label: "Logout", icon: "pi pi-sign-out", path: "/login" },
  ];

  const headerTemplate = (
    <div className="flex justify-between items-center p-5 border-b border-gray-200">
      <div className="max-w-[100px] min-w-[100px]">
        <Image src="/images/logo.webp" alt="" />
      </div>
      <Button
        icon="pi pi-times"
        className="btnico !w-auto !text-black"
        onClick={onHide}
      />
    </div>
  );

  const handleSidebarButtonClick = (label: string, e: React.MouseEvent) => {
    if (label === "Health Data" || label === "Messages") {
      e.preventDefault();
      toast.current?.show({
        severity: "info",
        summary: "Info",
        detail: "Coming soon",
        life: 3000,
      });
      return;
    }

    if (label.toLowerCase() === "logout") {
      e.preventDefault();
      resetAllData();
      navigate("/login");
    }

    onHide();
  };

  return (
    <Sidebar
      visible={visible}
      onHide={onHide}
      position="left"
      className="p-0 w-64 sideBarMenu"
      showCloseIcon={false}
      header={headerTemplate}
    >
      <div className="flex flex-col gap-1 pt-2">
        {sidebarButtons.map((btn, index) => (
          <NavLink
            key={index}
            to={btn.path}
            // onClick={onHide}
            onClick={(e) => handleSidebarButtonClick(btn.label, e)}
            className={({ isActive }) =>
              classNames(
                "flex items-center gap-3 p-3 rounded-lg transition-all duration-200",
                {
                  "bg-blue-50 text-black": isActive,
                  "": !isActive,
                }
              )
            }
          >
            <i className={`${btn.icon} text-lg`}></i>
            <span className="text-sm font-medium">{btn.label}</span>
          </NavLink>
        ))}
      </div>
      <Toast ref={toast} />
    </Sidebar>
  );
}
