import React, { useEffect, useRef, useState } from "react";
import { Sidebar } from "primereact/sidebar";
import { Toast } from "primereact/toast";
import { DashboardService } from "../../service/Dashboard/DashboardService";
import type { DoctorFullDetailsData } from "../../service/Dashboard/dto";
import { ProgressSpinner } from "primereact/progressspinner";
import { Image } from "primereact/image";
import { Tag } from "primereact/tag";
import { Card } from "primereact/card";
import { ToggleButton } from "primereact/togglebutton";
import { InputSwitch } from "primereact/inputswitch";

type DashboardDoctorDetailsViewProps = {
  visible: boolean;
  uid: string | null;
  onClose: (state: boolean) => void;
};

const DashboardDoctorDetailsView: React.FC<DashboardDoctorDetailsViewProps> = ({
  visible,
  uid,
  onClose,
}) => {
  const toast = useRef<Toast | null>(null);
  const [doctorDetails, setDoctorDetails] =
    useState<DoctorFullDetailsData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const customHeader = (
    <div className="flex items-center gap-2">
      <div className="font-bold text-black text-xl">Doctor Details</div>
    </div>
  );

  useEffect(() => {
    if (visible && uid) {
      fetchDoctorDetails(uid);
    }
  }, [visible, uid]);

  const fetchDoctorDetails = async (doctorUid: string) => {
    try {
      setDoctorDetails(null);

      setLoading(true);
      const res = await DashboardService.getDoctorDetails(doctorUid);
      if (res.status === 200 && res.data) {
        setDoctorDetails(res.data);
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Not Found",
          detail: "Doctor details not found.",
          life: 3000,
        });
      }
    } catch (err) {
      console.error("Failed to load doctor:", err);
      toast.current?.show({
        severity: "error",
        summary: "Server Error",
        detail: "Failed to load doctor details",
        life: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const getSpecialties = () => {
    if (doctorDetails?.doctor_details.specialities?.length) {
      return doctorDetails.doctor_details.specialities
        .map((s) => s.name)
        .join(", ");
    }
    return "N/A";
  };

  const getExperience = () => {
    if (doctorDetails?.doctor_details.experience?.length) {
      return doctorDetails.doctor_details.experience
        .map((exp) => `${exp.years_of_experience} in ${exp.specialitie_name}`)
        .join(", ");
    }
    return "N/A";
  };

  const handleKycVerificationToggle = async (
    docUid: string,
    newValue: boolean,
    index: number
  ) => {
    if (!doctorDetails) return;

    const is_verified = newValue ? 1 : 0;

    try {
      const updatedDocs = [...doctorDetails.doctor_details.kyc_documents];
      updatedDocs[index] = {
        ...updatedDocs[index],
        is_verified: is_verified.toString(),
      };

      setDoctorDetails({
        ...doctorDetails,
        doctor_details: {
          ...doctorDetails.doctor_details,
          kyc_documents: updatedDocs,
        },
      });

      const res = await DashboardService.verifyDoctorKycDocument({
        kyc_document_uid: docUid,
        is_verified,
      });

      toast.current?.show({
        severity: res.success ? "success" : "warn",
        summary: res.success ? "Updated" : "Failed",
        detail: res.message,
        life: 2000,
      });

      // setTimeout(() => {
      // fetchDoctorDetails(uid!);
      // }, 2000);
    } catch (err) {
      console.error("Error verifying KYC:", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to update document status",
        life: 3000,
      });
    }
  };

  const handleQualificationVerificationToggle = async (
    docUid: string,
    newValue: boolean,
    index: number
  ) => {
    if (!doctorDetails) return;

    const is_verified = newValue ? 1 : 0;

    try {
      const updatedDocs = [
        ...doctorDetails.doctor_details.qualification_documents,
      ];
      updatedDocs[index] = {
        ...updatedDocs[index],
        is_verified: is_verified.toString(),
      };

      setDoctorDetails({
        ...doctorDetails,
        doctor_details: {
          ...doctorDetails.doctor_details,
          qualification_documents: updatedDocs,
        },
      });

      const res = await DashboardService.verifyDoctorQualificationDocument({
        qualification_document_uid: docUid,
        is_verified,
      });

      toast.current?.show({
        severity: res.success ? "success" : "warn",
        summary: res.success ? "Updated" : "Failed",
        detail: res.message,
        life: 2000,
      });

      // setTimeout(() => {
      // fetchDoctorDetails(uid!);
      // }, 2000);
    } catch (err) {
      console.error("Error verifying Qualification:", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to update Qualification document status",
        life: 3000,
      });
    }
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />
      <Sidebar
        header={customHeader}
        visible={visible}
        position="right"
        onHide={() => onClose(false)}
        style={{ width: "500px" }}
      >
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <ProgressSpinner />
          </div>
        ) : doctorDetails ? (
          <div className="flex flex-col gap-4 h-full overflow-y-auto p-2">
            {/* Doctor Basic Info */}
            <div className="flex flex-col items-center text-center border-b pb-3">
              <Image
                src={
                  doctorDetails.doctor_details.profile_pic ||
                  "/placeholder-avatar.png"
                }
                alt={doctorDetails.doctor_details.name}
                width="100"
                height="100"
                className="rounded-full mb-2"
                preview
              />
              <div className="font-semibold text-lg text-black">
                {doctorDetails.doctor_details.name || "N/A"}
              </div>
              <div className="text-gray-600 text-sm">
                Reg. No: {doctorDetails.doctor_details.registration || "N/A"}
              </div>
            </div>

            {/* Specialties */}
            <div>
              <div className="text-black font-medium">Specialties</div>
              <div className="text-gray-700">{getSpecialties()}</div>
            </div>

            {/* Experience */}
            <div>
              <div className="text-black font-medium">Experience</div>
              <div className="text-gray-700">{getExperience()}</div>
            </div>

            {/* Clinics Section */}
            <div>
              <div className="text-black font-medium mb-2">Clinics</div>

              {doctorDetails.clinic && doctorDetails.clinic.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {doctorDetails.clinic.map((clinic) => (
                    <Card
                      key={clinic.uid}
                      className="shadow-md border border-gray-200 rounded-md"
                      title={
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-black">
                            {clinic.name}
                          </span>
                          <Tag
                            value={clinic.status}
                            severity={
                              clinic.status === "active" ? "success" : "danger"
                            }
                          />
                        </div>
                      }
                    >
                      <div className="text-sm text-gray-700">
                        <div className="mb-2">
                          <span className="font-medium">Address: </span>
                          {clinic.address}
                        </div>

                        {/* Time Slots */}
                        {clinic.time_slots && clinic.time_slots.length > 0 && (
                          <div>
                            {clinic.time_slots.map((slot, index) => (
                              <div
                                key={index}
                                className="mb-2 p-2 bg-gray-50 rounded-md border border-gray-100"
                              >
                                <div>
                                  <span className="font-medium">Time:</span>{" "}
                                  {slot.start_time} - {slot.end_time}
                                </div>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {slot.days.map((day, i) => (
                                    <Tag
                                      key={i}
                                      value={day}
                                      className="text-xs"
                                      severity="info"
                                    />
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-gray-500 text-sm">
                  No clinics found for this doctor.
                </div>
              )}
            </div>

            {/* KYC Documents Section */}
            <div>
              <div className="text-black font-medium mb-2">KYC Documents</div>
              {doctorDetails.doctor_details.kyc_documents &&
              doctorDetails.doctor_details.kyc_documents.length > 0 ? (
                <div className="grid grid-cols-2 gap-3">
                  {doctorDetails.doctor_details.kyc_documents.map(
                    (doc, index) => (
                      <div
                        key={doc.uid}
                        className="border border-gray-200 rounded-lg p-3 shadow-sm flex flex-col items-center bg-white"
                      >
                        {/* Document Image */}
                        {/* <Image
                          src={doc.kyc_document_file}
                          alt={doc.type}
                          width="120"
                          height="120"
                          className="rounded-md object-cover"
                          preview
                        /> */}

                        <div className="w-[120px] h-[120px] overflow-hidden rounded-md">
                          <Image
                            src={doc.kyc_document_file}
                            alt={doc.type}
                            width="120"
                            height="120"
                            className="w-full h-full object-cover"
                            preview
                          />
                        </div>

                        {/* Document Info */}
                        <div className="mt-2 text-center text-sm">
                          <div className="font-medium text-gray-800">
                            {doc.type}
                          </div>
                          <div className="text-gray-500 text-xs">
                            {doc.variation}
                          </div>
                        </div>

                        {/* Verification Toggle */}
                        <div className="flex items-center gap-2 mt-2">
                          {/* <InputSwitch
                            checked={doc.is_verified === "1"}
                            disabled
                            className={
                              doc.is_verified === "1"
                                ? "!rounded-full  bg-green-500"
                                : "!rounded-full  bg-gray-300"
                            }
                          /> */}
                          <InputSwitch
                            checked={doc.is_verified === "1"}
                            onChange={(e) =>
                              handleKycVerificationToggle(
                                doc.uid,
                                e.value,
                                index
                              )
                            }
                            className={
                              doc.is_verified === "1"
                                ? "!rounded-full  bg-green-500"
                                : "!rounded-full  bg-gray-300"
                            }
                          />
                          <span
                            className={`text-xs font-medium ${
                              doc.is_verified === "1"
                                ? "text-green-600"
                                : "text-gray-500"
                            }`}
                          >
                            {doc.is_verified === "1"
                              ? "Verified"
                              : "Not Verified"}
                          </span>
                        </div>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div className="text-gray-500 text-sm">
                  No KYC documents uploaded.
                </div>
              )}
            </div>

            {/* Qualification Documents Section */}
            <div>
              <div className="text-black font-medium mb-2 mt-4">
                Qualification Documents
              </div>
              {doctorDetails.doctor_details.qualification_documents &&
              doctorDetails.doctor_details.qualification_documents.length >
                0 ? (
                <div className="grid grid-cols-2 gap-3">
                  {doctorDetails.doctor_details.qualification_documents.map(
                    (doc, index) => (
                      <div
                        key={doc.uid}
                        className="border border-gray-200 rounded-lg p-3 shadow-sm flex flex-col items-center bg-white"
                      >
                        {/* Document Image */}
                        {/* <Image
                          src={doc.doctor_qualification_document}
                          alt={doc.type || "Document"}
                          width="120"
                          height="120"
                          className="rounded-md object-cover"
                          preview
                        /> */}

                        <div className="w-[120px] h-[120px] overflow-hidden rounded-md">
                          <Image
                            src={doc.doctor_qualification_document}
                            alt={doc.type || "Document"}
                            width="120"
                            height="120"
                            className="w-full h-full object-cover"
                            preview
                          />
                        </div>
                        {/* Document Info */}
                        <div className="mt-2 text-center text-sm">
                          <div className="font-medium text-gray-800">
                            {doc.type || "N/A"}
                          </div>
                          <div className="text-gray-500 text-xs">
                            {doc.variation}
                          </div>
                        </div>

                        {/* Verification Toggle */}
                        <div className="flex items-center gap-2 mt-2">
                          {/* <InputSwitch
                            checked={doc.is_verified === "1"}
                            disabled
                            className={
                              doc.is_verified === "1"
                                ? "!rounded-full  bg-green-500"
                                : "!rounded-full  bg-gray-300"
                            }
                          /> */}

                          <InputSwitch
                            checked={doc.is_verified === "1"}
                            onChange={(e) =>
                              handleQualificationVerificationToggle(
                                doc.uid,
                                e.value,
                                index
                              )
                            }
                            className={
                              doc.is_verified === "1"
                                ? "!rounded-full  bg-green-500"
                                : "!rounded-full  bg-gray-300"
                            }
                          />
                          <span
                            className={`text-xs font-medium ${
                              doc.is_verified === "1"
                                ? "text-green-600"
                                : "text-gray-500"
                            }`}
                          >
                            {doc.is_verified === "1"
                              ? "Verified"
                              : "Not Verified"}
                          </span>
                        </div>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div className="text-gray-500 text-sm">
                  No qualification documents uploaded.
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500 mt-10">
            No doctor details found.
          </div>
        )}
      </Sidebar>
    </>
  );
};

export default DashboardDoctorDetailsView;
