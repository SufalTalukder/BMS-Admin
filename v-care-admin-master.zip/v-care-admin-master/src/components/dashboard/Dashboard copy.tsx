import { useState } from "react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);

  // Toggle Sidebar Visibility
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div
        className={`${
          isSidebarOpen ? "w-64" : "w-20"
        } bg-[#0D52AF] text-white transition-all duration-300`}
      >
        <div className="p-4 flex items-center justify-between">
          <div className="text-xl font-bold">Dashboard</div>
          {/* Toggle Sidebar Button */}
          <button onClick={toggleSidebar} className="text-white">
            {isSidebarOpen ? (
              <span>Close</span>
            ) : (
              <svg
                className="h-6 w-6"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            )}
          </button>
        </div>
        {/* Sidebar Links */}
        <div className="mt-8">
          <ul>
            <li>
              <Link to="/" className="block p-4 text-white hover:bg-[#084F87]">
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                to="/profile"
                className="block p-4 text-white hover:bg-[#084F87]"
              >
                Profile
              </Link>
            </li>
            <li>
              <Link
                to="/settings"
                className="block p-4 text-white hover:bg-[#084F87]"
              >
                Settings
              </Link>
            </li>
            <li>
              <Link
                to="/logout"
                className="block p-4 text-white hover:bg-[#084F87]"
              >
                Logout
              </Link>
            </li>
          </ul>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation Bar */}
        <div className="flex justify-between items-center bg-white shadow-lg p-4">
          {/* Hamburger Menu (Mobile/Tablet) */}
          <button onClick={toggleSidebar} className="md:hidden text-xl">
            <svg
              className="h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>

          {/* App Title */}
          <div className="text-2xl font-bold text-[#0D52AF]">My Health</div>

          {/* Profile and Notifications */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <button>
                <svg
                  className="h-6 w-6 text-[#0D52AF]"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 22c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm0 0v-4m0 0v-4m0 4l4-4m-4 4l-4-4"
                  />
                </svg>
              </button>
            </div>
            <div className="w-10 h-10 rounded-full overflow-hidden">
              <img
                src="https://www.gravatar.com/avatar/your-gravatar-hash"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="flex-1 p-6 bg-gray-100">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Dashboard Overview</h1>
            <div className="text-gray-600">Welcome, User!</div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Total Users</h3>
              <div className="text-3xl font-bold text-[#0D52AF]">1,245</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Active Sessions</h3>
              <div className="text-3xl font-bold text-[#0D52AF]">32</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Revenue</h3>
              <div className="text-3xl font-bold text-[#0D52AF]">$4,320</div>
            </div>
          </div>

          {/* Recent Activities */}
          <div className="mt-8 bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold mb-4">Recent Activities</h3>
            <div className="text-sm text-gray-600">
              <ul>
                <li>User John Doe logged in</li>
                <li>New revenue generated: $1,200</li>
                <li>Session ended for User #124</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
