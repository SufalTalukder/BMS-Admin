import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { useEffect, useRef, useState, type RefObject } from "react";
import { DashboardService } from "../../service/Dashboard/DashboardService";
import type {
  AdminDashboardStats,
  DoctorListData,
} from "../../service/Dashboard/dto";
import { Avatar } from "primereact/avatar";
import { DataTable, type DataTableSortMeta } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputSwitch } from "primereact/inputswitch";
import { Toast } from "primereact/toast";
import { Paginator, type PaginatorPageChangeEvent } from "primereact/paginator";
import { getRowsPerPageOptions } from "../../utils/paginationUtils";
import { InputText } from "primereact/inputtext";
import { Menu } from "primereact/menu";
import React from "react";
import DashboardDoctorDetailsView from "./DashboardDoctorDetailsView";
import { ProgressSpinner } from "primereact/progressspinner";
import { useGlobalStore } from "../../store";
import { convertUTCToTimeZone } from "../../utils/dateFormatter";

type TemplateOptions = {
  rowIndex: number;
};
type MenuRef = RefObject<Menu | null>;

const Dashboard = () => {
  const actionMenuRefs = useRef<MenuRef[]>([]);

  const toast = useRef<Toast | null>(null);
  const [firstRowIndex, setFirstRowIndex] = useState<number>(0);
  const [selectedPageSize, setSelectedPageSize] = useState<number>(50);
  const [loading, setLoading] = useState(false);
  const [globalFilter, setGlobalFilter] = useState<string>("");

  const [doctorsData, setDoctorsData] = useState<DoctorListData[]>([]);
  const [doctorsDataCount, setDoctorsDataCount] = useState<number>(0);
  const [multiSortMeta, setMultiSortMeta] = useState<
    DataTableSortMeta[] | undefined
  >([]);

  const [selectedDoctorData, setSelectedDoctorData] =
    useState<DoctorListData | null>(null);

  const [viewVisible, setViewVisible] = useState(false);
  const [selectedDocUid, setSelectedDocUid] = useState<string | null>(null);

  const [dashboardStats, setDashboardStats] =
    useState<AdminDashboardStats | null>(null);
  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  const { setHeaderName } = useGlobalStore();

  useEffect(() => {
    setHeaderName("Dashboard");
  }, []);

  /////// effects //////////////
  const fetchDoctorListData = async () => {
    try {
      setLoading(true);
      const response = await DashboardService.getDoctorList(
        selectedPageSize,
        Math.floor(firstRowIndex / selectedPageSize) + 1,
        globalFilter.trim() ? globalFilter : undefined
      );

      if (response.status === 200) {
        setDoctorsData(response.data);
        setDoctorsDataCount(response.count || 0);
      } else {
        setDoctorsData([]);
        setDoctorsDataCount(0);
      }
    } catch (error) {
      console.error("Error in fetching doctor list data:", error);
      setDoctorsData([]);
      setDoctorsDataCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      // Only trigger search if at least 2 characters or filter is cleared
      if (globalFilter.trim().length >= 2 || globalFilter.trim().length === 0) {
        fetchDoctorListData();
      }
    }, 500); // wait 500ms after typing stops

    // Cleanup if user keeps typing fast
    return () => clearTimeout(handler);
  }, [firstRowIndex, selectedPageSize, globalFilter]);

  // useEffect(() => {
  //   fetchDoctorListData();
  // }, [firstRowIndex, selectedPageSize, globalFilter]);

  const fetchDashboardStats = async () => {
    try {
      setStatsLoading(true);
      const response = await DashboardService.getAdminDashboardStatsDetails();

      if (response.status === 200 && response.data) {
        setDashboardStats(response.data);
      } else {
        setDashboardStats(null);
        toast.current?.show({
          severity: "warn",
          summary: "Warning",
          detail: response.message || "Failed to fetch dashboard stats",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch dashboard stats",
        life: 3000,
      });
    } finally {
      setStatsLoading(false);
    }
  };
  useEffect(() => {
    fetchDashboardStats();
  }, []);

  ///// change event //////
  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setFirstRowIndex(event.first);
    setSelectedPageSize(event.rows);
  };

  const onSelectionChange = (e: { value: DoctorListData }) => {
    setSelectedDoctorData(e.value);
  };

  ////////// templates
  const doctorTemplate = (doctor: DoctorListData) => {
    return (
      <div className="flex items-center gap-3">
        <Avatar
          image={doctor.profile_pic || undefined}
          label={!doctor.profile_pic ? doctor.name[0] : undefined}
          shape="circle"
          className="w-10 h-10 text-white bg-blue-500"
        />
        <span className="font-semibold">{doctor.name}</span>
      </div>
    );
  };

  const registerDateTemplate = (doctor: DoctorListData) => {
    const formattedDate = convertUTCToTimeZone(
      doctor.created_at,
      doctor.time_zone
    );
    return <>{formattedDate}</>;
  };

  const statusTemplate = (doctor: DoctorListData) => {
    return (
      <span
        className={`text-xs font-medium px-2 py-1 rounded-full ${
          doctor.status === "active"
            ? "bg-green-100 text-green-800"
            : "bg-gray-100 text-gray-600"
        }`}
      >
        {doctor.status?.toUpperCase() || "N/A"}
      </span>
    );
  };

  const updateDoctorStatus = async (
    doctorUid: string,
    newStatus: string,
    originalStatus: string
  ) => {
    try {
      const response = await DashboardService.updateDoctorStatus({
        doctor_uid: doctorUid,
        status: newStatus,
      });

      if (response.success) {
        toast.current?.show({
          severity: "success",
          summary: "Success",
          detail: `Doctor ${
            newStatus === "active" ? "Activated" : "Deactivated"
          }`,
          life: 2000,
        });
        setTimeout(() => {
          fetchDoctorListData();
        }, 2000);
      } else {
        setDoctorsData((prev) =>
          prev.map((d) =>
            d.uid === doctorUid ? { ...d, status: originalStatus } : d
          )
        );
        toast.current?.show({
          severity: "error",
          summary: "Error",
          detail: response.message || "Failed to update doctor status",
          life: 3000,
        });
      }
    } catch (error) {
      setDoctorsData((prev) =>
        prev.map((d) =>
          d.uid === doctorUid ? { ...d, status: originalStatus } : d
        )
      );
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to update doctor status",
        life: 3000,
      });
    }
  };

  const actionTemplate = (
    rowData: DoctorListData,
    options: TemplateOptions
  ) => {
    const index = options.rowIndex;
    if (!actionMenuRefs.current[index]) {
      actionMenuRefs.current[index] = React.createRef();
    }

    const menuModel = [
      {
        label: "View",
        icon: "pi pi-eye",
        command: () => handleViewClick(rowData.uid),
      },
      // {
      //   label: "Delete",
      //   icon: "pi pi-trash",
      //   command: () => console.log("Delete clicked for ID:", rowData.uid),
      // },
    ];

    return (
      <>
        <Menu model={menuModel} popup ref={actionMenuRefs.current[index]} />
        <Button
          icon="pi pi-ellipsis-v"
          rounded
          text
          size="small"
          className="btnico text-black"
          onClick={(e) => actionMenuRefs.current[index]?.current?.toggle(e)}
          aria-haspopup
          aria-controls="popup_menu"
        />
      </>
    );
  };

  const statusToggleTemplate = (doctor: DoctorListData) => {
    const normalizedStatus = doctor.status?.toLowerCase() || "inactive"; // normalize

    const handleToggle = (value: boolean) => {
      const newStatus = value ? "active" : "inactive";
      const originalStatus = normalizedStatus;

      setDoctorsData((prev) =>
        prev.map((d) =>
          d.uid === doctor.uid ? { ...d, status: newStatus } : d
        )
      );

      updateDoctorStatus(doctor.uid, newStatus, originalStatus);
    };

    return (
      <div className="flex items-center gap-2">
        <InputSwitch
          checked={normalizedStatus === "active"}
          onChange={(e) => handleToggle(e.value)}
        />
        {/* <span
          className={`text-xs font-medium px-2 py-1 rounded-full ${
            normalizedStatus === "active"
              ? "bg-green-100 text-green-800"
              : "bg-gray-100 text-gray-600"
          }`}
        >
          {normalizedStatus.toUpperCase()}
        </span> */}
      </div>
    );
  };

  ///// handlers ///////
  const handleViewClick = (uid: string) => {
    setSelectedDocUid(uid);
    setViewVisible(true);
  };
  const handleViewClose = (state: boolean) => {
    setViewVisible(state);
    setSelectedDocUid(null);
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-semibold text-gray-800">
            Dashboard Overview
          </h2>
          {/* <Button
          icon="pi pi-refresh"
          label="Refresh"
          className="p-button-sm p-button-outlined"
        /> */}
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card title="Doctors" className="shadow-md">
            {statsLoading ? (
              <ProgressSpinner className="w-6 h-6" />
            ) : (
              <>
                <p className="text-3xl font-bold text-blue-600">
                  {dashboardStats?.total_doctors ?? 0}
                </p>
                <p className="text-gray-500 text-sm">
                  Total Registered Doctors
                </p>
              </>
            )}
          </Card>

          <Card title="Appointments" className="shadow-md">
            {statsLoading ? (
              <ProgressSpinner className="w-6 h-6" />
            ) : (
              <>
                <p className="text-3xl font-bold text-green-600">
                  {dashboardStats?.total_appointments ?? 0}
                </p>
                <p className="text-gray-500 text-sm">Total Appointments</p>
              </>
            )}
          </Card>

          <Card title="Clinics" className="shadow-md">
            {statsLoading ? (
              <ProgressSpinner className="w-6 h-6" />
            ) : (
              <>
                <p className="text-3xl font-bold text-pink-600">
                  {dashboardStats?.total_clinics ?? 0}
                </p>
                <p className="text-gray-500 text-sm">Total Clinics</p>
              </>
            )}
          </Card>

          <Card title="prescriptions" className="shadow-md">
            {statsLoading ? (
              <ProgressSpinner className="w-6 h-6" />
            ) : (
              <>
                <p className="text-3xl font-bold text-yellow-600">
                  {dashboardStats?.total_prescription ?? 0}
                </p>
                <p className="text-gray-500 text-sm">Total Prescription</p>
              </>
            )}
          </Card>
          {/* <Card title="Revenue" className="shadow-md">
            {statsLoading ? (
              <ProgressSpinner className="w-6 h-6" />
            ) : (
              <>
                <p className="text-3xl font-bold text-yellow-600">
                  {dashboardStats?.total_earnings ?? 0}
                </p>
                <p className="text-gray-500 text-sm">Total Earnings</p>
              </>
            )}
          </Card> */}
        </div>
        {/* DataTable Section */}
        <Card title="All Doctors" className="shadow-md">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3">
              {/* <label className="text-gray-600 ">Search</label> */}
              <InputText
                value={globalFilter}
                onChange={(e) => setGlobalFilter(e.target.value)}
                placeholder="Search by name or email or mobile"
                className="w-full"
              />
            </div>
            {/* <div className="p-4">
              <InputText
                value={globalFilter}
                onChange={(e) => setGlobalFilter(e.target.value)}
                placeholder="Search by name or email"
                className="w-full"
              />
            </div> */}
          </div>

          <DataTable
            value={doctorsData || []}
            selection={selectedDoctorData!}
            onSelectionChange={onSelectionChange}
            selectionMode="single"
            dataKey="uid"
            // rows={10}
            globalFilter={globalFilter}
            sortMode="multiple"
            scrollable
            // scrollHeight="400px"
            // scrollHeight="calc(100vh - 230px)"
            className="text-sm w-full "
            loading={loading!}
            multiSortMeta={multiSortMeta}
            onSort={(e) => {
              if (e.multiSortMeta !== null && e.multiSortMeta !== undefined) {
                setMultiSortMeta(e.multiSortMeta);
              }
              console.log(" multiSortMeta ===> ", multiSortMeta);
              console.log("dataTable sort data");
            }}
          >
            <Column field="id" header="#" sortable />
            <Column field="name" header="Doctor" body={doctorTemplate} />
            <Column field="email" header="Email" sortable />
            <Column field="dob" header="DOB" sortable />
            <Column field="mobile" header="Mobile" sortable />
            <Column field="gender" header="Gender" sortable />
            <Column
              field="prescription_count"
              header="E-Prescription"
              sortable
            />
            <Column
              field="created_at"
              header="Registration Date"
              body={registerDateTemplate}
              sortable
            />
            <Column
              field="status"
              header="Status"
              body={statusToggleTemplate}
              sortable
            />
            <Column
              header="Actions"
              body={actionTemplate}
              style={{ width: "80px" }}
            />
          </DataTable>
          <div className="card">
            <Paginator
              first={firstRowIndex}
              rows={selectedPageSize}
              totalRecords={doctorsDataCount || 0}
              onPageChange={onPageChange}
              rowsPerPageOptions={getRowsPerPageOptions(doctorsDataCount || 0)}
            />
          </div>
        </Card>
      </div>

      <DashboardDoctorDetailsView
        visible={viewVisible}
        onClose={handleViewClose}
        uid={selectedDocUid}
      />
    </>
  );
};

export default Dashboard;
