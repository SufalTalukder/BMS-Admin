import { Sidebar as PrimeSidebar } from "primereact/sidebar";
import { Button } from "primereact/button";
import { useState } from "react";
import { Home, Settings, LogOut, UserCog } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { useGlobalStore } from "../../store";
import { confirmDialog, ConfirmDialog } from "primereact/confirmdialog";
import { Stethoscope } from "lucide-react";

interface SidebarProps {
  isSidebarExpanded: boolean;
  setIsSidebarExpanded: (value: boolean) => void;
}

const Sidebar = ({ isSidebarExpanded, setIsSidebarExpanded }: SidebarProps) => {
  const navigate = useNavigate();

  const [visible, setVisible] = useState(false);
  const location = useLocation(); // get current path

  const { resetAllData } = useGlobalStore();

  const handleLogoutConfirm = () => {
    confirmDialog({
      message: "Are you sure you want to logout?",
      header: "Logout Confirmation",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      accept: () => {
        resetAllData();
        navigate("/login");
      },
      reject: () => {
        // nothing happens
      },
    });
  };

  const menuItems = [
    {
      label: "Dashboard",
      icon: <i className="pi pi-home text-lg" />,
      path: "/",
    },
    // {
    //   label: "Settings",
    //   icon: <i className="pi pi-cog text-lg" />,
    //   path: "/settings",
    // },
    {
      label: "Clinic",
      // icon: <i className="pi pi-plus-circle text-lg text-blue-500" />,
      icon: (
        <img
          src="/images/clinic-icon.png"
          alt="Clinic"
          className="w-5 h-5 object-contain shrink-0"
        />
      ),
      path: "/clinic",
    },
    // {
    //   label: "Clinic",
    //   icon: <Stethoscope className="w-5 h-5 text-blue-500" />,
    //   path: "/clinic",
    // },
    // {
    //   label: "Doctor",
    //   icon: <UserCog className="w-5 h-5 text-green-500" />,
    //   path: "/doctor",
    // },
    {
      label: "Profile Details",
      icon: <i className="pi pi-user text-lg" />,
      path: "/profile",
    },
    // {
    //   label: "Feedback",
    //   icon: <i className="pi pi-comment text-lg text-black-500" />,
    //   path: "/feedback",
    // },
    // {
    //   label: "Support",
    //   icon: <i className="pi pi-comment text-xl text-black-500" />,
    //   path: "/support",
    // },
    {
      label: "Feedback",
      icon: (
        <img
          src="/images/feedback.png"
          alt="Feedback"
          className="w-5 h-5 object-contain shrink-0"
        />
      ),
      path: "/feedback",
    },
    {
      label: "Support",
      icon: (
        <img
          src="/images/support.png"
          alt="Support"
          className="w-5 h-5 object-contain shrink-0"
        />
      ),
      path: "/support",
    },
    {
      label: "Plan",
      icon: (
        <img
          src="/images/plan-icon.png"
          alt="Plan"
          className="w-5 h-5 object-contain shrink-0"
        />
      ),
      path: "/plan",
    },
    {
      label: "Logout",
      icon: <i className="pi pi-sign-out text-lg text-black-500" />,
      path: "/logout",
    },
  ];

  return (
    <>
      {/* Hamburger Button for Mobile */}
      <div className="fixed top-4 left-4 z-50 md:hidden">
        <Button
          icon="pi pi-bars"
          className="p-button-rounded p-button-text"
          onClick={() => setVisible(true)}
        />
      </div>

      {/* PrimeReact Sidebar (Mobile) */}
      <PrimeSidebar
        visible={visible}
        onHide={() => setVisible(false)}
        className="p-sidebar-sm md:hidden"
      >
        <div className="flex flex-col gap-3 text-gray-700">
          {menuItems.map((item) => (
            <a
              key={item.label}
              href={item.path}
              className="flex items-center gap-2"
            >
              {item.icon} {item.label}
            </a>
          ))}
        </div>
      </PrimeSidebar>

      {/* Desktop Sidebar */}
      <div
        className={`hidden md:flex flex-col fixed left-0 top-0 h-full bg-white shadow-md transition-all duration-300 ${
          isSidebarExpanded ? "w-64" : "w-20"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b">
          {/* Logo Section */}
          <div className="flex items-center gap-2">
            <span
              className={`font-bold text-lg ${
                !isSidebarExpanded ? "hidden" : ""
              }`}
            >
              Logo
            </span>
          </div>
          <Button
            icon={isSidebarExpanded ? "pi pi-angle-left" : "pi pi-bars"}
            className="p-button-text p-button-sm"
            onClick={() => setIsSidebarExpanded(!isSidebarExpanded)}
          />
        </div>

        <nav className="flex flex-col gap-2 p-4">
          {/* {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <a
                key={item.label}
                href={item.path}
                className={`flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 ${
                  isActive
                    ? "bg-blue-100 text-blue-700 font-semibold"
                    : "text-gray-700"
                }`}
              >
                {item.icon}
                {isSidebarExpanded && <span>{item.label}</span>}
              </a>
            );
          })} */}

          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;

            if (item.label === "Logout") {
              console.log("item.label ===> ", item.label);
              return (
                <button
                  key={item.label}
                  onClick={handleLogoutConfirm}
                  className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 text-gray-700 w-full text-left"
                >
                  {item.icon}
                  {isSidebarExpanded && <span>{item.label}</span>}
                </button>
              );
            }

            return (
              <a
                key={item.label}
                href={item.path}
                className={`flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 ${
                  isActive
                    ? "bg-blue-100 text-blue-700 font-semibold"
                    : "text-gray-700"
                }`}
              >
                {item.icon}
                {isSidebarExpanded && <span>{item.label}</span>}
              </a>
            );
          })}
        </nav>
      </div>

      {/* <ConfirmDialog /> */}
    </>
  );
};

export default Sidebar;
