// components/login/Login.tsx
import { useState, useRef } from "react";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { Toast } from "primereact/toast";
import { useNavigate } from "react-router-dom";
import { useGlobalStore } from "../../store";
import { LoginService } from "../../service/Login/LoginService";

interface LoginProps {
  onHide: () => void;
  onContinue?: () => void;
}

export default function Login({ onHide, onContinue }: LoginProps) {
  const navigate = useNavigate();
  const { setIsLoggedIn, setAdminDetails } = useGlobalStore();
  const frontend_type = "browser";
  const device_type = "web";
  const [email, setEmail] = useState<string>(""); // State for email
  const [password, setPassword] = useState<string>(""); // State for password
  const [showPassword, setShowPassword] = useState<boolean>(false); // State for toggling password visibility
  const [showOtp, setShowOtp] = useState<boolean>(false);
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]);
  const demoOtp = "123456";
  const [resendTimer, setResendTimer] = useState<number>(30);
  const [canResend, setCanResend] = useState<boolean>(false);

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const toast = useRef<Toast | null>(null);

  const handleContinue = async () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.current?.show({
        severity: "error",
        summary: "Invalid Email",
        detail: "Please enter a valid email address",
      });
      return;
    }

    if (password.length < 6) {
      toast.current?.show({
        severity: "error",
        summary: "Invalid Password",
        detail: "Password must be at least 6 characters long",
      });
      return;
    }

    try {
      const res = await LoginService.login({
        email,
        password,
      });

      if (res.success && res.data) {
        setAdminDetails(res.data);
        console.log("sent otp ===> ", res);
        toast.current?.show({
          severity: "success",
          summary: "Login",
          detail: res.message || `Login Successfully`,
          life: 3000,
        });

        setIsLoggedIn(true);

        setShowOtp(true);
        setCanResend(false);

        setTimeout(() => {
          navigate("/");
        }, 3000);
      } else {
        setIsLoggedIn(false);
        toast.current?.show({
          severity: "error",
          summary: "Login Failed",
          detail: res.message || "Something went wrong. Please try again.",
        });
      }
    } catch (err) {
      console.error(err);
      toast.current?.show({
        severity: "error",
        summary: "Server Error",
        detail: "Failed to login. Please try again later.",
      });
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-[#f7faff]">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full sm:w-96">
        <Toast ref={toast} position="top-right" />
        <div className="text-center text-black font-bold text-3xl mb-6">
          Login
        </div>

        <div className="space-y-6">
          <div className="flex flex-col gap-4">
            {/* Email Input */}
            <div className="p-inputgroup border border-[#ccc] rounded-lg bg-white">
              <span className="p-inputgroup-addon border-0 rounded-l-lg bg-white">
                <i className="pi pi-envelope text-[#0D52AF]"></i>
              </span>
              <InputText
                type="email" // Change type to email
                placeholder="Enter email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="!shadow-none w-full border-0 rounded-r-lg py-3 pl-4 text-lg"
              />
            </div>

            {/* Password Input with Eye Icon */}
            <div className="p-inputgroup border border-[#ccc] rounded-lg bg-white">
              <span className="p-inputgroup-addon border-0 rounded-l-lg bg-white">
                <i className="pi pi-lock text-[#0D52AF]"></i>
              </span>
              <InputText
                type={showPassword ? "text" : "password"}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="!shadow-none w-full border-0 rounded-r-lg py-3 pl-4 text-lg"
              />
              <span
                className="p-inputgroup-addon cursor-pointer border-0 rounded-r-lg bg-white"
                onClick={() => setShowPassword((prev) => !prev)}
              >
                <i
                  className={`pi ${showPassword ? "pi-eye-slash" : "pi-eye"}`}
                />
              </span>
            </div>

            {/* Continue Button */}
            <Button
              label="Continue"
              className="w-full !bg-[#0D52AF] text-white text-lg py-3 mt-4 rounded-lg hover:bg-[#084F87] transition duration-200"
              onClick={handleContinue}
            />
          </div>

          {/* <div className="text-center text-sm text-gray-500 mt-4">
            <p>
              Don't have an account?{" "}
              <a
                href="#"
                className="text-[#0D52AF] font-semibold hover:underline"
              >
                Sign up
              </a>
            </p>
          </div> */}
        </div>
      </div>
    </div>
  );
}
