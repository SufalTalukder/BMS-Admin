export const getRelativeDay = (
  dateStr: string | undefined,
  timeStr: string | undefined
): string => {
  if (!dateStr) return timeStr || "";

  // Parse date from string like "Thu, Oct 16"
  const parts = dateStr.split(", "); // ["Thu", "Oct 16"]
  if (!parts[1]) return timeStr || "";

  const parsedDate = new Date(parts[1] + " " + new Date().getFullYear());
  const today = new Date();

  // Reset hours/minutes for accurate day difference
  parsedDate.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  const diffTime = parsedDate.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

  let dayLabel = "";
  if (diffDays === 0) dayLabel = "Today";
  else if (diffDays === 1) dayLabel = "Tomorrow";
  else if (diffDays === -1) dayLabel = "Yesterday";
  else dayLabel = parsedDate.toLocaleDateString("en-US", { weekday: "long" }); // "Monday", "Tuesday", etc.

  return timeStr ? `${dayLabel} at ${timeStr}` : dayLabel;
};
