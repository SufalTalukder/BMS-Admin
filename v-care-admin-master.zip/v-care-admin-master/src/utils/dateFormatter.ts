export function formatDateString(dateStr: string, year?: number): string {
  if (!dateStr) return "";

  const currentYear = year ?? new Date().getFullYear();

  const date = new Date(`${dateStr}, ${currentYear}`);

  if (isNaN(date.getTime())) return "";

  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");

  return `${yyyy}-${mm}-${dd}`;
}

export function formatToShortMonthDay(dateStr: string): string {
  if (!dateStr) return "";

  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return "";

  const options: Intl.DateTimeFormatOptions = {
    month: "short",
    day: "numeric",
  };
  return date.toLocaleDateString("en-US", options);
}

export function formatDateToYYYYMMDD(
  date: Date | string | null | undefined
): string | undefined {
  if (!date) return undefined;

  if (typeof date === "string") return date;

  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0"); // months are 0-based
  const day = date.getDate().toString().padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export function dateStringFormatter(
  dateObj: { day: string; date: string },
  year: number = new Date().getFullYear()
): string {
  if (!dateObj || !dateObj.date) return "";

  // Extract the date string (e.g., "Nov 15")
  const { date } = dateObj;

  // Parse the month and day from the date string (e.g., "Nov" and "15")
  const [month, day] = date.split(" ");

  // Create a valid date string with the given year (e.g., "2025-Nov-15")
  const fullDateStr = `${month} ${day}, ${year}`;

  // Create a Date object from the string
  const dateParsed = new Date(fullDateStr);

  if (isNaN(dateParsed.getTime())) return "";

  // Extract the year, month, and day from the Date object
  const yyyy = dateParsed.getFullYear();
  const mm = String(dateParsed.getMonth() + 1).padStart(2, "0"); // months are 0-based
  const dd = String(dateParsed.getDate()).padStart(2, "0");

  // Return the formatted date as "YYYY-MM-DD"
  return `${yyyy}-${mm}-${dd}`;
}

export const convertUTCToTimeZone = (
  utcString: string,
  targetTimeZone?: string | null
) => {
  if (!utcString) return "";

  // If time_zone is empty/null, fallback to system timezone
  const tz =
    targetTimeZone && targetTimeZone.trim() !== ""
      ? targetTimeZone
      : Intl.DateTimeFormat().resolvedOptions().timeZone;

  const date = new Date(utcString + " UTC"); // Ensure UTC parsing

  return new Intl.DateTimeFormat("en-IN", {
    timeZone: tz,
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
};
