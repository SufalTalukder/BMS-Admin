export const getRowsPerPageOptions = (totalRecords: number): number[] => {
  const options: number[] = [10, 20, 50, 100]; // Default options
  const increment = 30; // Set increment as a constant

  // Check if total records exceed 100 and add dynamic options
  if (totalRecords > 100) {
    // Start at 120, increment by 30, until we reach or exceed the total records
    let start = 120;

    while (start <= totalRecords) {
      options.push(start);
      start += increment;
    }

    // Ensure the last option is added if it's exactly equal to totalRecords
    if (start - increment !== totalRecords) {
      options.push(totalRecords);
    }
  }

  return options;
};
