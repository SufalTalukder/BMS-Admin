export const parseClinicAddress = (rawAddress: string) => {
  let displayAddress = "N/A";
  let fullAddress = rawAddress;

  try {
    if (rawAddress?.trim().startsWith("{")) {
      const parsed = JSON.parse(rawAddress);

      // Pick main display address
      displayAddress =
        parsed.address ||
        parsed.line_1 ||
        parsed.line_2 ||
        parsed.city ||
        parsed.town ||
        parsed.village ||
        parsed.state_or_province ||
        "N/A";

      // Build full formatted address but SKIP empty values
      const meaningfulFields: string[] = [];

      Object.entries(parsed).forEach(([key, value]) => {
        if (value && String(value).trim() !== "") {
          meaningfulFields.push(`${key}: ${value}`);
        }
      });

      // If nothing meaningful → fallback to displayAddress
      fullAddress = meaningfulFields.length
        ? meaningfulFields.join("\n")
        : displayAddress;
    } else {
      displayAddress = rawAddress;
      fullAddress = rawAddress;
    }
  } catch (err) {
    displayAddress = rawAddress;
    fullAddress = rawAddress;
  }

  return { displayAddress, fullAddress };
};

export const extractAddress = (
  rawAddress: string | null | undefined
): string => {
  if (!rawAddress) return "N/A";

  try {
    const parsed = JSON.parse(rawAddress);

    if (parsed && typeof parsed === "object") {
      return parsed.address || "N/A";
    }
  } catch (err) {
    // Not JSON → return raw text
  }

  return rawAddress;
};
