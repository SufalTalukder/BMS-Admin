import { useState } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import Login from "./components/login/Login";
import "./App.css";
import { useGlobalStore } from "./store";
import { Toast } from "primereact/toast";
import { useRef } from "react";

import Layout from "./components/layout/Layout";
import Dashboard from "./components/dashboard/Dashboard";
import ProfilePage from "./pages/admin/ProfilePage";
import ClinicListPage from "./pages/clinic/ClinicListPage";
import FeedBackListPage from "./pages/feedBack/FeedBackListPage";
import SupportListPage from "./pages/support/SupportListPage";
import PlanListPage from "./pages/plan/PlanListPage";

function App() {
  const { isLoggedIn, setIsLoggedIn } = useGlobalStore();
  const toast = useRef<Toast>(null);

  // const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    navigate("/dashboard");
    //navigate("/appointment"); // Redirect to appointment page after login
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <Routes>
        {/* Home Page */}
        {/* <Route path="/" element={<HomePage />} /> */}
        {/* <Route path="/:doctorUid?" element={<HomePage />} /> */}

        <Route
          path="/login"
          element={<Login onHide={() => {}} onContinue={handleLoginSuccess} />}
        />
        <Route element={<Layout />}>
          <Route
            path="/"
            element={
              isLoggedIn ? <Dashboard /> : <Navigate to="/login" replace />
            }
          />
          <Route
            path="/profile"
            element={
              isLoggedIn ? <ProfilePage /> : <Navigate to="/login" replace />
            }
          />
          <Route
            path="/clinic"
            element={
              isLoggedIn ? <ClinicListPage /> : <Navigate to="/login" replace />
            }
          />
          <Route
            path="/feedBack"
            element={
              isLoggedIn ? (
                <FeedBackListPage />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />
          <Route
            path="/support"
            element={
              isLoggedIn ? (
                <SupportListPage />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />
          <Route
            path="/plan"
            element={
              isLoggedIn ? <PlanListPage /> : <Navigate to="/login" replace />
            }
          />
        </Route>

        {/* Dashboard Page */}
        {/* <Route
          path="/dashboard"
          element={
            isLoggedIn ? <DashboardPage /> : <Navigate to="/login" replace />
          }
        /> */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </>
  );
}

export default App;
