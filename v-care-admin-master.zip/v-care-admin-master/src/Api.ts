export const Apis = {
  paths: {
    appointBooking: {
      doctorDetails: (uid: string) => `patient/doctor/details/${uid}`,
      symptomList: "patient/master/symptoms",
      createAppointment: "patient/appointment",
      appointmentDetails: (uid: string) => `patient/appointment/${uid}`,
      appointmentStatusUpdate: "patient/appointment/status-update",
      appointmentRescheduled: "patient/appointment/reschedule",
    },
    auth: {
      login: "admin/login",
    },
    dashboard: {
      doctorList: "admin/doctor-list",
      doctorStatusUpdate: "admin/doctor-status-update",
      doctorDetails: (uid: string) => `admin/doctor/details/${uid}`,
      dashboardStats: "admin/dashboard-stats",
      doctorKycDocumentVerify: "admin/doctor-kyc-verify",
      doctorQualificationVerify: "admin/doctor-qualification-verify",
    },
    admin: {
      profileUpdate: "admin/profile-update",
    },
    clinic: {
      clinicList: "admin/clinic-list",
    },
    support: {
      supportList: "admin/support",
    },
    plan: {
      list: "admin/plan",
      update: (uid: string) => `admin/plan/${uid}`,
      add: "admin/plan/add",
    },
    patient: {
      register: "patient/register",
      patientList: (uid: string) => `patient/patient-list?patient_id=${uid}`,
      createPatient: "patient/add",
      appointmentList: (uid: string) =>
        `patient/appointment-list-for-patient/${uid}`,
      updatePatient: (uid: string) => `patient/update/${uid}`,
      patientRelationList: "patient/patient-relations",
      taggedPatientList: "patient/patient-list-by-tag",
      patientDetails: (uid: string) => `patient/details/${uid}`,
    },
  },
};
