export interface ClinicListData {
  id: string;
  uid: string;
  doctor_id: string;
  name: string;
  address: string;
  lat: string;
  lng: string;
  image: string;
  status: string;
  created_by: string;
  updated_by: string | null;
  created_at: string;
  updated_at: string | null;
  time_zone: string;
  created_by_name: string;
}
