import { Apis } from "../../Api";
import { Resty } from "../../resty";
import { extractAddress } from "../../utils/addressUtils";
import type { ClinicListData } from "./dto";

export const ClinicService = {
  getClinicList: async (
    pageSize: number,
    pageNumber: number,
    search?: string
  ): Promise<{
    data: ClinicListData[];
    message: string;
    status: number;
    count?: number;
    pageCount?: number;
  }> => {
    try {
      const url = `${Apis.paths.clinic.clinicList}`;

      const request = Resty.create()
        .get()
        .path(url)
        .queryParam("page", pageNumber.toString())
        .queryParam("page_size", pageSize.toString());

      if (search) {
        request.queryParam("search", search);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        if (data.data?.clinicList && Array.isArray(data.data?.clinicList)) {
          console.log("response content ====>: ", data.data?.clinicList);

          const startingId = (pageNumber - 1) * pageSize + 1;
          const modifiedData = data.data?.clinicList.map(
            (clinic: ClinicListData, index: number) => {
              const customId = startingId + index;
              return {
                ...clinic,
                id: clinic.id,
                uid: clinic.uid,
                name: clinic.name || "N/A",
                address: clinic.address || "N/A",
                lat: clinic.lat || "N/A",
                lng: clinic.lng || "N/A",
                image: clinic.image,
                status: clinic.status,
                time_zone: clinic.time_zone,
                created_at: clinic.created_at,
                created_by_name: clinic.created_by_name || "N/A",
              };
            }
          );

          return {
            data: modifiedData,
            message: data.message ? data.message : "Clinic loaded successfully",
            status: httpStatusValue,
            count: data.data?.pagination?.total || 0,
            pageCount: data.data?.pagination?.total_pages || 0,
          };
        } else {
          return {
            data: [],
            message: "No clinic data available.",
            status: httpStatusValue,
          };
        }
      } else {
        return {
          data: [],
          message: `Error fetching clinic. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching clinic list data:", error);
      return {
        data: [],
        message: "An error occurred while fetching the clinic list.",
        status: 500,
      };
    }
  },
};
