import { Apis } from "../../Api";
import { Resty } from "../../resty";
import type { LoginDetails } from "./dto";

export const LoginService = {
  login: async (payload: {
    email: string;
    password: string;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    data: LoginDetails | null;
  }> => {
    try {
      const requestBody: any = {
        email: payload.email,
        password: payload.password,
      };

      const url = Apis.paths.auth.login;

      const [status, error, data] = await new Resty()
        .path(url)
        .post()
        .bodyObject(requestBody)
        .execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Login successfully!",
          data: data?.data ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to Login. Please try again later.",
          data: null,
        };
      }
    } catch (err) {
      throw new Error("Error login: " + err);
    }
  },
};
