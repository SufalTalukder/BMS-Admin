export interface LoginDetails {
  id: string;
  uid: string;
  name: string;
  email: string;
  mobile: string;
  dob: string;
  image: string;
  status: string;
  token: string;
}
