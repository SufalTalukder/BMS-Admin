export interface PatientDetails {
  id: string;
  uid: string;
  name: string;
  email: string | null;
  owner_type: string | null;
  owner_id: string | null;
  tagged_as: string | null;
  mobile: string;
  age: string;
  age_on_date: string;
  dob: string;
  gender: string;
  more_details: string;
  profile_image: string;
  status: string;
  created_by: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
  patient_age: string;
  patient_relation: string;
}

export interface PatientListData {
  id: string;
  uid: string;
  name: string;
  email: string | null;
  owner_type: string;
  owner_id: string;
  mobile: string;
  age: string;
  age_on_date: string;
  dob: string;
  gender: string;
  more_details: string;
  profile_image: string;
  status: string;
  created_by: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
  patient_age: string;
}

export interface PatientAppointmentListData {
  id: string;
  uid: string;
  doctor_id: string;
  patient_id: string;
  clinic_id: string;
  date: string;
  time: string;
  duration: string;
  owner_type: string;
  owner_id: string;
  status: string;
  created_at: string;
  created_by: string;
  updated_at: string;
  updated_by: string;
  doctor_name: string;
  doctor_image: string;
  patient_name: string;
  patient_image: string;
  clinic_name: string;
  clinic_address: string;
  clinic_image: string;
  fees: string;
  patient_relation_name: string;
  clinic_lat: string;
  clinic_lng: string;
}

export interface PatientRelationListData {
  id: string;
  uid: string;
  name: string;
  description: string;
  icon: string;
  status: string;
  created_at: string;
  updated_at: string;
}
