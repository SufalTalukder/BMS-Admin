import { Apis } from "../../Api";
import { Resty } from "../../resty";
import type {
  PatientAppointmentListData,
  PatientDetails,
  PatientRelationListData,
} from "./dto";

export const PatientService = {
  registerPatient: async (
    payload: {
      first_name: string;
      last_name: string;
      mobile: string;
      dob: string;
      gender: string;
      email: string;
    },
    profile_image?: File
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    data: PatientDetails | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.patient.register;

      const resty = Resty.create();

      const filteredPayload: Record<string, any> = {};
      Object.entries(payload).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredPayload[key] = value;
        }
      });

      let req = resty.path(url).post().formFields(filteredPayload);

      if (profile_image) {
        req = req.file("profile_image", profile_image);
      }

      const [status, error, data] = await req.execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 201) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Patient registered successfully!",
          data: data?.data?.patient_details ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to register patient.",
          data: null,
        };
      }
    } catch (err) {
      console.error("Error in registerPatient:", err);
      throw new Error("Error register: " + err);
    }
  },

  getPatientList: async (
    uid: string,
    search?: string
  ): Promise<{
    data: PatientDetails[];
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.patient.patientList(uid)}`;

      const request = Resty.create().get().path(url);
      if (search) {
        request.queryParam("search", search);
      }
      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        const modifiedData = data.data.map((patient: PatientDetails) => ({
          uid: patient.uid,
          name: patient.name || "N/A",
          age: patient.age || "N/A",
          gender: patient.gender || "N/A",
          profile_image: patient.profile_image,
          patient_age: patient.patient_age || "25",
        }));
        return {
          data: modifiedData,
          message: data.message ? data.message : "Patients loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: [],
          message: `Error fetching patients. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching patients list data:", error);
      throw error;
    }
  },

  addPatient: async (
    payload: {
      first_name: string;
      last_name: string;
      mobile: string;
      dob: string;
      gender: string;
      owner_id: string;
      tagged_as: string;
    },
    profile_image?: File
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    data: PatientDetails | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.patient.createPatient;

      const resty = Resty.create();

      const filteredPayload: Record<string, any> = {};
      Object.entries(payload).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredPayload[key] = value;
        }
      });

      let req = resty.path(url).post().formFields(filteredPayload);

      if (profile_image) {
        req = req.file("profile_image", profile_image);
      }

      const [status, error, data] = await req.execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 201) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Patient created successfully!",
          data: data?.data?.patient_details ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to create patient.",
          data: null,
        };
      }
    } catch (err) {
      console.error("Error in create patient:", err);
      throw new Error("Error create patient: " + err);
    }
  },

  getPatientAppointmentList: async (
    uid: string
  ): Promise<{
    data: PatientAppointmentListData[];
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.patient.appointmentList(uid)}`;

      const request = Resty.create().get().path(url);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        return {
          data: data.data,
          message: data.message
            ? data.message
            : "Patients appointments loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: [],
          message: `Error fetching patient appointments. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching patient appointments list data:", error);
      throw error;
    }
  },

  updatePatient: async (
    uid: string,
    payload: {
      name?: string;
      email?: string;
      mobile?: string;
      dob?: string;
      age?: string;
      gender?: string;
    },
    profile_image?: File
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    data: PatientDetails | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.patient.updatePatient(uid);

      const resty = Resty.create();

      const filteredPayload: Record<string, any> = {};
      Object.entries(payload).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredPayload[key] = value;
        }
      });
      console.log("filteredPayload =====> ", filteredPayload);
      console.log("profile_image ====> ", profile_image);

      let req = resty.path(url).post().formFields(filteredPayload);

      if (profile_image) {
        req = req.file("profile_image", profile_image);
      }

      const [status, error, data] = await req.execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Patient updated successfully!",
          data: data?.data?.patient_details ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to update patient.",
          data: null,
        };
      }
    } catch (err) {
      console.error("Error in update patient:", err);
      throw new Error("Error update patient: " + err);
    }
  },

  getPatientRelationList: async (): Promise<{
    data: PatientRelationListData[];
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.patient.patientRelationList}`;

      const request = Resty.create().get().path(url);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        return {
          data: data.data,
          message: data.message
            ? data.message
            : "Patients relations loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: [],
          message: `Error fetching patient relations. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching patient relations list data:", error);
      throw error;
    }
  },

  getTaggedPatientList: async (
    owner_id: string,
    tagged_as: string
  ): Promise<{
    data: PatientDetails[];
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.patient.taggedPatientList}`;

      const request = Resty.create().get().path(url);

      request.queryParam("owner_id", owner_id);
      request.queryParam("tagged_as", tagged_as);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        const modifiedData = data.data.map((patient: PatientDetails) => ({
          uid: patient.uid,
          name: patient.name || "N/A",
          age: patient.age || "N/A",
          gender: patient.gender || "N/A",
          profile_image: patient.profile_image,
          patient_age: patient.patient_age || "25",
        }));

        return {
          data: modifiedData,
          message: data.message
            ? data.message
            : "Patient tagged list loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: [],
          message: `Error fetching patient tagged list. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching patient tagged list data:", error);
      throw error;
    }
  },

  getPatientDetails: async (
    id: string
  ): Promise<{
    data: PatientDetails | null;
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.patient.patientDetails(id)}`;

      const request = Resty.create().get().path(url);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        return {
          data: data?.data,
          message: "Patient Details loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: null,
          message: `Error fetching patient details. Status code: ${data?.httpStatus}`,
          status: httpStatusValue || 500,
        };
      }
    } catch (error) {
      console.error("Error fetching patient details:", error);
      throw error;
    }
  },
};
