export interface SupportListData {
  id: string;
  uid: string;
  doctor_id: string;
  type: string;
  subject: string;
  description: string;
  file_path: string;
  status: string;
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string | null;
  doctor_name: string;
  doctor_profile_pic: string;
}
