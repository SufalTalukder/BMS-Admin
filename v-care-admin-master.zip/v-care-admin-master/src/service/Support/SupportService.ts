import { Apis } from "../../Api";
import { Resty } from "../../resty";
import { extractAddress } from "../../utils/addressUtils";
import type { SupportListData } from "./dto";

export const SupportService = {
  getSupportList: async (
    pageSize: number,
    pageNumber: number,
    type?: string,
    search?: string
  ): Promise<{
    data: SupportListData[];
    message: string;
    status: number;
    count?: number;
    pageCount?: number;
  }> => {
    try {
      const url = `${Apis.paths.support.supportList}`;

      const request = Resty.create()
        .get()
        .path(url)
        .queryParam("pageNumber", pageNumber.toString())
        .queryParam("pageSize", pageSize.toString());

      if (type) {
        request.queryParam("type", type);
      }
      if (search) {
        request.queryParam("search", search);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        if (data.data?.supports && Array.isArray(data.data?.supports)) {
          console.log("response content ====>: ", data.data?.supports);

          const startingId = (pageNumber - 1) * pageSize + 1;
          const modifiedData = data.data?.supports.map(
            (support: SupportListData, index: number) => {
              const customId = startingId + index;
              return {
                ...support,
                id: support.id,
                uid: support.uid,
                type: support.type || "N/A",
                subject: support.subject || "N/A",
                description: support.description || "N/A",
                file_path: support.file_path,
                status: support.status || "N/A",
                created_at: support.created_at,
                doctor_name: support.doctor_name || "N/A",
                doctor_profile_pic: support.doctor_profile_pic,
              };
            }
          );

          return {
            data: modifiedData,
            message: data.message
              ? data.message
              : `${type} loaded successfully`,
            status: httpStatusValue,
            count: data.data?.pagination?.total || 0,
            pageCount: data.data?.pagination?.total_pages || 0,
          };
        } else {
          return {
            data: [],
            message: `No ${type} data available.`,
            status: httpStatusValue,
          };
        }
      } else {
        return {
          data: [],
          message: `Error fetching ${type}. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error(`Error fetching ${type} list data:`, error);
      return {
        data: [],
        message: `An error occurred while fetching the ${type} list.`,
        status: 500,
      };
    }
  },
};
