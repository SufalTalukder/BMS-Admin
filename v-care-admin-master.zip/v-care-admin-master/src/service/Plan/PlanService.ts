import { Apis } from "../../Api";
import { Resty } from "../../resty";
import { extractAddress } from "../../utils/addressUtils";
import type { PlanAddPayload, PlanListData, PlanUpdatePayload } from "./dto";

export const PlanService = {
  getPlanList: async (
    pageSize?: number,
    pageNumber?: number,
    country?: string,
    search?: string
  ): Promise<{
    data: PlanListData[];
    message: string;
    status: number;
    count?: number;
    pageCount?: number;
  }> => {
    try {
      const url = `${Apis.paths.plan.list}`;

      const request = Resty.create().get().path(url);

      if (pageNumber) {
        request.queryParam("pageNumber", pageNumber.toString());
      }
      if (pageSize) {
        request.queryParam("pageSize", pageSize.toString());
      }

      if (country) {
        request.queryParam("country", country);
      }
      if (search) {
        request.queryParam("search", search);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        if (data.data?.plans && Array.isArray(data.data?.plans)) {
          console.log("response content ====>: ", data.data?.plans);

          const modifiedData = data.data?.plans.map(
            (plan: PlanListData, index: number) => {
              return {
                ...plan,
                id: plan.id,
                uid: plan.uid,
                name: plan.name || "N/A",
                price: plan.price || "N/A",
                currency: plan.currency || "N/A",
                country: plan.country || "N/A",
                status: plan.status || "N/A",
                created_at: plan.created_at,
              };
            }
          );

          return {
            data: modifiedData,
            message: data.message ? data.message : `Plan loaded successfully`,
            status: httpStatusValue,
            count: data.data?.pagination?.total || 0,
            pageCount: data.data?.pagination?.total_pages || 0,
          };
        } else {
          return {
            data: [],
            message: `No plan data available.`,
            status: httpStatusValue,
          };
        }
      } else {
        return {
          data: [],
          message: `Error fetching plan. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error(`Error fetching plan list data:`, error);
      return {
        data: [],
        message: `An error occurred while fetching the plan list.`,
        status: 500,
      };
    }
  },

  updatePlan: async (
    uid: string,
    payload: PlanUpdatePayload
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
  }> => {
    try {
      console.log("updated payload ===> ", payload);

      const url = `${Apis.paths.plan.update(uid)}`;

      const [status, error, data] = await new Resty()
        .path(url)
        .patch()
        .bodyObject(payload)
        .execute();
      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Plan updated successfully!",
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to update plan",
        };
      }
    } catch (err) {
      console.error("Error in update plan:", err);
      throw new Error("Error update plan: " + err);
    }
  },

  addPlan: async (
    payload: PlanAddPayload
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
  }> => {
    try {
      const url = `${Apis.paths.plan.add}`;

      const [status, error, data] = await new Resty()
        .path(url)
        .post()
        .bodyObject(payload)
        .execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 201) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Plan add successfully!",
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to add plan",
        };
      }
    } catch (err) {
      console.error("Error in add plan:", err);
      throw new Error("Error add plan: " + err);
    }
  },
};
