export interface PlanFeatureItem {
  value: string;
}

export interface PlanFeatures {
  number_of_clinic?: PlanFeatureItem;
  number_of_appointment?: PlanFeatureItem;
  number_of_prescription?: PlanFeatureItem;
  basic_alerts?: PlanFeatureItem;
  qr_based_appointment_booking?: PlanFeatureItem;
  fast_and_details_prescription_mode?: PlanFeatureItem;
  secure_patient_records?: PlanFeatureItem;
}

export interface PlanListData {
  id: string;
  uid: string;
  name: string;
  sub_title: string;
  description: string;
  features: PlanFeatures;
  price: string;
  currency: string;
  duration_days: string;
  is_public: string;
  is_trial: string;
  is_popular: string;
  offer_label: string;
  price_label: string;
  bottom_text: string;
  country: string;
  timezone: string;
  status: string;
  created_at: string;
  updated_at: string;

  plan_id: string;
}

export interface PlanUpdatePayload {
  name?: string;
  duration_days?: string | number;
  price: number;
  currency: string;
  country: string;
  offer_label: string;
  price_label: string;
  description?: PlanDescriptionItem[] | null;
  features?: PlanFeaturesData;
}

export interface FeatureValue {
  value: string | null;
}

export interface PlanDescriptionItem {
  label: string;
  status: boolean;
}

export interface PlanFeaturesData {
  number_of_clinic?: FeatureValue;
  number_of_appointment?: FeatureValue;
  number_of_prescription?: FeatureValue;
  basic_alerts?: FeatureValue;
  qr_based_appointment_booking?: FeatureValue;
  fast_and_details_prescription_mode?: FeatureValue;
  secure_patient_records?: FeatureValue;
}
export interface PlanAddPayload {
  plan_id: string;
  country: string;
  price: number;
  currency: string;
  timeZone?: string;
  description?: PlanDescriptionItem[] | null;
  features?: PlanFeaturesData;
}
