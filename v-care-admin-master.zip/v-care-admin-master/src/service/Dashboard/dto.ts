export interface DoctorListData {
  id: string;
  uid: string;
  profile_pic: string;
  status: string;
  name: string;
  email: string;
  mobile: string;
  gender: string;
  dob: string;
  summary: string;
  created_by: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
  contact_mobile: string;
  contact_email: string;
  prescription_count: number;
  time_zone: string;
}

interface DoctorSpecialistData {
  uid: string;
  name: string;
}
interface DoctorExperienceData {
  years_of_experience: string;
  specialitie_id: string;
  specialitie_name: string;
}

interface DoctorClinicTimeSlotsData {
  cron_expression: string;
  details: string;
  applicable_from: string | null;
  applicable_to: string | null;
  start_time: string;
  end_time: string;
  days: string[];
}

export interface DoctorClinicData {
  uid: string;
  doctor_id: string;
  name: string;
  address: string;
  lat: string;
  lng: string;
  status: string;
  time_slots: DoctorClinicTimeSlotsData[];
  consultation_fee: string;
  contact_numbers: string;
}

export interface DoctorKycDocumentsData {
  uid: string;
  type: string;
  kyc_document_file: string;
  variation: string;
  is_verified: string;
}

export interface DoctorQualificationDocumentsData {
  uid: string;
  type: string | null;
  variation: string;
  doctor_qualification_document: string;
  is_verified: string;
}

export interface DoctorDetails {
  uid: string;
  profile_pic: string;
  name: string;
  email: string;
  mobile: string;
  gender: string;
  dob: string;
  summary: string;
  registration: string;
  specialities: DoctorSpecialistData[];
  experience: DoctorExperienceData[];
  kyc_documents: DoctorKycDocumentsData[];
  qualification_documents: DoctorQualificationDocumentsData[];
}

export interface DoctorFullDetailsData {
  doctor_details: DoctorDetails;
  clinic: DoctorClinicData[];
}

export interface AdminDashboardStats {
  total_doctors: number;
  total_appointments: number;
  total_clinics: number;
  total_earnings: number;
  total_prescription: number;
}
