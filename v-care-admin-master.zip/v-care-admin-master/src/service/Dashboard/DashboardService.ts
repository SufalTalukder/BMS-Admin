import { Apis } from "../../Api";
import { Resty } from "../../resty";
import type {
  AdminDashboardStats,
  DoctorFullDetailsData,
  DoctorListData,
} from "./dto";

export const DashboardService = {
  getDoctorList: async (
    pageSize: number,
    pageNumber: number,
    search?: string
  ): Promise<{
    data: DoctorListData[];
    message: string;
    status: number;
    count?: number;
    pageCount?: number;
  }> => {
    try {
      const url = `${Apis.paths.dashboard.doctorList}`;

      const request = Resty.create()
        .get()
        .path(url)
        .queryParam("page", pageNumber.toString())
        .queryParam("page_size", pageSize.toString());

      if (search) {
        request.queryParam("search", search);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        if (data.data?.doctorList && Array.isArray(data.data?.doctorList)) {
          // console.log("response content ====>: ", data.data?.doctorList);

          const startingId = (pageNumber - 1) * pageSize + 1;
          const modifiedData = data.data?.doctorList.map(
            (doctor: DoctorListData, index: number) => {
              const customId = startingId + index;
              const docMobile = doctor.mobile || doctor.contact_mobile || "N/A";
              const docEmail = doctor.email || doctor.contact_email || "N/A";
              return {
                ...doctor,
                id: doctor.id,
                uid: doctor.uid,
                name: doctor.name || "N/A",
                dob: doctor.dob || "N/A",
                email: docEmail,
                mobile: docMobile,
                gender: doctor.gender || "N/A",
                profile_pic: doctor.profile_pic,
                status: doctor.status,
                time_zone: doctor.time_zone,
                prescription_count: doctor.prescription_count || 0,
              };
            }
          );

          return {
            data: modifiedData,
            message: data.message
              ? data.message
              : "Doctors loaded successfully",
            status: httpStatusValue,
            count: data.data?.pagination?.total || 0,
            pageCount: data.data?.pagination?.total_pages || 0,
          };
        } else {
          return {
            data: [],
            message: "No doctor data available.",
            status: httpStatusValue,
          };
        }
      } else {
        return {
          data: [],
          message: `Error fetching doctors. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching doctors list data:", error);
      return {
        data: [],
        message: "An error occurred while fetching the doctor list.",
        status: 500,
      };
    }
  },

  updateDoctorStatus: async (payload: {
    doctor_uid: string;
    status: string;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.dashboard.doctorStatusUpdate;

      const [status, error, data] = await new Resty()
        .path(url)
        .patch()
        .bodyObject(payload)
        .execute();
      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Doctor status updated successfully!",
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to update doctor status",
        };
      }
    } catch (err) {
      console.error("Error in update doctor status:", err);
      throw new Error("Error update doctor status: " + err);
    }
  },

  getDoctorDetails: async (
    uid: string,
    clinic_id?: string
  ): Promise<{
    data: DoctorFullDetailsData | null;
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.dashboard.doctorDetails(uid)}`;

      const request = Resty.create().get().path(url);
      if (clinic_id) {
        request.queryParam("clinic_id", clinic_id);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      // console.log("getDoctorDetails ====> ", data);

      if (httpStatusValue === 200) {
        return {
          data: data.data,
          message: "Doctor Details loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: null,
          message: `Error fetching doctor details. Status code: ${data?.httpStatus}`,
          status: httpStatusValue || 500,
        };
      }
    } catch (error) {
      console.error("Error fetching doctor details:", error);
      throw error;
    }
  },

  getAdminDashboardStatsDetails: async (): Promise<{
    data: AdminDashboardStats | null;
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.dashboard.dashboardStats}`;

      const request = Resty.create().get().path(url);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      console.log("getAdminDashboardStatsDetails ====> ", data);

      if (httpStatusValue === 200) {
        return {
          data: data.data,
          message: "Dashboard stats Details loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: null,
          message: `Error fetching dashboard stats details. Status code: ${data?.httpStatus}`,
          status: httpStatusValue || 500,
        };
      }
    } catch (error) {
      console.error("Error fetching dashboard stats details:", error);
      throw error;
    }
  },

  verifyDoctorKycDocument: async (payload: {
    kyc_document_uid: string;
    is_verified: number;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
  }> => {
    try {
      // console.log("verifyDoctorKycDocument payload ====> ", payload);

      const url = Apis.paths.dashboard.doctorKycDocumentVerify;

      const [status, error, data] = await new Resty()
        .path(url)
        .patch()
        .bodyObject(payload)
        .execute();

      const httpStatusCode = data?.httpStatus ?? status ?? 500;

      if (httpStatusCode === 200 && data?.success !== false) {
        return {
          success: true,
          httpStatus: httpStatusCode,
          message:
            data?.message || "Doctor KYC document verified successfully!",
        };
      }

      if (httpStatusCode >= 400 && httpStatusCode < 500) {
        return {
          success: false,
          httpStatus: httpStatusCode,
          message: data?.message || "Request failed. Please check input data.",
        };
      }

      return {
        success: false,
        httpStatus: httpStatusCode,
        message: data?.message || "Server error while verifying KYC document.",
      };
    } catch (err: any) {
      console.error("Error verifying doctor KYC document:", err);

      return {
        success: false,
        httpStatus: 500,
        message: "Unexpected error verifying doctor KYC document.",
      };
    }
  },

  verifyDoctorQualificationDocument: async (payload: {
    qualification_document_uid: string;
    is_verified: number;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
  }> => {
    try {
      const url = Apis.paths.dashboard.doctorQualificationVerify;

      const [status, error, data] = await new Resty()
        .path(url)
        .patch()
        .bodyObject(payload)
        .execute();

      const httpStatusCode = data?.httpStatus ?? status ?? 500;

      if (httpStatusCode === 200 && data?.success !== false) {
        return {
          success: true,
          httpStatus: httpStatusCode,
          message:
            data?.message ||
            "Doctor Qualification document verified successfully!",
        };
      }

      if (httpStatusCode >= 400 && httpStatusCode < 500) {
        return {
          success: false,
          httpStatus: httpStatusCode,
          message: data?.message || "Request failed. Please check input data.",
        };
      }

      return {
        success: false,
        httpStatus: httpStatusCode,
        message:
          data?.message ||
          "Server error while verifying Qualification document.",
      };
    } catch (err: any) {
      console.error("Error verifying doctor Qualification document:", err);

      return {
        success: false,
        httpStatus: 500,
        message: "Unexpected error verifying doctor Qualification document.",
      };
    }
  },
};
