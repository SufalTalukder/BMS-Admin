export interface AdminDetailsData {
  id: string;
  uid: string;
  name: string;
  mobile: string;
  image: string;
  email: string;
  password: string;
  dob: string;
  created_at: string;
  created_by: string | null;
  updated_at: string;
  updated_by: string;
  status: string;
}
