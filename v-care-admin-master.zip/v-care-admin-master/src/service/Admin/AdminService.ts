import { Apis } from "../../Api";
import { Resty } from "../../resty";
import type { AdminDetailsData } from "./dto";

export const AdminService = {
  updateAdmin: async (
    payload: {
      uid: string;
      name?: string;
      email?: string;
      mobile?: string;
      dob?: string;
    },
    profile_image?: File
  ): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    data: AdminDetailsData | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.admin.profileUpdate;

      const resty = Resty.create();

      const filteredPayload: Record<string, any> = {};
      Object.entries(payload).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredPayload[key] = value;
        }
      });
      console.log("filteredPayload =====> ", filteredPayload);
      console.log("profile_image ====> ", profile_image);

      let req = resty.path(url).post().formFields(filteredPayload);

      if (profile_image) {
        req = req.file("image", profile_image);
      }

      const [status, error, data] = await req.execute();

      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Admin updated successfully!",
          data: data?.data?.admin_details ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to update admin.",
          data: null,
        };
      }
    } catch (err) {
      console.error("Error in update admin:", err);
      throw new Error("Error update admin: " + err);
    }
  },
};
