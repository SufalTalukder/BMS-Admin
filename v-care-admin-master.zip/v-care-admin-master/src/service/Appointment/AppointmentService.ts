import { Apis } from "../../Api";
import { Resty } from "../../resty";
import type {
  AppointmentDetailsData,
  AppointmentDoctorDetails,
  SymptomListData,
} from "./dto";

export const AppointmentService = {
  getDoctorDetails: async (
    uid: string,
    clinic_id?: string
  ): Promise<{
    data: AppointmentDoctorDetails | null;
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.appointBooking.doctorDetails(uid)}`;

      const request = Resty.create().get().path(url);
      if (clinic_id) {
        request.queryParam("clinic_id", clinic_id);
      }

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        return {
          data: data.data,
          message: "Doctor Details loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: null,
          message: `Error fetching doctor details. Status code: ${data?.httpStatus}`,
          status: httpStatusValue || 500,
        };
      }
    } catch (error) {
      console.error("Error fetching doctor details:", error);
      throw error;
    }
  },

  getSymptomList: async (
    search?: string
  ): Promise<{
    data: SymptomListData[];
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.appointBooking.symptomList}`;

      const request = Resty.create().get().path(url);
      if (search) {
        request.queryParam("search", search);
      }
      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        const modifiedData = data.data.map((symptom: SymptomListData) => ({
          id: symptom.id,
          uid: symptom.uid,
          name: symptom.name || "N/A",
          description: symptom.description || "N/A",
          image: symptom.image,
          status: symptom.status || "N/A",
        }));
        return {
          data: modifiedData,
          message: data.message ? data.message : "Symptoms loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: [],
          message: `Error fetching symptoms. Status code: ${httpStatusValue}`,
          status: httpStatusValue,
        };
      }
    } catch (error) {
      console.error("Error fetching symptoms list data:", error);
      throw error;
    }
  },

  addAppointment: async (payload: {
    doctor_id: string;
    patient_id: string;
    clinic_id: string;
    date: string;
    time: string;
    duration: string;
    owner_type: string;
    owner_id: string;
    payment_mode: string;
    total_amount: string;
    symptom_id: string;
    symptom_desc?: string;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    appointment_id?: string | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.appointBooking.createAppointment;

      const [status, error, data] = await new Resty()
        .path(url)
        .post()
        .bodyObject(payload)
        .execute();
      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 201) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Appointment booked successfully!",
          appointment_id: data?.data?.appointment_id ?? null,
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to book appointment",
        };
      }
    } catch (err) {
      console.error("Error in book appointment:", err);
      throw new Error("Error book appointment: " + err);
    }
  },

  getAppointmentDetails: async (
    id: string
  ): Promise<{
    data: AppointmentDetailsData | null;
    message: string;
    status: number;
  }> => {
    try {
      const url = `${Apis.paths.appointBooking.appointmentDetails(id)}`;

      const request = Resty.create().get().path(url);

      const [status, error, data, headers] = await request.execute();

      const httpStatusValue = data?.httpStatus || status;

      if (httpStatusValue === 200) {
        return {
          data: data?.data,
          message: "Appointment Details loaded successfully",
          status: httpStatusValue,
        };
      } else {
        return {
          data: null,
          message: `Error fetching appointment details. Status code: ${data?.httpStatus}`,
          status: httpStatusValue || 500,
        };
      }
    } catch (error) {
      console.error("Error fetching appointment details:", error);
      throw error;
    }
  },

  updateAppointmentStatus: async (payload: {
    appointment_id: string;
    status: string;
    owner_id: string;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    appointment_id?: string | null;
  }> => {
    try {
      console.log("payload ====> ", payload);

      const url = Apis.paths.appointBooking.appointmentStatusUpdate;

      const [status, error, data] = await new Resty()
        .path(url)
        .put()
        .bodyObject(payload)
        .execute();
      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Appointment status updated successfully!",
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to update appointment status",
        };
      }
    } catch (err) {
      console.error("Error in update appointment status:", err);
      throw new Error("Error update appointment status: " + err);
    }
  },

  updateAppointmentRescheduled: async (payload: {
    appointment_id: string;
    owner_id: string;
    date: string;
    time: string;
    duration: string;
  }): Promise<{
    success: boolean;
    httpStatus: number;
    message: string;
    appointment_id?: string | null;
  }> => {
    try {
      const url = Apis.paths.appointBooking.appointmentRescheduled;

      const [status, error, data] = await new Resty()
        .path(url)
        .put()
        .bodyObject(payload)
        .execute();
      const httpStatusCode = data?.httpStatus || status;

      if (httpStatusCode === 200) {
        return {
          success: data?.success ?? true,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Appointment rescheduled successfully!",
        };
      } else {
        return {
          success: data?.success ?? false,
          httpStatus: httpStatusCode,
          message: data?.message ?? "Failed to rescheduled appointment",
        };
      }
    } catch (err) {
      console.error("Error in rescheduled appointment status:", err);
      throw new Error("Error rescheduled appointment: " + err);
    }
  },
};
