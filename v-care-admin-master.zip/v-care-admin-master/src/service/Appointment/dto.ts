interface DoctorSpecialistData {
  uid: string;
  name: string;
}
interface DoctorExperienceData {
  years_of_experience: string;
  specialitie_id: string;
  specialitie_name: string;
}

interface DoctorClinicTimeSlotsData {
  cron_expression: string;
  details: string;
  applicable_from: string | null;
  applicable_to: string | null;
  start_time: string;
  end_time: string;
  days: string[];
}

export interface DoctorClinicData {
  uid: string;
  doctor_id: string;
  name: string;
  address: string;
  lat: string;
  lng: string;
  status: string;
  time_slots: DoctorClinicTimeSlotsData[];
  consultation_fee: string;
  contact_numbers: string;
}

export interface DoctorDetails {
  uid: string;
  profile_pic: string;
  name: string;
  email: string;
  mobile: string;
  gender: string;
  dob: string;
  summary: string;
  registration: string;
  specialities: DoctorSpecialistData[];
  experience: DoctorExperienceData[];
}

export interface AppointmentDoctorDetails {
  doctor_details: DoctorDetails;
  clinic: DoctorClinicData[];
}

export interface AppointmentBookingSelection {
  doctorId: string;
  doctorDetails: AppointmentDoctorDetails;
  date: string;
  time: string;
  serviceType: "In-Person" | "Virtual";
  clinicId?: string;
  clinicName?: string;
  clinicAddress?: string;
  patientName?: string;
  consultation_fee?: string;
  [key: string]: any;
}

export interface SymptomListData {
  id: string;
  uid: string;
  group_id: string;
  name: string;
  description: string;
  image: string;
  status: string;
  created_by: string;
  updated_by: string;
  created_at: string;
  updated_at: string;
}

export interface AppointmentDetailsData {
  id: string;
  uid: string;
  doctor_id: string;
  patient_id: string;
  clinic_id: string;
  date: string;
  time: string;
  duration: string;
  owner_type: string;
  owner_id: string;
  status: string;
  created_at: string;
  created_by: string;
  updated_at: string;
  updated_by: string;
  doctor_name: string;
  doctor_image: string;
  patient_name: string;
  patient_image: string;
  clinic_name: string;
  clinic_address: string;
  clinic_image: string;
  fees: string;
  clinic_lat: string;
  clinic_lng: string;
}
