import { create } from "zustand";
import { persist } from "zustand/middleware";
import { produce } from "immer";

import type {
  AppointmentBookingSelection,
  AppointmentDetailsData,
  AppointmentDoctorDetails,
  SymptomListData,
} from "./service/Appointment/dto";
import type { PatientDetails } from "./service/Patient/dto";
import type { LoginDetails } from "./service/Login/dto";

function generateDeviceId() {
  return (
    "web-" +
    Date.now().toString(36) +
    "-" +
    Math.random().toString(36).substr(2, 9)
  );
}
interface GlobalStoreState {
  isLoggedIn: boolean;
  adminDetails: LoginDetails | null;

  headerName: string;

  setIsLoggedIn: (isLogin: boolean) => void;
  setAdminDetails: (data: LoginDetails | null) => void;

  setHeaderName: (title: string) => void;

  resetAllData: () => void;
}

export const useGlobalStore = create<GlobalStoreState>()(
  persist(
    (set, get) => ({
      isLoggedIn: false,
      adminDetails: null,
      headerName: "Dashboard",

      setIsLoggedIn: (isLoggedIn: boolean) =>
        set(
          produce((state: GlobalStoreState) => {
            state.isLoggedIn = isLoggedIn;
          })
        ),

      setAdminDetails: (data) =>
        set(
          produce((state: GlobalStoreState) => {
            state.adminDetails = data;
          })
        ),
      setHeaderName: (title: string) =>
        set(
          produce((state: GlobalStoreState) => {
            state.headerName = title;
          })
        ),

      resetAllData: () =>
        set(
          produce((state: GlobalStoreState) => {
            state.isLoggedIn = false;

            state.adminDetails = null;
            state.headerName = "Dashboard";
          })
        ),
    }),
    {
      name: "clinic-pe-admin-Storage",
    }
  )
);
