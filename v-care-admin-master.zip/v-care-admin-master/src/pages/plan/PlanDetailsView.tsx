import { useEffect, useRef, useState, type RefObject } from "react";
import { Sidebar } from "primereact/sidebar";
import type { PlanListData } from "../../service/Plan/dto";

type PlanDetailsViewProps = {
  visible: boolean;
  uid: string | null;
  onClose: (state: boolean) => void;
  planData: PlanListData | null;
};

const parseJSONSafely = <T,>(value: any, fallback: T): T => {
  try {
    if (!value) return fallback;
    if (typeof value === "string") return JSON.parse(value);
    return value;
  } catch {
    return fallback;
  }
};

export default function PlanDetailsView({
  visible,
  uid,
  onClose,
  planData,
}: PlanDetailsViewProps) {
  useEffect(() => {
    if (visible && uid && planData) {
      console.log("plan details for uid ", uid);
    }
  }, [visible, uid]);

  if (!visible) return null;

  const parsedDescription = parseJSONSafely<
    { label: string; status: boolean }[]
  >(planData?.description, []);

  const parsedFeatures = parseJSONSafely<Record<string, { value: string }>>(
    planData?.features,
    {}
  );

  const FEATURE_LABELS: Record<string, string> = {
    number_of_clinic: "Number of Clinics",
    number_of_appointment: "Appointments",
    number_of_prescription: "Prescriptions",
    basic_alerts: "Basic Alerts",
    qr_based_appointment_booking: "QR Booking",
    fast_and_details_prescription_mode: "Fast Prescription",
    secure_patient_records: "Secure Records",
  };

  const customHeader = (
    <div className="flex items-center gap-2">
      <div className="font-bold text-black text-xl">Plan Details</div>
    </div>
  );

  // if (planData) {
  // }

  const isPublic = planData?.is_public === "1";
  const isTrial = planData?.is_trial === "1";
  const isPopular = planData?.is_popular === "1";

  return (
    <>
      <Sidebar
        header={customHeader}
        visible={visible}
        position="right"
        onHide={() => onClose(false)}
        className="p-sidebar-md"
        style={{ width: "480px" }}
      >
        {planData && (
          <div className="space-y-6 text-sm">
            {/* Plan Title */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {planData.name}
                </h2>

                {planData.sub_title && (
                  <p className="text-gray-500 mt-1">{planData.sub_title}</p>
                )}
              </div>

              {/* Offer + Flags */}
              <div className="flex flex-wrap gap-2 items-center justify-end">
                {/* Offer Label */}
                {planData.offer_label && (
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full ${
                      planData.offer_label.toLowerCase() === "free"
                        ? "bg-green-100 text-green-700"
                        : "bg-orange-100 text-orange-700"
                    }`}
                  >
                    {planData.offer_label}
                  </span>
                )}

                {/* Public */}
                {isPublic && (
                  <span className="text-xs font-medium px-2 py-1 rounded-full bg-blue-100 text-blue-700">
                    Public
                  </span>
                )}

                {/* Trial */}
                {isTrial && (
                  <span className="text-xs font-medium px-2 py-1 rounded-full bg-purple-100 text-purple-700">
                    Trial
                  </span>
                )}

                {/* Popular */}
                {isPopular && (
                  <span className="text-xs font-medium px-2 py-1 rounded-full bg-yellow-100 text-yellow-700">
                    Popular
                  </span>
                )}
              </div>
            </div>

            {/* Price Section */}
            <div className="grid grid-cols-3 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div>
                <div className="text-gray-500 text-xs">Price</div>
                <div className="font-semibold text-gray-900">
                  {planData.currency} {planData.price}
                </div>

                {/* Price Label */}
                {planData.price_label && (
                  <div className="text-xs text-gray-500 capitalize">
                    {planData.price_label}
                  </div>
                )}
              </div>

              <div>
                <div className="text-gray-500 text-xs">Duration</div>
                <div className="font-semibold text-gray-900">
                  {planData.duration_days} days
                </div>
              </div>

              <div>
                <div className="text-gray-500 text-xs">Country</div>
                <div className="font-semibold text-gray-900 capitalize">
                  {planData.country}
                </div>
              </div>
            </div>

            {/* Description */}
            {parsedDescription.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">
                  Description
                </h3>

                <ul className="space-y-2">
                  {parsedDescription.map((item, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <span
                        className={`mt-1 text-xs ${
                          item.status ? "text-green-600" : "text-gray-400"
                        }`}
                      >
                        {item.status ? "✔" : "✖"}
                      </span>
                      <span
                        className={`${
                          item.status
                            ? "text-gray-700"
                            : "text-gray-400 line-through"
                        }`}
                      >
                        {item.label}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Features */}
            <div>
              <h3 className="font-semibold text-gray-800 mb-3">Features</h3>

              <div className="space-y-2">
                {Object.entries(FEATURE_LABELS).map(([key, label]) => {
                  const feature = parsedFeatures[key];

                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-md text-sm"
                    >
                      <span className="text-gray-700">{label}</span>

                      <span
                        className={`text-xs font-medium px-2 py-1 rounded-full ${
                          feature?.value
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {feature?.value ?? "Not Available"}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Status */}
            <div className="flex justify-between items-center pt-4 border-t">
              <span className="text-gray-500">Status</span>
              <span
                className={`text-xs font-semibold px-3 py-1 rounded-full ${
                  planData.status === "active"
                    ? "bg-green-100 text-green-700"
                    : "bg-gray-100 text-gray-600"
                }`}
              >
                {planData.status.toUpperCase()}
              </span>
            </div>
          </div>
        )}
      </Sidebar>
    </>
  );
}
