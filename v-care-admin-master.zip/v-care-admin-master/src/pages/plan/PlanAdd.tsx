import { useEffect, useRef, useState } from "react";
import { Sidebar } from "primereact/sidebar";
import { InputText } from "primereact/inputtext";
import { Dropdown, type DropdownChangeEvent } from "primereact/dropdown";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import { PlanService } from "../../service/Plan/PlanService";
import type { PlanListData } from "../../service/Plan/dto";

type PlanAddProps = {
  visible: boolean;
  onClose: (state: boolean) => void;
  onSuccess: () => void;
};

const COUNTRY_OPTIONS = [
  { label: "India", value: "india" },
  { label: "Canada", value: "canada" },
  { label: "USA", value: "usa" },
  { label: "Australia", value: "australia" },
];

const COUNTRY_TIMEZONE_MAP: Record<string, string> = {
  india: "Asia/Kolkata",
  canada: "America/Toronto",
  usa: "America/New_York",
  australia: "Australia/Sydney",
};

const COUNTRY_CURRENCY_MAP: Record<string, { label: string; value: string }> = {
  india: { label: "INR", value: "INR" },
  canada: { label: "CAD", value: "CAD" },
  usa: { label: "USD", value: "USD" },
  australia: { label: "AUD", value: "AUD" },
};
type AddFormState = {
  plan_id: string;
  country: string;
  currency: string;
  price: string;
  description: DescriptionItem[];
  features: FeaturesState;
};

const DEFAULT_FORM: AddFormState = {
  plan_id: "",
  country: "india",
  currency: "INR",
  price: "",
  description: [],
  features: {
    number_of_clinic: "",
    number_of_appointment: "",
    number_of_prescription: "",
    basic_alerts: false,
    qr_based_appointment_booking: false,
    fast_and_details_prescription_mode: false,
    secure_patient_records: false,
  },
};

type DescriptionItem = {
  label: string;
  status: boolean;
};
type FeaturesState = {
  number_of_clinic: string;
  number_of_appointment: string;
  number_of_prescription: string;
  basic_alerts: boolean;
  qr_based_appointment_booking: boolean;
  fast_and_details_prescription_mode: boolean;
  secure_patient_records: boolean;
};

export default function PlanAdd({ visible, onClose, onSuccess }: PlanAddProps) {
  const toast = useRef<Toast | null>(null);

  const [loading, setLoading] = useState(false);
  const [plans, setPlans] = useState<PlanListData[]>([]);

  const [form, setForm] = useState<AddFormState>(DEFAULT_FORM);

  /* ---------- Load base plans (India as master) ---------- */
  const loadPlans = async () => {
    const res = await PlanService.getPlanList(100, 1, "india");
    if (res.status === 200) {
      setPlans(res.data);
    }
  };

  if (visible && plans.length === 0) {
    loadPlans();
  }

  if (!visible) return null;

  /* ---------- Country change ---------- */
  const onCountryChange = (e: DropdownChangeEvent) => {
    const currency = COUNTRY_CURRENCY_MAP[e.value];
    setForm({
      ...form,
      country: e.value,
      currency: currency?.value ?? "",
    });
  };

  const resetForm = () => {
    setForm(DEFAULT_FORM);
    setLoading(false);
  };

  const addDescriptionRow = () => {
    setForm({
      ...form,
      description: [...form.description, { label: "", status: true }],
    });
  };

  const updateDescription = (
    index: number,
    key: "label" | "status",
    value: any
  ) => {
    const updated = [...form.description];
    updated[index] = { ...updated[index], [key]: value };
    setForm({ ...form, description: updated });
  };

  const removeDescription = (index: number) => {
    const updated = form.description.filter((_, i) => i !== index);
    setForm({ ...form, description: updated });
  };

  const updateFeatureValue = (key: keyof FeaturesState, value: any) => {
    setForm({
      ...form,
      features: {
        ...form.features,
        [key]: value,
      },
    });
  };

  /* ---------- Submit ---------- */
  const handleSubmit = async () => {
    if (!form.plan_id) {
      toast.current?.show({
        severity: "warn",
        summary: "Validation Error",
        detail: "Please select a plan",
        life: 3000,
      });
      return;
    }

    if (!form.country) {
      toast.current?.show({
        severity: "warn",
        summary: "Validation Error",
        detail: "Please select a country",
        life: 3000,
      });
      return;
    }

    if (!form.price) {
      toast.current?.show({
        severity: "warn",
        summary: "Validation Error",
        detail: "Please enter a price",
        life: 3000,
      });
      return;
    }

    const payload = {
      plan_id: form.plan_id,
      country: form.country,
      currency: form.currency,
      price: Number(form.price),
      timeZone: COUNTRY_TIMEZONE_MAP[form.country],
      description:
        form.description && form.description.length > 0
          ? form.description
          : null,
      features: {
        number_of_clinic: { value: form.features.number_of_clinic || null },
        number_of_appointment: {
          value: form.features.number_of_appointment || null,
        },
        number_of_prescription: {
          value: form.features.number_of_prescription || null,
        },
        basic_alerts: { value: String(form.features.basic_alerts) },
        qr_based_appointment_booking: {
          value: String(form.features.qr_based_appointment_booking),
        },
        fast_and_details_prescription_mode: {
          value: String(form.features.fast_and_details_prescription_mode),
        },
        secure_patient_records: {
          value: String(form.features.secure_patient_records),
        },
      },
    };

    console.log("payload ====> ", payload);

    try {
      setLoading(true);
      const res = await PlanService.addPlan(payload);

      if (res.success) {
        toast.current?.show({
          severity: "success",
          summary: "Success",
          detail: res.message || "Plan added successfully",
          life: 1500,
        });
        setTimeout(() => {
          onSuccess();
          resetForm();
          onClose(false);
        }, 1800);
      } else {
        toast.current?.show({
          severity: "error",
          summary: "Error",
          detail: res.message || "Failed to add plan",
          life: 4000,
        });
      }
    } catch (err) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Something went wrong. Please try again.",
        life: 4000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <Sidebar
        visible={visible}
        position="right"
        style={{ width: "480px" }}
        onHide={() => {
          resetForm();
          onClose(false);
        }}
        header={<h2 className="text-xl font-bold">Add Plan</h2>}
      >
        <div className="flex flex-col h-full">
          <div className="flex-1 overflow-y-auto pr-2 space-y-6 text-sm">
            {/* Plan Dropdown */}
            <div>
              <label className="text-sm font-medium text-gray-600">
                Select Plan
              </label>
              <Dropdown
                value={form.plan_id}
                options={plans}
                optionLabel="name"
                optionValue="uid"
                placeholder="Select plan"
                className="w-full"
                onChange={(e) => setForm({ ...form, plan_id: e.value })}
              />
            </div>

            {/* Country */}
            <div>
              <label className="text-sm font-medium text-gray-600">
                Country
              </label>
              <Dropdown
                value={form.country}
                options={COUNTRY_OPTIONS}
                className="w-full"
                onChange={onCountryChange}
              />
            </div>

            {/* Currency */}
            <div>
              <label className="text-sm font-medium text-gray-600">
                Currency
              </label>
              <InputText
                value={form.currency}
                disabled
                className="w-full bg-gray-100"
              />
            </div>

            {/* Price */}
            <div>
              <label className="text-sm font-medium text-gray-600">Price</label>
              <InputText
                value={form.price}
                keyfilter="num"
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                className="w-full"
              />
            </div>

            {/* Description */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-gray-600">
                  Description
                </label>
                <Button
                  icon="pi pi-plus"
                  size="small"
                  text
                  onClick={addDescriptionRow}
                />
              </div>

              {form.description.map((item, index) => (
                <div
                  key={index}
                  className="flex gap-2 items-center border border-gray-200 rounded-lg p-2"
                >
                  <InputText
                    placeholder="Description label"
                    value={item.label}
                    onChange={(e) =>
                      updateDescription(index, "label", e.target.value)
                    }
                    className="flex-1"
                  />

                  <Dropdown
                    value={item.status}
                    options={[
                      { label: "Yes", value: true },
                      { label: "No", value: false },
                    ]}
                    onChange={(e) =>
                      updateDescription(index, "status", e.value)
                    }
                    className="w-32"
                  />

                  <Button
                    icon="pi pi-trash"
                    severity="danger"
                    text
                    onClick={() => removeDescription(index)}
                  />
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="space-y-4">
              <label className="text-sm font-medium text-gray-600">
                Features
              </label>

              <div className="grid grid-cols-2 gap-4">
                <InputText
                  placeholder="No. of Clinics"
                  value={form.features.number_of_clinic}
                  onChange={(e) =>
                    updateFeatureValue("number_of_clinic", e.target.value)
                  }
                />

                <InputText
                  placeholder="No. of Appointments"
                  value={form.features.number_of_appointment}
                  onChange={(e) =>
                    updateFeatureValue("number_of_appointment", e.target.value)
                  }
                />

                <InputText
                  placeholder="No. of Prescriptions"
                  value={form.features.number_of_prescription}
                  onChange={(e) =>
                    updateFeatureValue("number_of_prescription", e.target.value)
                  }
                />
              </div>
              {[
                { key: "basic_alerts", label: "Basic Alerts" },
                { key: "qr_based_appointment_booking", label: "QR Booking" },
                {
                  key: "fast_and_details_prescription_mode",
                  label: "Fast Prescription Mode",
                },
                {
                  key: "secure_patient_records",
                  label: "Secure Patient Records",
                },
              ].map((item) => (
                <div
                  key={item.key}
                  className="flex justify-between items-center border border-gray-200 rounded-lg px-3 py-2"
                >
                  <span className="text-sm">{item.label}</span>
                  <Dropdown
                    value={(form.features as any)[item.key]}
                    options={[
                      { label: "Yes", value: true },
                      { label: "No", value: false },
                    ]}
                    onChange={(e) =>
                      updateFeatureValue(item.key as any, e.value)
                    }
                    className="w-24"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="sticky bottom-0 bg-white pt-4 pb-2 ">
            <Button
              icon="pi pi-plus"
              loading={loading}
              onClick={handleSubmit}
              className="
                w-full py-3 rounded-lg text-base
                flex items-center justify-center
                bg-indigo-600 hover:bg-indigo-700
                border-none text-white
                "
            >
              <span className="ml-2">Add Plan</span>
            </Button>
          </div>
        </div>
      </Sidebar>
    </>
  );
}
