import { useEffect, useRef, useState, type RefObject } from "react";
import { Button } from "primereact/button";
import { useNavigate } from "react-router-dom";
import { getRowsPerPageOptions } from "../../utils/paginationUtils";
import { Paginator, type PaginatorPageChangeEvent } from "primereact/paginator";
import { Card } from "primereact/card";
import { DataTable, type DataTableSortMeta } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Toast } from "primereact/toast";
import { convertUTCToTimeZone } from "../../utils/dateFormatter";
import { Menu } from "primereact/menu";
import { useGlobalStore } from "../../store";
import { SupportService } from "../../service/Support/SupportService";
import type { SupportListData } from "../../service/Support/dto";
import { Avatar } from "primereact/avatar";
import { Image } from "primereact/image";
import { PlanService } from "../../service/Plan/PlanService";
import type { PlanListData } from "../../service/Plan/dto";
import { Dropdown, type DropdownChangeEvent } from "primereact/dropdown";
import React from "react";
import PlanDetailsView from "./PlanDetailsView";
import PlanEdit from "./PlanEdit";
import PlanAdd from "./PlanAdd";

type TemplateOptions = {
  rowIndex: number;
};
type MenuRef = RefObject<Menu | null>;

export default function PlanListPage() {
  const actionMenuRefs = useRef<MenuRef[]>([]);

  const toast = useRef<Toast | null>(null);
  const [firstRowIndex, setFirstRowIndex] = useState<number>(0);
  const [selectedPageSize, setSelectedPageSize] = useState<number>(50);
  const [loading, setLoading] = useState(false);
  const [globalFilter, setGlobalFilter] = useState<string>("");

  const [planData, setPlanData] = useState<PlanListData[]>([]);
  const [plansDataCount, setPlansDataCount] = useState<number>(0);
  const [multiSortMeta, setMultiSortMeta] = useState<
    DataTableSortMeta[] | undefined
  >([]);

  const [selectedPlanData, setSelectedPlanData] = useState<PlanListData | null>(
    null
  );

  const [viewVisible, setViewVisible] = useState(false);
  const [selectedPlanUid, setSelectedPlanUid] = useState<string | null>(null);

  const [editVisible, setEditVisible] = useState(false);
  const [selectedPlanUidForEdit, setSelectedPlanUidForEdit] = useState<
    string | null
  >(null);

  const [addVisible, setAddVisible] = useState(false);

  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  const { setHeaderName } = useGlobalStore();

  const [selectedCountry, setSelectedCountry] = useState<string>("india");

  const countryOptions = [
    { label: "India", value: "india" },
    { label: "Canada", value: "canada" },
    { label: "USA", value: "usa" },
    { label: "Australia", value: "australia" },
  ];

  const COUNTRY_CURRENCY_MAP: Record<string, { symbol: string; code: string }> =
    {
      india: { symbol: "₹", code: "INR" },
      canada: { symbol: "$", code: "CAD" },
      usa: { symbol: "$", code: "USD" },
      australia: { symbol: "$", code: "AUD" },
    };

  useEffect(() => {
    setHeaderName("Plans");
  }, []);

  /////// effects //////////////
  const fetchPlanListData = async () => {
    try {
      setLoading(true);

      const response = await PlanService.getPlanList(
        selectedPageSize,
        Math.floor(firstRowIndex / selectedPageSize) + 1,
        selectedCountry,
        globalFilter.trim() ? globalFilter : undefined
      );

      if (response.status === 200) {
        setPlanData(response.data);
        setPlansDataCount(response.count || 0);
      } else {
        setPlanData([]);
        setPlansDataCount(0);
      }
    } catch (error) {
      console.error("Error in fetching plan list data:", error);
      setPlanData([]);
      setPlansDataCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      // Only trigger search if at least 2 characters or filter is cleared
      if (globalFilter.trim().length >= 2 || globalFilter.trim().length === 0) {
        fetchPlanListData();
      }
    }, 500); // wait 500ms after typing stops

    // Cleanup if user keeps typing fast
    return () => clearTimeout(handler);
  }, [firstRowIndex, selectedPageSize, globalFilter, selectedCountry]);

  ///// change event //////
  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setFirstRowIndex(event.first);
    setSelectedPageSize(event.rows);
  };

  const onSelectionChange = (e: { value: PlanListData }) => {
    setSelectedPlanData(e.value);
  };

  ////////// templates

  const priceTemplate = (plan: PlanListData) => {
    if (!plan.price) {
      return <>N/A</>;
    }

    const currency = COUNTRY_CURRENCY_MAP[plan.country?.toLowerCase()] ?? {
      symbol: "",
      code: "",
    };

    return (
      <span className="font-medium">
        {currency.symbol}
        {Number(plan.price).toLocaleString()}
        {/* {currency.code && (
          <span className="text-xs text-gray-500 ml-1">{currency.code}</span>
        )} */}
      </span>
    );
  };

  const durationTemplate = (plan: PlanListData) => {
    return (
      <>
        {plan.duration_days ? (
          <>
            <p>{plan.duration_days} days</p>
          </>
        ) : (
          <>N/A</>
        )}
      </>
    );
  };

  const statusTemplate = (support: PlanListData) => {
    return (
      <span
        className={`text-xs font-medium px-2 py-1 rounded-full ${
          support.status === "active"
            ? "bg-green-100 text-green-800"
            : "bg-gray-100 text-gray-600"
        }`}
      >
        {support.status?.toUpperCase() || "N/A"}
      </span>
    );
  };

  const actionTemplate = (rowData: PlanListData, options: TemplateOptions) => {
    const index = options.rowIndex;
    if (!actionMenuRefs.current[index]) {
      actionMenuRefs.current[index] = React.createRef();
    }

    const menuModel = [
      {
        label: "View",
        icon: "pi pi-eye",
        command: () => {
          handleViewClick(rowData);
        },
      },
      {
        label: "Edit",
        icon: "pi pi-pencil",
        // command: () => console.log("edit clicked for ID:", rowData.uid),
        command: () => {
          handleEditClick(rowData);
        },
      },
      // {
      //   label: "Delete",
      //   icon: "pi pi-trash",
      //   command: () => console.log("Delete clicked for ID:", rowData.uid),
      // },
    ];

    return (
      <>
        <Menu model={menuModel} popup ref={actionMenuRefs.current[index]} />
        <Button
          icon="pi pi-ellipsis-v"
          rounded
          text
          size="small"
          className="btnico text-black"
          onClick={(e) => actionMenuRefs.current[index]?.current?.toggle(e)}
          aria-haspopup
          aria-controls="popup_menu"
        />
      </>
    );
  };

  ///// handlers ///////
  const handleViewClick = (rowData: PlanListData) => {
    setSelectedPlanData(rowData);

    setSelectedPlanUid(rowData.plan_id);
    setViewVisible(true);
  };
  const handleViewClose = (state: boolean) => {
    setViewVisible(state);
  };

  const handleEditClick = (rowData: PlanListData) => {
    setSelectedPlanData(rowData);

    setSelectedPlanUidForEdit(rowData.plan_id);
    setEditVisible(true);
  };

  const handleEditClose = (state: boolean) => {
    setEditVisible(state);
  };

  const handleAddClick = () => {
    console.log("add new plan pricing");
    setAddVisible(true);
  };

  const handleAddClose = (state: boolean) => {
    setAddVisible(state);
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center"></div>

        {/* DataTable Section */}
        <Card className="shadow-md">
          {/* Add Plan Button */}
          {/* Header */}
          <div className="flex justify-between items-center mb-4 w-full">
            <h2 className="text-lg font-semibold">All Plan</h2>

            <Button
              label="Add Plan"
              icon="pi pi-plus"
              onClick={handleAddClick}
            />
          </div>
          <div className="flex flex-col md:flex-row md:items-end gap-4 mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
            {/* Search */}
            <div className="flex flex-col w-full md:w-1/3">
              <label className="text-sm font-medium text-gray-600 mb-1">
                Search
              </label>

              <span className="p-input-icon-left w-full">
                {/* <i className="pi pi-search text-gray-400" /> */}
                <InputText
                  value={globalFilter}
                  onChange={(e) => setGlobalFilter(e.target.value)}
                  placeholder="Search plans..."
                  className="w-full pl-10"
                />
              </span>
            </div>

            {/* Country Filter */}
            <div className="flex flex-col w-full md:w-1/4">
              <label className="text-sm font-medium text-gray-600 mb-1">
                Country
              </label>
              <Dropdown
                value={selectedCountry}
                options={countryOptions}
                onChange={(e: DropdownChangeEvent) => {
                  setSelectedCountry(e.value);
                  setFirstRowIndex(0);
                }}
                placeholder="Select Country"
                className="w-full"
              />
            </div>

            {/* Optional Clear Button */}
            <div className="flex w-full md:w-auto">
              <Button
                label="Clear"
                icon="pi pi-times"
                outlined
                className="w-full md:w-auto mt-6"
                onClick={() => {
                  setGlobalFilter("");
                  setSelectedCountry("india");
                  setFirstRowIndex(0);
                }}
              />
            </div>
          </div>

          <DataTable
            value={planData || []}
            selection={selectedPlanData!}
            onSelectionChange={onSelectionChange}
            selectionMode="single"
            dataKey="uid"
            // rows={10}
            globalFilter={globalFilter}
            sortMode="multiple"
            scrollable
            // scrollHeight="400px"
            // scrollHeight="calc(100vh - 230px)"
            className="text-sm w-full "
            loading={loading!}
            multiSortMeta={multiSortMeta}
            onSort={(e) => {
              if (e.multiSortMeta !== null && e.multiSortMeta !== undefined) {
                setMultiSortMeta(e.multiSortMeta);
              }
              console.log(" multiSortMeta ===> ", multiSortMeta);
              console.log("dataTable sort data");
            }}
          >
            <Column field="id" header="#" sortable />
            <Column field="name" header="Name" sortable />
            <Column field="country" header="Country" sortable />
            <Column
              field="price"
              header="Price"
              body={priceTemplate}
              sortable
            />
            <Column field="currency" header="Currency" sortable />
            <Column
              field="duration_days"
              header="Duration"
              body={durationTemplate}
              sortable
            />

            <Column
              field="status"
              header="Status"
              body={statusTemplate}
              sortable
            />
            <Column
              header="Actions"
              body={actionTemplate}
              style={{ width: "80px" }}
            />
          </DataTable>
          <div className="card">
            <Paginator
              first={firstRowIndex}
              rows={selectedPageSize}
              totalRecords={plansDataCount || 0}
              onPageChange={onPageChange}
              rowsPerPageOptions={getRowsPerPageOptions(plansDataCount || 0)}
            />
          </div>
        </Card>
      </div>

      <PlanDetailsView
        visible={viewVisible}
        onClose={handleViewClose}
        uid={selectedPlanUid}
        planData={selectedPlanData!}
      />

      <PlanEdit
        visible={editVisible}
        onClose={handleEditClose}
        uid={selectedPlanUidForEdit}
        planData={selectedPlanData!}
        onSuccess={fetchPlanListData}
      />

      <PlanAdd
        visible={addVisible}
        onClose={handleAddClose}
        onSuccess={fetchPlanListData}
      />
    </>
  );
}
