import { useEffect, useRef, useState } from "react";
import { Sidebar } from "primereact/sidebar";
import { InputText } from "primereact/inputtext";
import { Dropdown, type DropdownChangeEvent } from "primereact/dropdown";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import type { PlanListData } from "../../service/Plan/dto";
import { PlanService } from "../../service/Plan/PlanService";

type PlanEditProps = {
  visible: boolean;
  uid: string | null;
  onClose: (state: boolean) => void;
  planData: PlanListData | null;
  onSuccess: () => void;
};

type DescriptionItem = {
  label: string;
  status: boolean;
};

type FeaturesState = {
  number_of_clinic: string;
  number_of_appointment: string;
  number_of_prescription: string;
  basic_alerts: boolean;
  qr_based_appointment_booking: boolean;
  fast_and_details_prescription_mode: boolean;
  secure_patient_records: boolean;
};

type EditFormState = {
  name: string;
  price: string;
  currency: string;
  country: string;
  offer_label: string;
  price_label: string;
  description: DescriptionItem[];
  features: FeaturesState;
};

// type EditFormState = {
//   name: string;
//   // duration_days: string;
//   price: string;
//   currency: string;
//   country: string;
//   offer_label: string;
//   price_label: string;
// };

export default function PlanEdit({
  visible,
  uid,
  onClose,
  planData,
  onSuccess,
}: PlanEditProps) {
  const toast = useRef<Toast | null>(null);

  const [loading, setLoading] = useState(false);
  const DEFAULT_EDIT_FORM: EditFormState = {
    name: "",
    price: "",
    currency: "",
    country: "",
    offer_label: "",
    price_label: "",
    description: [],
    features: {
      number_of_clinic: "",
      number_of_appointment: "",
      number_of_prescription: "",
      basic_alerts: false,
      qr_based_appointment_booking: false,
      fast_and_details_prescription_mode: false,
      secure_patient_records: false,
    },
  };
  const [form, setForm] = useState<EditFormState>(DEFAULT_EDIT_FORM);

  // const [form, setForm] = useState<EditFormState>({
  //   name: "",
  //   // duration_days: "",
  //   price: "",
  //   currency: "",
  //   country: "",
  //   offer_label: "",
  //   price_label: "",
  // });

  /* ---------- Dropdown options ---------- */
  const countryOptions = [
    { label: "India", value: "india" },
    { label: "Canada", value: "canada" },
    { label: "USA", value: "usa" },
    { label: "Australia", value: "australia" },
  ];

  const currencyOptions = [
    { label: "INR", value: "INR" },
    { label: "USD", value: "USD" },
    { label: "CAD", value: "CAD" },
    { label: "AUD", value: "AUD" },
  ];

  const priceLabelOptions = [
    { label: "One-time", value: "one-time" },
    { label: "Per Month", value: "month" },
    { label: "Per Year", value: "year" },
  ];

  const parseJSONSafely = <T,>(value: any, fallback: T): T => {
    try {
      if (!value) return fallback;
      if (typeof value === "string") return JSON.parse(value);
      return value;
    } catch {
      return fallback;
    }
  };

  /* ---------- Prefill form ---------- */
  // useEffect(() => {
  //   if (visible && planData) {
  //     setForm({
  //       name: planData.name ?? "",
  //       // duration_days: planData.duration_days ?? "",
  //       price: planData.price ?? "",
  //       currency: planData.currency ?? "",
  //       country: planData.country ?? "",
  //       offer_label: planData.offer_label ?? "",
  //       price_label: planData.price_label ?? "",
  //     });
  //   }
  // }, [visible, planData]);

  // if (!visible) return null;
  useEffect(() => {
    if (visible && planData) {
      const parsedDescription = parseJSONSafely<DescriptionItem[]>(
        planData.description,
        []
      );

      const parsedFeatures = parseJSONSafely<any>(planData.features, {});

      setForm({
        name: planData.name ?? "",
        price: planData.price ?? "",
        currency: planData.currency ?? "",
        country: planData.country ?? "",
        offer_label: planData.offer_label ?? "",
        price_label: planData.price_label ?? "",
        description: parsedDescription,
        features: {
          number_of_clinic: parsedFeatures?.number_of_clinic?.value ?? "",
          number_of_appointment:
            parsedFeatures?.number_of_appointment?.value ?? "",
          number_of_prescription:
            parsedFeatures?.number_of_prescription?.value ?? "",
          basic_alerts: parsedFeatures?.basic_alerts?.value === "true",
          qr_based_appointment_booking:
            parsedFeatures?.qr_based_appointment_booking?.value === "true",
          fast_and_details_prescription_mode:
            parsedFeatures?.fast_and_details_prescription_mode?.value ===
            "true",
          secure_patient_records:
            parsedFeatures?.secure_patient_records?.value === "true",
        },
      });
    }
  }, [visible, planData]);

  const addDescriptionRow = () => {
    setForm({
      ...form,
      description: [...form.description, { label: "", status: true }],
    });
  };

  const updateDescription = (
    index: number,
    key: "label" | "status",
    value: any
  ) => {
    const updated = [...form.description];
    updated[index] = { ...updated[index], [key]: value };
    setForm({ ...form, description: updated });
  };

  const removeDescription = (index: number) => {
    const updated = form.description.filter((_, i) => i !== index);
    setForm({ ...form, description: updated });
  };

  const updateFeatureValue = (key: keyof FeaturesState, value: any) => {
    setForm({
      ...form,
      features: {
        ...form.features,
        [key]: value,
      },
    });
  };

  /* ---------- Update handler ---------- */
  const handleUpdate = async () => {
    if (!uid) return;

    // temp off that duration days
    // const payload = {
    //   ...(form.country === "india" && { name: form.name }),
    //   // duration_days: form.duration_days,
    //   price: Number(form.price),
    //   currency: form.currency,
    //   country: form.country,
    //   offer_label: form.offer_label,
    //   price_label: form.price_label,
    // };
    const payload = {
      ...(form.country === "india" && { name: form.name }),
      price: Number(form.price),
      currency: form.currency,
      country: form.country,
      offer_label: form.offer_label,
      price_label: form.price_label,

      description:
        form.description && form.description.length > 0
          ? form.description
          : null,

      features: {
        number_of_clinic: { value: form.features.number_of_clinic || null },
        number_of_appointment: {
          value: form.features.number_of_appointment || null,
        },
        number_of_prescription: {
          value: form.features.number_of_prescription || null,
        },
        basic_alerts: { value: String(form.features.basic_alerts) },
        qr_based_appointment_booking: {
          value: String(form.features.qr_based_appointment_booking),
        },
        fast_and_details_prescription_mode: {
          value: String(form.features.fast_and_details_prescription_mode),
        },
        secure_patient_records: {
          value: String(form.features.secure_patient_records),
        },
      },
    };

    console.log("handle update ===> ", payload);

    try {
      setLoading(true);

      const response = await PlanService.updatePlan(uid, payload);

      if (response.success) {
        toast.current?.show({
          severity: "success",
          summary: "Success",
          detail: response.message || "Plan updated successfully",
          life: 3000,
        });
        onSuccess();
        setTimeout(() => {
          onClose(false);
        }, 1500);
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Warning",
          detail: response.message || "Update failed",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("Update failed:", error);

      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Something went wrong while updating plan",
        life: 4000,
      });
    } finally {
      setLoading(false);
    }
  };

  const customHeader = (
    <div className="flex items-center gap-2">
      <div className="font-bold text-black text-xl">Edit Plan</div>
    </div>
  );

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <Sidebar
        header={customHeader}
        visible={visible}
        position="right"
        onHide={() => onClose(false)}
        className="p-sidebar-md"
        style={{ width: "480px" }}
      >
        <div className="space-y-6 text-sm">
          {/* Plan Name */}
          <div>
            <label className="text-sm font-medium text-gray-600">
              Plan Name
            </label>
            <InputText
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full"
              disabled={form.country !== "india"}
            />
            {form.country !== "india" && (
              <>
                <p className="text-xs text-gray-400 mt-1">
                  Plan name can be edited only for India
                </p>
              </>
            )}
          </div>

          {/* Duration */}
          {/* <div>
            <label className="text-sm font-medium text-gray-600">
              Duration (Days)
            </label>
            <InputText
              value={form.duration_days}
              onChange={(e) =>
                setForm({ ...form, duration_days: e.target.value })
              }
              className="w-full"
            />
          </div> */}

          {/* Price */}
          <div>
            <label className="text-sm font-medium text-gray-600">Price</label>
            <InputText
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="w-full"
            />
          </div>

          {/* Price Label */}
          <div>
            <label className="text-sm font-medium text-gray-600">
              Price Label
            </label>
            <Dropdown
              value={form.price_label}
              options={priceLabelOptions}
              onChange={(e: DropdownChangeEvent) =>
                setForm({ ...form, price_label: e.value })
              }
              placeholder="Select price label"
              className="w-full"
            />
          </div>

          {/* Offer Label */}
          <div>
            <label className="text-sm font-medium text-gray-600">
              Offer Label
            </label>
            <InputText
              value={form.offer_label}
              onChange={(e) =>
                setForm({ ...form, offer_label: e.target.value })
              }
              placeholder="e.g. 20% OFF / FREE"
              className="w-full"
            />
          </div>

          {/* Currency */}
          <div>
            <label className="text-sm font-medium text-gray-600">
              Currency
            </label>
            <Dropdown
              value={form.currency}
              options={currencyOptions}
              onChange={(e: DropdownChangeEvent) =>
                setForm({ ...form, currency: e.value })
              }
              className="w-full"
            />
          </div>

          {/* Description */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-gray-600">
                Description
              </label>
              <Button
                icon="pi pi-plus"
                size="small"
                text
                onClick={addDescriptionRow}
              />
            </div>

            {form.description.length === 0 && (
              <p className="text-xs text-gray-400">No description added</p>
            )}

            {form.description.map((item, index) => (
              <div
                key={index}
                className="flex gap-2 items-center border border-gray-200 rounded-lg p-2"
              >
                <InputText
                  placeholder="Description label"
                  value={item.label}
                  onChange={(e) =>
                    updateDescription(index, "label", e.target.value)
                  }
                  className="flex-1"
                />

                <Dropdown
                  value={item.status}
                  options={[
                    { label: "Yes", value: true },
                    { label: "No", value: false },
                  ]}
                  onChange={(e) => updateDescription(index, "status", e.value)}
                  className="w-28"
                />

                <Button
                  icon="pi pi-trash"
                  severity="danger"
                  text
                  onClick={() => removeDescription(index)}
                />
              </div>
            ))}
          </div>

          {/* Features */}
          <div className="space-y-4">
            <label className="text-sm font-medium text-gray-600">
              Features
            </label>

            <div className="grid grid-cols-2 gap-4">
              <InputText
                placeholder="No. of Clinics"
                value={form.features.number_of_clinic}
                onChange={(e) =>
                  updateFeatureValue("number_of_clinic", e.target.value)
                }
              />

              <InputText
                placeholder="No. of Appointments"
                value={form.features.number_of_appointment}
                onChange={(e) =>
                  updateFeatureValue("number_of_appointment", e.target.value)
                }
              />

              <InputText
                placeholder="No. of Prescriptions"
                value={form.features.number_of_prescription}
                onChange={(e) =>
                  updateFeatureValue("number_of_prescription", e.target.value)
                }
              />
            </div>

            {[
              { key: "basic_alerts", label: "Basic Alerts" },
              { key: "qr_based_appointment_booking", label: "QR Booking" },
              {
                key: "fast_and_details_prescription_mode",
                label: "Fast Prescription Mode",
              },
              {
                key: "secure_patient_records",
                label: "Secure Patient Records",
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex justify-between items-center border border-gray-200 rounded-lg px-3 py-2"
              >
                <span className="text-sm">{item.label}</span>
                <Dropdown
                  value={(form.features as any)[item.key]}
                  options={[
                    { label: "Yes", value: true },
                    { label: "No", value: false },
                  ]}
                  onChange={(e) =>
                    updateFeatureValue(item.key as keyof FeaturesState, e.value)
                  }
                  className="w-24"
                />
              </div>
            ))}
          </div>

          {/* Country */}
          <div>
            <label className="text-sm font-medium text-gray-600">Country</label>
            <Dropdown
              value={form.country}
              options={countryOptions}
              onChange={(e: DropdownChangeEvent) =>
                setForm({ ...form, country: e.value })
              }
              className="w-full"
              disabled={true}
            />
          </div>

          {/* Update Button */}
          <div className="pt-4">
            {/* <Button
              label="Update Plan"
              icon="pi pi-check"
              loading={loading}
              className="w-full"
              onClick={handleUpdate}
            /> */}

            <Button
              icon="pi pi-check"
              loading={loading}
              onClick={handleUpdate}
              className="
                            w-full py-3 rounded-lg text-base
                            flex items-center justify-center
                            bg-indigo-600 hover:bg-indigo-700
                            border-none text-white
                            "
            >
              <span className="ml-2">Update Plan</span>
            </Button>
          </div>
        </div>
      </Sidebar>
    </>
  );
}
