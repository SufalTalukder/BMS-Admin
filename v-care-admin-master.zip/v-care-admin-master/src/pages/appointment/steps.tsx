// pages/appointment/steps.tsx
import { useState } from "react";
import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { RadioButton } from "primereact/radiobutton";
import { useNavigate } from "react-router-dom";

export default function AppointmentStepsPage() {
  const navigate = useNavigate();

  // States
  const [dob, setDob] = useState<Date | null>(null);
  const [gender, setGender] = useState<string>("");

  const genders = ["Male", "Female", "Other"];

  const handleBack = () => {
    navigate("/appointment"); // go back to selection page
  };

  const handleConfirm = () => {
    console.log("Selected DOB:", dob);
    console.log("Selected Gender:", gender);
    alert(`Appointment confirmed for ${dob?.toLocaleDateString()} (${gender})`);
  };

  return (
    <div className="h-full bg-[#f1f1f1] p-4 overflow-auto min-h-screen">
      {/* Header */}
      <div className="p-4 bg-white text-black font-semibold text-lg flex items-center gap-3 rounded-md">
        <Button
          icon="pi pi-arrow-left"
          className="!text-black p-button-text"
          onClick={handleBack}
        />
        <span>Appointment Details</span>
      </div>

      {/* Form Content */}
      <div className="space-y-4 mt-6">
        {/* Date of Birth */}
        <div className="flex flex-col gap-2">
          <label className="font-medium text-black">Date of Birth</label>
          <Calendar
            value={dob}
            onChange={(e) => setDob(e.value as Date)}
            maxDate={new Date()} // only past days
            placeholder="Select DOB"
            className="w-full !bg-white !border !border-[#ccc] rounded-md"
            showIcon
          />
        </div>

        {/* Gender Radio Buttons */}
        <div className="flex flex-col gap-2">
          <label className="font-medium text-black">Gender</label>
          <div className="flex gap-4">
            {genders.map((g) => (
              <div
                key={g}
                className={`flex items-center gap-2 border rounded p-2 cursor-pointer transition ${
                  gender === g ? "bg-[#0D52AF] text-white border-[#0D52AF]" : "bg-white text-black border-[#ccc]"
                }`}
                onClick={() => setGender(g)}
              >
                <RadioButton
                  inputId={g}
                  name="gender"
                  value={g}
                  onChange={() => setGender(g)}
                  checked={gender === g}
                />
                <label htmlFor={g}>{g}</label>
              </div>
            ))}
          </div>
        </div>

        {/* Confirm Button */}
        <Button
          label="Confirm Appointment"
          icon="pi pi-arrow-right"
          iconPos="right"
          className="!bg-[#0D52AF] !border-[#0D52AF] w-full mt-4"
          onClick={handleConfirm}
          disabled={!dob || !gender}
        />
      </div>
    </div>
  );
}
