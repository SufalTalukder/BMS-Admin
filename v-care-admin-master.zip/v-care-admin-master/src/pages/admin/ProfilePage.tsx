// src/pages/ProfileInfo.tsx
import { Avatar } from "primereact/avatar";
import { Badge } from "primereact/badge";
import { Button } from "primereact/button";
import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Image } from "primereact/image";

import { Toast } from "primereact/toast";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { InputMask } from "primereact/inputmask";
import { FileUpload } from "primereact/fileupload";
import { Dialog } from "primereact/dialog"; // Import Dialog
import { Calendar } from "primereact/calendar";
import { useNavigate } from "react-router-dom";
import { formatDateToYYYYMMDD } from "../../utils/dateFormatter";
import { useGlobalStore } from "../../store";
import { AdminService } from "../../service/Admin/AdminService";
import type { LoginDetails } from "../../service/Login/dto";
import { Card } from "primereact/card";
import { ProgressSpinner } from "primereact/progressspinner";

export default function ProfilePage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();

  const [loading, setLoading] = useState<boolean>(false);
  const [notificationCount, setNotificationCount] = useState<number | null>(0);

  const [sidebarVisible, setSidebarVisible] = useState(false);
  const { adminDetails, setAdminDetails } = useGlobalStore();

  const footerButtons = [
    { label: "Dashboard", icon: "pi pi-home", path: "/dashboard" },
    { label: "Health Data", icon: "pi pi-chart-line", path: "/health-data" },
    { label: "Appointments", icon: "pi pi-calendar", path: "/all-appointment" },
    { label: "Messages", icon: "pi pi-envelope", path: "/messages" },
    { label: "Profile", icon: "pi pi-user", path: "/profile-details" },
  ];
  const [editing, setEditing] = useState(false);

  const { setHeaderName } = useGlobalStore();

  useEffect(() => {
    setHeaderName("Profile");
  }, []);

  const [formData, setFormData] = useState<{
    name?: string;
    email?: string;
    mobile?: string | null;
    gender?: string;
    dob?: Date | string | null;
    profile_image?: File | null;
    age?: string | null;
  }>({
    name: "",
    email: "",
    mobile: "",
    gender: "",
    dob: null,
    profile_image: null,
    age: null,
  });

  useEffect(() => {
    if (adminDetails) {
      setFormData({
        name: adminDetails.name || "",
        email: adminDetails.email || "",
        mobile: adminDetails.mobile || "",
        dob: adminDetails.dob || "",
        profile_image: null,
      });
    }
  }, [adminDetails]);

  const handleProfileImageUpload = (event: any) => {
    const file = event.files[0];
    setFormData((prev) => ({ ...prev, profile_image: file }));
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        profile_image: file,
      }));
    }
  };
  const resetFormDataFromSaved = () => {
    if (adminDetails) {
      setFormData({
        name: adminDetails.name || "",
        email: adminDetails.email || "",
        mobile: adminDetails.mobile || "",
        dob: adminDetails.dob || "",
        profile_image: null,
      });
    }
  };

  const handleCancelEdit = () => {
    resetFormDataFromSaved();
    setEditing(false);
  };

  const handleSave = async () => {
    try {
      if (!adminDetails?.uid) return;
      console.log("formData ==> ", formData);
      console.log("adminDetails ==> ", adminDetails);

      const trimmedName = formData.name?.trim() || "";
      const trimmedEmail = formData.email?.trim() || "";
      const trimmedMobile = formData.mobile?.trim() || "";

      if (!trimmedName || trimmedName.length < 3) {
        toast.current?.show({
          severity: "warn",
          summary: "Invalid Name",
          detail: "Name must be at least 3 characters long.",
          life: 3000,
        });
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
        toast.current?.show({
          severity: "warn",
          summary: "Invalid Email",
          detail: "Please enter a valid email address.",
          life: 3000,
        });
        return;
      }

      if (trimmedMobile && !/^\d{10}$/.test(trimmedMobile)) {
        toast.current?.show({
          severity: "warn",
          summary: "Invalid Mobile",
          detail: "Mobile number must be exactly 10 digits.",
          life: 3000,
        });
        return;
      }

      const changedData: {
        uid: string;
        name?: string;
        email?: string;
        mobile?: string;
        dob?: string;
      } = {
        uid: adminDetails.uid,
      };

      if (trimmedName !== adminDetails.name) changedData.name = trimmedName;
      if (trimmedEmail !== (adminDetails.email || ""))
        changedData.email = trimmedEmail;
      if (trimmedMobile !== (adminDetails.mobile || ""))
        changedData.mobile = trimmedMobile;

      if (formData.dob) {
        const dobString = formatDateToYYYYMMDD(formData.dob);

        if (dobString !== adminDetails.dob) {
          changedData.dob = dobString;
        }
      }

      if (Object.keys(changedData).length === 0 && !formData.profile_image) {
        toast.current?.show({
          severity: "info",
          summary: "No Changes",
          detail: "No changes detected to update.",
          life: 3000,
        });
        setEditing(false);
        return;
      }

      console.log("changedData ===> ", changedData);

      const response = await AdminService.updateAdmin(
        changedData,
        formData.profile_image || undefined
      );

      if (response.success) {
        toast.current?.show({
          severity: "success",
          summary: "Profile Updated",
          detail: response.message,
          life: 3000,
        });
        console.log("profile update data ===> ", response.data);

        if (response.data) {
          console.log("get register patient details ", response.data);
          const updatedAdmin: LoginDetails = {
            ...adminDetails,
            id: response.data.id,
            uid: response.data.uid,
            name: response.data.name,
            mobile: response.data.mobile,
            image: response.data.image,
            email: response.data.email,
            dob: response.data.dob,
          };

          setAdminDetails(updatedAdmin);
        }

        setEditing(false);
      } else {
        toast.current?.show({
          severity: "error",
          summary: "Update Failed",
          detail: response.message,
          life: 3000,
        });
      }
    } catch (error) {
      console.error(error);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to update profile",
        life: 3000,
      });
    }
  };

  return (
    <>
      <Toast ref={toast} />

      <div className="p-6">
        <div className="flex justify-center">
          <Card className="w-full sm:w-2/3 lg:w-1/2 shadow-md rounded-xl p-8 bg-white">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <ProgressSpinner />
              </div>
            ) : (
              <>
                {/* Profile Image + Name */}
                <div className="flex flex-col items-center space-y-3">
                  <Avatar
                    image={adminDetails?.image || "/images/doctor1.webp"}
                    shape="circle"
                    className="w-24 h-24 border-4 border-blue-100 shadow-sm"
                    size="xlarge"
                  />
                  <h2 className="text-xl font-semibold text-gray-800">
                    {adminDetails?.name || "Name not available"}
                  </h2>
                </div>

                {/* Info Grid */}
                <div className="mt-8 grid grid-cols-2 gap-y-4 text-sm text-gray-700">
                  {/* Left Column */}
                  <div className="flex flex-col items-center gap-2">
                    <div className="flex items-center gap-2">
                      <i className="pi pi-phone text-blue-500"></i>
                      <span>{adminDetails?.mobile || "N/A"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <i className="pi pi-envelope text-blue-500"></i>
                      <span>{adminDetails?.email || "N/A"}</span>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="flex flex-col items-center gap-2">
                    <div className="flex items-center gap-2">
                      <i className="pi pi-calendar text-blue-500"></i>
                      <span>{adminDetails?.dob || "N/A"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <i className="pi pi-check-circle text-blue-500"></i>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          adminDetails?.status === "active"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {adminDetails?.status?.toUpperCase() || "UNKNOWN"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Edit Button */}
                <div className="mt-8 flex justify-center">
                  {!editing && (
                    <Button
                      label="Edit Profile"
                      icon="pi pi-pencil"
                      className="p-button-sm p-button-outlined text-blue-600 border-blue-600 hover:bg-blue-50"
                      onClick={() => setEditing(true)}
                    />
                  )}
                </div>
              </>
            )}
          </Card>
        </div>
      </div>

      {/* Modal for Editing Profile */}
      <Dialog
        header="Edit Profile"
        visible={editing}
        // onHide={() => setEditing(false)}
        onHide={handleCancelEdit}
        dismissableMask
        style={{ width: "90vw", maxWidth: "500px" }}
      >
        <div className="space-y-3">
          <div className="flex flex-col items-center mb-4">
            <div className="relative">
              <img
                src={
                  formData.profile_image
                    ? URL.createObjectURL(formData.profile_image)
                    : adminDetails?.image || "/images/doctor1.webp"
                }
                alt="Profile Preview"
                className="rounded-full w-24 h-24 object-cover border-4 border-blue-100 cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              />
            </div>

            {/* Hidden file input */}
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>

          <div className="mb-4">
            <InputText
              className="w-full"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              placeholder="Full Name"
            />
          </div>

          <div className="mb-4">
            <InputText
              className="w-full"
              value={formData.email}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  email: e.target.value,
                })
              }
              placeholder="Email"
            />
          </div>

          <div className="mb-4">
            <InputMask
              className="w-full"
              mask="9999999999"
              value={formData.mobile || ""}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  mobile: e.value ?? "",
                })
              }
              placeholder="Mobile"
            />
          </div>

          <div className="mb-4">
            <div className="mb-4">
              <Calendar
                className="w-full"
                value={
                  formData.dob instanceof Date
                    ? formData.dob
                    : formData.dob
                    ? new Date(formData.dob)
                    : null
                }
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    dob: e.value as Date | null,
                  }))
                }
                dateFormat="yy-mm-dd"
                showIcon
                placeholder="Date of Birth"
                maxDate={new Date()}
              />
            </div>
          </div>

          <div className="flex gap-2 justify-center pt-2">
            <Button label="Save" icon="pi pi-check" onClick={handleSave} />
            <Button
              label="Cancel"
              icon="pi pi-times"
              className="p-button-secondary"
              // onClick={() => setEditing(false)}
              onClick={handleCancelEdit}
            />
          </div>
        </div>
      </Dialog>
    </>
  );
}
