import { useEffect, useRef, useState, type RefObject } from "react";
import { Button } from "primereact/button";
import { useNavigate } from "react-router-dom";
import { getRowsPerPageOptions } from "../../utils/paginationUtils";
import { Paginator, type PaginatorPageChangeEvent } from "primereact/paginator";
import { Card } from "primereact/card";
import { DataTable, type DataTableSortMeta } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Toast } from "primereact/toast";
import { convertUTCToTimeZone } from "../../utils/dateFormatter";
import type { Menu } from "primereact/menu";
import { useGlobalStore } from "../../store";
import { SupportService } from "../../service/Support/SupportService";
import type { SupportListData } from "../../service/Support/dto";
import { Avatar } from "primereact/avatar";
import { Image } from "primereact/image";

type MenuRef = RefObject<Menu | null>;

export default function SupportListPage() {
  const actionMenuRefs = useRef<MenuRef[]>([]);

  const toast = useRef<Toast | null>(null);
  const [firstRowIndex, setFirstRowIndex] = useState<number>(0);
  const [selectedPageSize, setSelectedPageSize] = useState<number>(50);
  const [loading, setLoading] = useState(false);
  const [globalFilter, setGlobalFilter] = useState<string>("");

  const [clinicsData, setSupportsData] = useState<SupportListData[]>([]);
  const [clinicsDataCount, setClinicsDataCount] = useState<number>(0);
  const [multiSortMeta, setMultiSortMeta] = useState<
    DataTableSortMeta[] | undefined
  >([]);

  const [selectedClinicData, setSelectedClinicData] =
    useState<SupportListData | null>(null);

  const [viewVisible, setViewVisible] = useState(false);
  const [selectedClinicUid, setSelectedClinicUid] = useState<string | null>(
    null
  );

  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  const { setHeaderName } = useGlobalStore();

  useEffect(() => {
    setHeaderName("Supports");
  }, []);

  /////// effects //////////////
  const fetchSupportListData = async () => {
    try {
      setLoading(true);
      const response = await SupportService.getSupportList(
        selectedPageSize,
        Math.floor(firstRowIndex / selectedPageSize) + 1,
        "Support",
        globalFilter.trim() ? globalFilter : undefined
      );

      if (response.status === 200) {
        setSupportsData(response.data);
        setClinicsDataCount(response.count || 0);
      } else {
        setSupportsData([]);
        setClinicsDataCount(0);
      }
    } catch (error) {
      console.error("Error in fetching clinic list data:", error);
      setSupportsData([]);
      setClinicsDataCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      // Only trigger search if at least 2 characters or filter is cleared
      if (globalFilter.trim().length >= 2 || globalFilter.trim().length === 0) {
        fetchSupportListData();
      }
    }, 500); // wait 500ms after typing stops

    // Cleanup if user keeps typing fast
    return () => clearTimeout(handler);
  }, [firstRowIndex, selectedPageSize, globalFilter]);

  ///// change event //////
  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setFirstRowIndex(event.first);
    setSelectedPageSize(event.rows);
  };

  const onSelectionChange = (e: { value: SupportListData }) => {
    setSelectedClinicData(e.value);
  };

  ////////// templates
  const supportImgTemplate = (support: SupportListData) => {
    const imageUrl = support.file_path || "/images/default-image.png";

    return (
      <div className="flex items-center">
        <Image
          src={imageUrl}
          alt="Support Image"
          preview
          imageClassName="rounded-lg object-cover"
          className="w-10 h-10"
          style={{ width: "40px", height: "40px" }}
        />
      </div>
    );
  };

  const statusTemplate = (support: SupportListData) => {
    return (
      <span
        className={`text-xs font-medium px-2 py-1 rounded-full ${
          support.status === "active"
            ? "bg-green-100 text-green-800"
            : "bg-gray-100 text-gray-600"
        }`}
      >
        {support.status?.toUpperCase() || "N/A"}
      </span>
    );
  };

  //   const statusToggleTemplate = (doctor: DoctorListData) => {

  //     return (
  //       <div className="flex items-center gap-2">
  //      <span
  //           className={`text-xs font-medium px-2 py-1 rounded-full ${
  //             normalizedStatus === "active"
  //               ? "bg-green-100 text-green-800"
  //               : "bg-gray-100 text-gray-600"
  //           }`}
  //         >
  //           {normalizedStatus.toUpperCase()}
  //         </span>
  //       </div>
  //     );
  //   };

  ///// handlers ///////
  const handleViewClick = (uid: string) => {
    setSelectedClinicUid(uid);
    setViewVisible(true);
  };
  const handleViewClose = (state: boolean) => {
    setViewVisible(state);
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          {/* <h2 className="text-2xl font-semibold text-gray-800">
            Dashboard Overview
          </h2> */}
          {/* <Button
          icon="pi pi-refresh"
          label="Refresh"
          className="p-button-sm p-button-outlined"
        /> */}
        </div>

        {/* DataTable Section */}
        <Card title="All Support" className="shadow-md">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="">
              {/* <label className="text-gray-600 ">Search</label> */}
              <InputText
                value={globalFilter}
                onChange={(e) => setGlobalFilter(e.target.value)}
                placeholder="Search by subject and doctor name"
                className="w-full mt-2"
              />
            </div>
          </div>

          <DataTable
            value={clinicsData || []}
            selection={selectedClinicData!}
            onSelectionChange={onSelectionChange}
            selectionMode="single"
            dataKey="uid"
            // rows={10}
            globalFilter={globalFilter}
            sortMode="multiple"
            scrollable
            // scrollHeight="400px"
            // scrollHeight="calc(100vh - 230px)"
            className="text-sm w-full "
            loading={loading!}
            multiSortMeta={multiSortMeta}
            onSort={(e) => {
              if (e.multiSortMeta !== null && e.multiSortMeta !== undefined) {
                setMultiSortMeta(e.multiSortMeta);
              }
              console.log(" multiSortMeta ===> ", multiSortMeta);
              console.log("dataTable sort data");
            }}
          >
            <Column field="id" header="#" sortable />
            <Column field="type" header="Type" sortable />

            <Column field="subject" header="Subject" sortable />
            <Column field="description" header="Description" sortable />
            <Column
              field="file_path"
              header="Image"
              body={supportImgTemplate}
              sortable
            />

            <Column field="doctor_name" header="Doctor" sortable />
            <Column
              field="status"
              header="Status"
              body={statusTemplate}
              sortable
            />
            {/* <Column
              header="Actions"
              body={actionTemplate}
              style={{ width: "80px" }}
            /> */}
          </DataTable>
          <div className="card">
            <Paginator
              first={firstRowIndex}
              rows={selectedPageSize}
              totalRecords={clinicsDataCount || 0}
              onPageChange={onPageChange}
              rowsPerPageOptions={getRowsPerPageOptions(clinicsDataCount || 0)}
            />
          </div>
        </Card>
      </div>
    </>
  );
}
