import React from "react";
import Login from "../components/login/Login";

export default function LoginPage() {
  const handleContinue = () => {
    alert("Redirect to Appointment Page");
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <div className="p-6 w-full max-w-sm">
        <Login visible={true} onHide={() => {}} onContinue={handleContinue} />
      </div>
    </div>
  );
}
