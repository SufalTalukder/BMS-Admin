export const GOOGLE_API_SECRET_KEY = {
  GOOGLE_API_KEY: "AIzaSyDd--5VOqNI7PnQK-ulYaHpKzzxjBjnqgM",
};
