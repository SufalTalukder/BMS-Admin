import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { useEffect, useRef, useState, type RefObject } from "react";
import { DashboardService } from "../../service/Dashboard/DashboardService";
import type { AdminDashboardStats } from "../../service/Dashboard/dto";
import { Avatar } from "primereact/avatar";
import { DataTable, type DataTableSortMeta } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputSwitch } from "primereact/inputswitch";
import { Toast } from "primereact/toast";
import { Paginator, type PaginatorPageChangeEvent } from "primereact/paginator";
import { getRowsPerPageOptions } from "../../utils/paginationUtils";
import { InputText } from "primereact/inputtext";
import { Menu } from "primereact/menu";
import React from "react";
import { ProgressSpinner } from "primereact/progressspinner";
import type { ClinicListData } from "../../service/Clinic/dto";
import { ClinicService } from "../../service/Clinic/ClinicService";
import { Tooltip } from "primereact/tooltip";
import { parseClinicAddress } from "../../utils/addressUtils";
import { useGlobalStore } from "../../store";
import { convertUTCToTimeZone } from "../../utils/dateFormatter";

type TemplateOptions = {
  rowIndex: number;
};
type MenuRef = RefObject<Menu | null>;

const ClinicListPage = () => {
  const actionMenuRefs = useRef<MenuRef[]>([]);

  const toast = useRef<Toast | null>(null);
  const [firstRowIndex, setFirstRowIndex] = useState<number>(0);
  const [selectedPageSize, setSelectedPageSize] = useState<number>(50);
  const [loading, setLoading] = useState(false);
  const [globalFilter, setGlobalFilter] = useState<string>("");

  const [clinicsData, setClinicsData] = useState<ClinicListData[]>([]);
  const [clinicsDataCount, setClinicsDataCount] = useState<number>(0);
  const [multiSortMeta, setMultiSortMeta] = useState<
    DataTableSortMeta[] | undefined
  >([]);

  const [selectedClinicData, setSelectedClinicData] =
    useState<ClinicListData | null>(null);

  const [viewVisible, setViewVisible] = useState(false);
  const [selectedClinicUid, setSelectedClinicUid] = useState<string | null>(
    null
  );

  const [dashboardStats, setDashboardStats] =
    useState<AdminDashboardStats | null>(null);
  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  const { setHeaderName } = useGlobalStore();

  useEffect(() => {
    setHeaderName("Clinics");
  }, []);

  /////// effects //////////////
  const fetchClinicListData = async () => {
    try {
      setLoading(true);
      const response = await ClinicService.getClinicList(
        selectedPageSize,
        Math.floor(firstRowIndex / selectedPageSize) + 1,
        globalFilter.trim() ? globalFilter : undefined
      );

      if (response.status === 200) {
        setClinicsData(response.data);
        setClinicsDataCount(response.count || 0);
      } else {
        setClinicsData([]);
        setClinicsDataCount(0);
      }
    } catch (error) {
      console.error("Error in fetching clinic list data:", error);
      setClinicsData([]);
      setClinicsDataCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      // Only trigger search if at least 2 characters or filter is cleared
      if (globalFilter.trim().length >= 2 || globalFilter.trim().length === 0) {
        fetchClinicListData();
      }
    }, 500); // wait 500ms after typing stops

    // Cleanup if user keeps typing fast
    return () => clearTimeout(handler);
  }, [firstRowIndex, selectedPageSize, globalFilter]);

  const fetchDashboardStats = async () => {
    try {
      setStatsLoading(true);
      const response = await DashboardService.getAdminDashboardStatsDetails();

      if (response.status === 200 && response.data) {
        setDashboardStats(response.data);
      } else {
        setDashboardStats(null);
        toast.current?.show({
          severity: "warn",
          summary: "Warning",
          detail: response.message || "Failed to fetch dashboard stats",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch dashboard stats",
        life: 3000,
      });
    } finally {
      setStatsLoading(false);
    }
  };
  useEffect(() => {
    fetchDashboardStats();
  }, []);

  ///// change event //////
  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setFirstRowIndex(event.first);
    setSelectedPageSize(event.rows);
  };

  const onSelectionChange = (e: { value: ClinicListData }) => {
    setSelectedClinicData(e.value);
  };

  ////////// templates
  const clinicTemplate = (clinic: ClinicListData) => {
    return (
      <div className="flex items-center gap-3">
        <Avatar
          image={clinic.image || undefined}
          label={!clinic.image ? clinic.name[0] : undefined}
          shape="circle"
          className="w-10 h-10 text-white bg-blue-500"
        />
        <span className="font-semibold">{clinic.name}</span>
      </div>
    );
  };

  const statusTemplate = (clinic: ClinicListData) => {
    return (
      <span
        className={`text-xs font-medium px-2 py-1 rounded-full ${
          clinic.status === "active"
            ? "bg-green-100 text-green-800"
            : "bg-gray-100 text-gray-600"
        }`}
      >
        {clinic.status?.toUpperCase() || "N/A"}
      </span>
    );
  };

  const actionTemplate = (
    rowData: ClinicListData,
    options: TemplateOptions
  ) => {
    const index = options.rowIndex;
    if (!actionMenuRefs.current[index]) {
      actionMenuRefs.current[index] = React.createRef();
    }

    const menuModel = [
      {
        label: "View",
        icon: "pi pi-eye",
        command: () => handleViewClick(rowData.uid),
      },
      // {
      //   label: "Delete",
      //   icon: "pi pi-trash",
      //   command: () => console.log("Delete clicked for ID:", rowData.uid),
      // },
    ];

    return (
      <>
        <Menu model={menuModel} popup ref={actionMenuRefs.current[index]} />
        <Button
          icon="pi pi-ellipsis-v"
          rounded
          text
          size="small"
          className="btnico text-black"
          onClick={(e) => actionMenuRefs.current[index]?.current?.toggle(e)}
          aria-haspopup
          aria-controls="popup_menu"
        />
      </>
    );
  };

  const addressTemplate_old = (rowData: ClinicListData) => {
    const preview = rowData.address?.split("\n")[0] || "N/A";

    return (
      <>
        <span
          id={`cred-${rowData.uid}`}
          style={{ cursor: "pointer", fontFamily: "monospace" }}
        >
          {preview.length > 30 ? preview.substring(0, 30) + "..." : preview}
        </span>
        <Tooltip
          target={`#cred-${rowData.uid}`}
          position="top"
          mouseTrack
          mouseTrackTop={10}
        >
          <pre
            style={{
              whiteSpace: "pre-wrap",
              margin: 0,
              fontFamily: "monospace",
            }}
          >
            {rowData.address}
          </pre>
        </Tooltip>
      </>
    );
  };

  const addressTemplate = (rowData: ClinicListData) => {
    const { displayAddress, fullAddress } = parseClinicAddress(rowData.address);

    const preview =
      displayAddress.length > 30
        ? displayAddress.substring(0, 30) + "..."
        : displayAddress;

    return (
      <>
        <span
          id={`cred-${rowData.uid}`}
          style={{ cursor: "pointer", fontFamily: "monospace" }}
        >
          {preview}
        </span>

        <Tooltip
          target={`#cred-${rowData.uid}`}
          position="top"
          mouseTrack
          mouseTrackTop={10}
        >
          <pre
            style={{
              whiteSpace: "pre-wrap",
              margin: 0,
              fontFamily: "monospace",
            }}
          >
            {fullAddress}
          </pre>
        </Tooltip>
      </>
    );
  };

  const registerDateTemplate = (doctor: ClinicListData) => {
    const formattedDate = convertUTCToTimeZone(
      doctor.created_at,
      doctor.time_zone
    );
    return <>{formattedDate}</>;
  };

  //   const statusToggleTemplate = (doctor: DoctorListData) => {

  //     return (
  //       <div className="flex items-center gap-2">
  //      <span
  //           className={`text-xs font-medium px-2 py-1 rounded-full ${
  //             normalizedStatus === "active"
  //               ? "bg-green-100 text-green-800"
  //               : "bg-gray-100 text-gray-600"
  //           }`}
  //         >
  //           {normalizedStatus.toUpperCase()}
  //         </span>
  //       </div>
  //     );
  //   };

  ///// handlers ///////
  const handleViewClick = (uid: string) => {
    setSelectedClinicUid(uid);
    setViewVisible(true);
  };
  const handleViewClose = (state: boolean) => {
    setViewVisible(state);
  };

  return (
    <>
      <Toast ref={toast} position="top-right" />

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          {/* <h2 className="text-2xl font-semibold text-gray-800">
            Dashboard Overview
          </h2> */}
          {/* <Button
          icon="pi pi-refresh"
          label="Refresh"
          className="p-button-sm p-button-outlined"
        /> */}
        </div>

        {/* DataTable Section */}
        <Card title="All Clinic" className="shadow-md">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="">
              {/* <label className="text-gray-600 ">Search</label> */}
              <InputText
                value={globalFilter}
                onChange={(e) => setGlobalFilter(e.target.value)}
                placeholder="Search by name"
                className="w-full mt-2"
              />
            </div>
          </div>

          <DataTable
            value={clinicsData || []}
            selection={selectedClinicData!}
            onSelectionChange={onSelectionChange}
            selectionMode="single"
            dataKey="uid"
            // rows={10}
            globalFilter={globalFilter}
            sortMode="multiple"
            scrollable
            // scrollHeight="400px"
            // scrollHeight="calc(100vh - 230px)"
            className="text-sm w-full "
            loading={loading!}
            multiSortMeta={multiSortMeta}
            onSort={(e) => {
              if (e.multiSortMeta !== null && e.multiSortMeta !== undefined) {
                setMultiSortMeta(e.multiSortMeta);
              }
              console.log(" multiSortMeta ===> ", multiSortMeta);
              console.log("dataTable sort data");
            }}
          >
            <Column field="id" header="#" sortable />
            <Column field="name" header="Name" body={clinicTemplate} />
            <Column
              field="address"
              header="Address"
              body={addressTemplate}
              sortable
            />
            <Column field="lat" header="Latitude" sortable />
            <Column field="lng" header="Longitude" sortable />
            <Column
              field="created_at"
              header="Register Date"
              body={registerDateTemplate}
              sortable
            />
            <Column field="created_by_name" header="created_by_name" sortable />
            <Column
              field="status"
              header="Status"
              body={statusTemplate}
              sortable
            />
            {/* <Column
              header="Actions"
              body={actionTemplate}
              style={{ width: "80px" }}
            /> */}
          </DataTable>
          <div className="card">
            <Paginator
              first={firstRowIndex}
              rows={selectedPageSize}
              totalRecords={clinicsDataCount || 0}
              onPageChange={onPageChange}
              rowsPerPageOptions={getRowsPerPageOptions(clinicsDataCount || 0)}
            />
          </div>
        </Card>
      </div>
    </>
  );
};

export default ClinicListPage;
