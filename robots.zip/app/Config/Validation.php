<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Validation\StrictRules\CreditCardRules;
use CodeIgniter\Validation\StrictRules\FileRules;
use CodeIgniter\Validation\StrictRules\FormatRules;
use CodeIgniter\Validation\StrictRules\Rules;

class Validation extends BaseConfig
{
    // --------------------------------------------------------------------
    // Setup
    // --------------------------------------------------------------------

    /**
     * Stores the classes that contain the
     * rules that are available.
     *
     * @var list<string>
     */
    public array $ruleSets = [
        Rules::class,
        FormatRules::class,
        FileRules::class,
        CreditCardRules::class,
    ];

    /**
     * Specifies the views that are used to display the
     * errors.
     *
     * @var array<string, string>
     */
    public array $templates = [
        'list'   => 'CodeIgniter\Validation\Views\list',
        'single' => 'CodeIgniter\Validation\Views\single',
    ];

    // --------------------------------------------------------------------
    // Rules
    // --------------------------------------------------------------------
    
    public array $verify_signup = [
        'name'     => 'required',
        'password'     => 'required|max_length[255]',
        'confirmPassword' => 'required|max_length[255]|matches[password]',
        'email'        => 'required|max_length[254]|valid_email|is_unique[user_accounts.email]',
        'mobileNo'        => 'required|is_unique[user_accounts.mobileNo]',
        'gender'     => 'required',
        'profileImage'     => 'required',

    ];

    public array $verify_login = [
         'password'     => 'required',
         'emailMobile'        => 'required', 
    ];

    public array $otp_verification = [
        'otp'     => 'required',
    ];

    public array $forgot_password = [
        'emailMobile'     => 'required',
    ];

    public array $update_password = [
        'password'     => 'required',
        'confirmPassword' => 'required|max_length[255]|matches[password]',
        'userId'     => 'required',
    ];


    public array $search_by_storeId = [
        'storeId'     => 'required',
    ];
        
}
