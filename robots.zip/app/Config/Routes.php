<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

//******BUYER Route********
$routes->post('/Buyer/signup', 'Buyer\BuyerController::signup');
$routes->post('/Buyer/login', 'Buyer\BuyerController::login');
$routes->post('/Buyer/send_otp', 'Buyer\BuyerController::send_otp');
$routes->post('/Buyer/otp-verification', 'Buyer\BuyerController::otp_verification');
$routes->post('/Buyer/forgot-password', 'Buyer\BuyerController::forgot_password');
$routes->post('/Buyer/update-password', 'Buyer\BuyerController::update_password');
$routes->get('/Buyer/get-user-details/(:any)', 'Buyer\BuyerController::get_user_details/$1');

$routes->post('/Buyer/category-list', 'Buyer\BuyerController::category_list');
$routes->post('/Buyer/store-list', 'Buyer\BuyerController::store_list');
$routes->post('/Buyer/store-details', 'Buyer\BuyerController::store_details');
$routes->post('/Buyer/product-list-storewise', 'Buyer\BuyerController::product_list_storewise');
$routes->post('/Buyer/product-details', 'Buyer\BuyerController::product_details');
$routes->post('/Buyer/my-profile', 'Buyer\BuyerController::my_profile');
$routes->post('/Buyer/edit-profile', 'Buyer\BuyerController::edit_profile');
$routes->post('/Buyer/refer-earn', 'Buyer\BuyerController::refer_earn');
$routes->post('/Buyer/payments', 'Buyer\BuyerController::payments');
$routes->post('/Buyer/privecy-policy', 'Buyer\BuyerController::privecy_policy');
$routes->post('/Buyer/store-offer', 'Buyer\BuyerController::store_offer');
$routes->post('/Buyer/top-banner', 'Buyer\BuyerController::top_banner');
$routes->post('/Buyer/deals-of-the-day', 'Buyer\BuyerController::deals-of-the-day');
$routes->post('/Buyer/recommended-for-you', 'Buyer\BuyerController::recommended-for-you');

//******SELLER Route********
$routes->post('/Seller/signup', 'Seller\SellerController::signup');
$routes->post('/Seller/login', 'Seller\SellerController::login');
$routes->post('/Seller/send_otp', 'Seller\SellerController::send_otp');