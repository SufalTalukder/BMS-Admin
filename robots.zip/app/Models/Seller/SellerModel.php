<?php
namespace App\Models\Seller;
use CodeIgniter\Model;

class SellerModel extends Model {

    public function save_user($data) {
      $inserted =  $this->db->table('user_accounts')->insert($data);
      //  return $this->db->insert('user_accounts', $data);
      return $inserted;
    }

    public function get_user_data_by_email($email) {
    
    $builder = $this->db->table('user_accounts');
    $builder->select('id , uId, email,password,mobileNo,userType,state');
    $builder->where('email', $email);
    $query = $builder->get();
      return $query->getRow();
    }

    public function save_otp($data) {
      $inserted =  $this->db->table('otp_list')->insert($data);
      //  return $this->db->insert('user_accounts', $data);
      return $inserted;
    }

    


}
?>