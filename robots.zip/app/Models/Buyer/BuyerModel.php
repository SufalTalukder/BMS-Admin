<?php
namespace App\Models\Buyer;
use CodeIgniter\Model;

class BuyerModel extends Model {

    public function save_user($data) {
      $inserted =  $this->db->table('user_accounts')->insert($data);
      //  return $this->db->insert('user_accounts', $data);
      return $inserted;
    }

    public function get_user_data_by_email_mobile($emailMobile) {    
      $sql = "select id , uId, email,password,mobileNo,userType,state  from `user_accounts` where 
      (`email`='".$emailMobile."' and `email`!='') or (`mobileNo`='".$emailMobile."' and `mobileNo`!='') ";
      $query = $this->db->query($sql)->getRow();;
      return $query;
    }

    public function save_otp($data) {
      $inserted =  $this->db->table('otp_list')->insert($data);
      //  return $this->db->insert('user_accounts', $data);
      return $inserted;
    }

    public function get_otp_data($otp) {    
      $sql = "select *   from `otp_list` where  `otp`='".$otp."' and `isVerify`='I' order by id desc limit 0,1  ";
      $query = $this->db->query($sql)->getRow();
      return $query;
    }

    public function update_otp_data($otp) {    
      $sql = "update `otp_list` set `isVerify`='V'  where  `otp`='".$otp."' and `isVerify`='I'    ";
      $query = $this->db->query($sql);
      return $query;
    }

    public function get_user_data_by_uId($uId) {    
      $sql = "select id , uId,name, email,password,mobileNo,userType,state  from `user_accounts` where `uId`='".$uId."'   ";
      $query = $this->db->query($sql)->getRow();
      return $query;
    } 
    
    public function save_password($password,$userId) {    
      $sql = "update `user_accounts` set   `password`='".$password."'  where `uId`='".$userId."'    ";
      $query = $this->db->query($sql);
      return $query;
    }
    

    public function get_category_list() {      
      $builder = $this->db->table('product_category');
      $builder->select(['uId as categoryId', 'name' , 'imageUrl', 'state']);
     // $builder->getWhere(['state' => 'ACTIVE']);
      $builder->where('state', 'ACTIVE');
      $query = $builder->get();      
      return $query->getResult();
    } 

    public function get_store_list() {      
      $builder = $this->db->table('store');
      $builder->select(['uId as storeId', 'name' , 'panNo', 'address','pinCode']);
     // $builder->getWhere(['state' => 'ACTIVE']);
      $builder->where('state', 'ACTIVE');
      $query = $builder->get();      
      return $query->getResult();
    } 
    
    public function get_store_details($storeId) {       
      $conditions = [
        'state' => 'ACTIVE',
        'uId' => $storeId,
       ];
      $builder = $this->db->table('store');
      $builder->select(['uId as storeId', 'name' , 'panNo', 'address','pinCode']);
      $builder->where($conditions);
      $query = $builder->get()->getRow();      
      return $query ;
    }
    

    public function get_product_list_storewise($storeId) {       
      $conditions = [
        'listingstatus' => 'ACTIVE',
        'storeId' => $storeId,
       ];
      $builder = $this->db->table('product');
      $builder->select(['uId as productId', 'name' , 'brandName', 'title','description','color','mrpPrice','sellingPrice']);
      $builder->where($conditions);
      $query = $builder->get()->getResult();      
      return $query ;
    }

}
?>