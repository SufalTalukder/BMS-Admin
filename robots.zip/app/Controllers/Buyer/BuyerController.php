<?php
namespace App\Controllers\Buyer;
use App\Controllers\Buyer\Common;
use App\Models\Buyer\BuyerModel;

class BuyerController extends Common
{
    
   
    public function signup() {
        $this->validation->setRuleGroup('verify_signup');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();           
            $BuyerModel=$this->init_BuyerModel();
            $uId=$this->GUID('USER');
            $postedData = $this->request->getPost();
            $refferalCode = $postedData['referralCode'];
            $profileImage = $postedData['profileImage'];
            $imageUrl = '';
            if (!empty($profileImage)) {
                $imageUrl = $this->upload_profile_image($profileImage, "assets/uploads/profile_image/");
             }
             $data = [
                "uId" => $uId,
                "name" => $valid_data['name'],
                "mobileNo" => $valid_data['mobileNo'],
                "email" => $valid_data['email'],
                "password" => md5($valid_data['password']),
                "userType" => 'BUYER',                
                "createdAt" => date("Y-m-d H:i:s"),
                "state" => 'ACTIVE',
                "referredReferralId" => $refferalCode,
                "gender" => $valid_data['gender'],
                "profileImageLink" => $imageUrl,
            ];
          
            $Buyer_data_saved = $BuyerModel->save_user($data);
            //print_r($Buyer_data_saved); die;
            if ($Buyer_data_saved) { 
                    $send_otp=$this->send_otp($uId);
                    $save_otp=$this->save_otp($uId);                
                   
                    $response = ["status" => true, "message" => "Login credentials Saved successfully.", "data"=>["otp" => $save_otp]];
                             
            }
            else {
                $response = ["status" => false, "message" => "User Data Not saved"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }



    public function login() {
        $this->validation->setRuleGroup('verify_login');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();            
            $BuyerModel=$this->init_BuyerModel();
            $emailMobile = $valid_data['emailMobile'];
            $user_data = $BuyerModel->get_user_data_by_email_mobile($emailMobile); 

            if (!empty($user_data)) { 
             if ($user_data->state === 'ACTIVE') {
                if (md5($valid_data['password']) == $user_data->password) {
                    $userId=$user_data->uId;
                    $send_otp=$this->send_otp($userId);
                    $save_otp=$this->save_otp($userId);
                   
                    $response = ["status" => true, "message" => "Login credentials verified successfully.", "data"=>["otp" => $save_otp]];
                }
                else {
                    $response = ["status" => false, "message" => "Password is wrong!"];
                }
            }
            else {
                $response = ["status" => false, "message" => "User Is not Active"];
            }
            
        }else {
            $response = ["status" => false, "message" => "Email Id Not Found"];
        }
    }

        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }




    public function send_otp($userId) {            
        $response = false;            
        ////send sms             
        $response = true;
        return $response;
      }




    public function save_otp($userId){
        $BuyerModel=$this->init_BuyerModel();
        $uId=$this->GUID('OTP');
        //$otp=rand(1000,9999);
        $otp=1234; 
        $data = [
            "uId" => $uId,
            "userId" => $userId,
            "otp" => $otp,
            "createdAt" => date("Y-m-d H:i:s"),
        ];           
        $otp_data_saved = $BuyerModel->save_otp($data);
         if ($otp_data_saved) { 
            $response = $otp;                
        }
        else {
            $response = 0;
        }
        return $response;
    }

    
    public function otp_verification(){
        $this->validation->setRuleGroup('otp_verification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();           
            $BuyerModel=$this->init_BuyerModel();
            $entered_otp=$valid_data['otp'];
           // 
            $otp_data = $BuyerModel->get_otp_data($entered_otp);
             if (!empty($otp_data)) { 
                $BuyerModel->update_otp_data($entered_otp);
                $response = ["status" => true, "message" => "User Verified" , "data" => ["userId"=>$otp_data->userId]];                
            }
            else {
                $response = ["status" => false, "message" => "OTP Data Not Found"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function forgot_password(){
        $this->validation->setRuleGroup('forgot_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();           
            $BuyerModel=$this->init_BuyerModel();
            $emailMobile = $valid_data['emailMobile'];
            $user_data = $BuyerModel->get_user_data_by_email_mobile($emailMobile);
            if (!empty($user_data)) { 
                if ($user_data->state === 'ACTIVE') {
                    $userId=$user_data->uId;
                    $send_otp=$this->send_otp($userId);
                    $save_otp=$this->save_otp($userId);                   
                    $response = ["status" => true, "message" => "Users Found.", "data"=>["otp" => $save_otp]];                
                }
                else {
                    $response = ["status" => false, "message" => "User Is not Active"];
                }
            
            }else {
            $response = ["status" => false, "message" => "User Not Found"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function update_password(){
        $this->validation->setRuleGroup('update_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();           
            $BuyerModel=$this->init_BuyerModel();
            $password = $valid_data['password'];  
            $userId = $valid_data['userId'];            
            $password = md5($password);                
             
             $password_data_saved = $BuyerModel->save_password($password,$userId);
                if ($password_data_saved) { 
                    $response = ["status" => true, "message" => 'Password Updated'];              
                 }
                else {
                    $response = ["status" => false, "message" => 'Password Not Updated']; 
                }
           
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    
    public function get_user_details($uId){
        $BuyerModel=$this->init_BuyerModel();
        $user_data = $BuyerModel->get_user_data_by_uId($uId); 
        if (!empty($user_data)) { 
           $uId=$user_data->uId;
           $name=$user_data->name;
           $email=$user_data->email; 
           $mobileNo=$user_data->mobileNo; 
           $userType=$user_data->userType; 
           $state=$user_data->state;                                
            $response = ["status" => true, "message" => "Users Found.", "data"=>["uId" => $uId,"name" => $name,"email" => $email,"mobileNo" => $mobileNo,"userType" => $userType,"state" => $state]];                
        
        
        }else {
        $response = ["status" => false, "message" => "uId Not Found"];
        }

        return $this->send_response($response, 200); 
    }


    public function upload_profile_image($imageString, $image_upload_directory) {
        $uploaded_image_path = NULL;
        if (!empty($imageString) && !empty($image_upload_directory))
        {
            $file_name=$this->GUID('PROFILE');
           // $file_extension = ".".pathinfo($image["name"], PATHINFO_EXTENSION);
           $file_extension = ".png";
            $file_save_path = $image_upload_directory.$file_name.$file_extension;
            $file_upload_path = FCPATH.$file_save_path;

               $data = base64_decode($imageString);
               // $im = imagecreatefromstring($data);
                // if ($im !== false) {
                //     header('Content-Type: image/png');
                //     imagepng($im);
                //     imagedestroy($im);
                // }

           // if (move_uploaded_file($im, $file_upload_path))
           if (file_put_contents($file_upload_path, $data))
            {
                $uploaded_image_path = $file_save_path;
            }
        }
        return $uploaded_image_path;
    }


    
    public function category_list(){
        $BuyerModel=$this->init_BuyerModel();
        $category_data = $BuyerModel->get_category_list(); 
        if (!empty($category_data)) {               
        $response = ["status" => true, "message" => "Data Found.", "data"=>$category_data]; 
        }else {
        $response = ["status" => false, "message" => "Data Not Found"];
        }
        return $this->send_response($response, 200); 
    }

    public function store_list(){
        $BuyerModel=$this->init_BuyerModel();
        $store_data = $BuyerModel->get_store_list(); 
        if (!empty($store_data)) {               
        $response = ["status" => true, "message" => "Data Found.", "data"=>$store_data]; 
        }else {
        $response = ["status" => false, "message" => "Data Not Found"];
        }
        return $this->send_response($response, 200); 
    }

    public function store_details(){
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel=$this->init_BuyerModel();
            $storeId = $valid_data['storeId'];
            $store_details = $BuyerModel->get_store_details($storeId);
            if (!empty($store_details)) {               
            $response = ["status" => true, "message" => "Data Found.", "data"=>$store_details]; 
            }else {
            $response = ["status" => false, "message" => "Data Not Found"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200); 
    }



    public function product_list_storewise(){
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel=$this->init_BuyerModel();
            $storeId = $valid_data['storeId'];
            $store_details = $BuyerModel->get_product_list_storewise($storeId);
            if (!empty($store_details)) {               
            $response = ["status" => true, "message" => "Data Found.", "data"=>$store_details]; 
            }else {
            $response = ["status" => false, "message" => "Data Not Found"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200); 
    }

}
