<?php
namespace App\Controllers\Seller;
use App\Controllers\Seller\Common;
use App\Models\Seller\SellerModel;

class SellerController extends Common
{
    
   
    public function signup() {
        $this->validation->setRuleGroup('verify_signup');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();           
            $SellerModel=$this->init_SellerModel();
            $uId=$this->GUID('USER');

            $data = [
                "uId" => $uId,
                "userName" => $valid_data['userName'],
                "mobileNo" => $valid_data['mobileNo'],
                "email" => $valid_data['email'],
                "password" => md5($valid_data['password']),
                "userType" => 'BUYER',                
                "createdAt" => date("Y-m-d H:i:s"),
                "state" => 'ACTIVE',
            ];
          
            $seller_data_saved = $SellerModel->save_user($data);
            //print_r($seller_data_saved); die;
            if ($seller_data_saved) { 
                $response = ["status" => true, "message" => "User Saved" , "uId" => $uId];                
            }
            else {
                $response = ["status" => false, "message" => "User Data Not saved"];
            }
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }



    public function login() {
        $this->validation->setRuleGroup('verify_login');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();            
            $SellerModel=$this->init_SellerModel();
            $email = $valid_data['email'];
            $user_data = $SellerModel->get_user_data_by_email($email);
           

            if (!empty($user_data)) {        
            if ($user_data->state === 'ACTIVE') {
                if (md5($valid_data['password']) == $user_data->password) {
                    $response = ["status" => true, "message" => "Login credentials verified successfully.", "uId" => $user_data->uId];
                }
                else {
                    $response = ["status" => false, "message" => "Password is wrong!"];
                }
            }
            else {
                $response = ["status" => false, "message" => "User Is not Active"];
            }
            
        }else {
            $response = ["status" => false, "message" => "Email Id Not Found"];
        }
    }

        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }




    public function send_otp() {

        $this->validation->setRuleGroup('send_otp');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated(); 
            $userId = $valid_data['uId'];
            $save_otp=$this->save_otp($userId);
            if($save_otp){
                /////send mobile sms statr here/////

                $response = ["status" => true, "message" => "OTP Saved" ]; 
            }else{
                $response = ["status" => false, "message" => "OTP Not saved"];
            }
           
        }
        else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);



    }




    public function save_otp($userId){
        $SellerModel=$this->init_SellerModel();
        $uId=$this->GUID('OTP');
        //$otp=rand(1000,9999);
        $otp=1234; 
        $data = [
            "uId" => $uId,
            "userId" => $userId,
            "otp" => $otp,
            "createdAt" => date("Y-m-d H:i:s"),
        ];           
        $otp_data_saved = $SellerModel->save_otp($data);
         if ($otp_data_saved) { 
            $response = true;                
        }
        else {
            $response = false;
        }
        return $response;
    }

    
    public function otp_verification(){



    }


}
