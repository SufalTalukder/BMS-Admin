<?php
namespace App\Controllers\Seller;
use CodeIgniter\RESTful\ResourceController;

class Common extends ResourceController {

    function __construct()
	{
        $this->validation = \Config\Services::validation();
        $this->input = \Config\Services::request();
	} 

public function send_response($data, $status_code) {
        return $this->response->setJSON($data)->setStatusCode($status_code);
    }
public function GUID($prefix = "") {
        if (function_exists('com_create_guid') === true)
        {
            return trim(com_create_guid(), '{}');
        }
    
        $unique_code = sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));

        if (!empty($prefix)) {
            return $prefix."_".$unique_code."_".time();
        }
        else {
            return $unique_code;
        }
    }


public function init_SellerModel(){
    $sellerModel=new \App\Models\Seller\SellerModel();
    return $sellerModel;
}

}