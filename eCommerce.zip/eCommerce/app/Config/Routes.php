<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->group('/', ['namespace' => 'App\Controllers'], function ($routes) {
    $routes->get('', function () {
        return redirect()->to('/admin/login');
    });
    $routes->get('/privacy-policy', 'Home::privacy_policy_view');
    $routes->get('/terms-and-conditions', 'Home::terms_and_conditions_view');
    $routes->get('/buyer-privacy-policy', 'Home::buyer_privacy_policy_view');
    $routes->get('/buyer-terms-and-conditions', 'Home::buyer_terms_and_conditions_view');
    #Forget Password Routes for any user . ...

});

$routes->group('admin', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
    $routes->get('', function () {
        return redirect()->to('/admin/login'); // Redirect to 'admin/login'
         });
    $routes->get('login', 'Auth::login_view');
    $routes->get('sign-out', 'Auth::sign_out');
    $routes->get('dashboard', 'Dashboard::dashboard_show');
    $routes->get('user', 'User::get_user_list_view');


    $routes->group('buyer', function ($routes) {
        $routes->get('', 'User::get_buyer_details_view');
        $routes->get('(:any)', 'User::get_buyer_details_by_id/$1');
    });

    $routes->group('seller', function ($routes) {
        $routes->get('notification', 'User::get_push_notification_view/$1');
        $routes->get('', 'User::get_seller_management_view');
        $routes->get('(:any)/product/(:any)', 'User::get_product_details_by_uid/$2/$1');
        $routes->get('(:any)/store/(:any)', 'User::get_store_details_by_uid/$2/$1');
        $routes->get('(:any)', 'User::get_seller_details_by_id/$1');
        $routes->get('notification', 'User::get_push_notification_view/$1');

    });

    $routes->group('product', function ($routes) {
        $routes->get('', 'BulkProduct::bulk_product_view');
        $routes->get('/request', 'Product::get_product_request_view');
        $routes->get('download/excel/format', 'BulkProduct::download_excel_format');
        $routes->get('detail/(:any)', 'BulkProduct::get_signal_product_details/$1');
        $routes->get('download/excel/data', 'BulkProduct::download_excel_data');
        $routes->post('upload/excel/file', 'BulkProduct::upload_excel_file');
        $routes->get('category', 'Product::get_product_category_list_view');
        $routes->get('type', 'Product::get_product_type_list_view');
        $routes->get('request', 'Product::get_product_request_view');
        
    });

    $routes->group('store', function ($routes) {
        $routes->get('offer', 'Store::get_store_offer_view');
        $routes->get('payment', 'Store::get_store_payment_view');
        $routes->get('referral/requests', 'Store::get_referral_requests_view');
        $routes->get('category', 'Store::get_store_category_view');
        $routes->get('', 'Store::get_store_list_view');
        $routes->get('(:any)', 'Store::get_store_detail_by_uid/$1');
    });

    $routes->group('chat', function ($routes) {
        $routes->get('(:any)', 'ChatController::get_chat_detail');
        $routes->get('', 'ChatController::get_customer_query_view');
        
    });
});

$routes->group('Seller', ['namespace' => 'App\Controllers'], function ($routes) {
    $routes->get('bulk', 'ExcelController::index');
    $routes->post('add-bulk-list', 'ExcelController::Product_Bulk_listStore');
});

// Admin Panel End `UI` ROUTES HERE 
//========================================================================================================//
//API's for admin panel 

$routes->post('login', 'Admin\Auth::login_authentication');
$routes->post('fetch/user', 'Admin\User::get_all_user');


$routes->group('/', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
    $routes->post('fetch/buyer', 'User::get_only_buyer_user');
    $routes->post('delete/buyer', 'User::delete_buyer_by_uId');
    $routes->post('fetch/seller', 'User::get_only_seller_user');
    $routes->get('/get-store-details-by-uid', 'User::get_single_seller_store_details');
    $routes->get('/get-store-product-details-by-uid', 'User::get_single_seller_store_product_details');
    $routes->post('delete/seller', 'User::delete_seller_by_uId');
});

$routes->group('/', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
    $routes->post('update-product-category', 'Product::update_product_category');
    $routes->post('add-product-category', 'Product::add_product_category');
    $routes->post('get-product-category', 'Product::get_product_category');
    $routes->get('edit-product-category', 'Product::get_product_category_by_uid');
    $routes->post('fetch/product-category', 'Product::get_all_product_category_list');
    $routes->post('delete-product-category', 'Product::delete_product_category');
    $routes->post('add-product-type', 'Product::add_product_type');
    $routes->post('edit-product-type', 'Product::get_product_type_by_uid');
    $routes->post('update-product-type', 'Product::update_product_type');
    $routes->post('fetch-product-type', 'Product::get_all_product_type_list');
    $routes->post('delete-product-type', 'Product::delete_product_type');
    $routes->post('product-toggle-status-change', 'Product::product_toggle_status_change');
    $routes->post('fetch/product', '\Product::get_all_product_list');
    $routes->post('delete/product', 'Product::product_delete');
});

$routes->group('/', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
    $routes->post('fetch/store-category', 'Store::get_store_category');
    $routes->get('/edit-category', 'Store::get_category_by_uid');
    $routes->post('/update-category', 'Store::update_category');
    $routes->post('/delete-category', 'Store::delete_category');
    $routes->post('delete/store', 'Store::delete_store_by_uId');
    $routes->post('delete/store-offer', 'Store::store_offer_delete');
});


// ===== End Admin Panel API's ROUTES Here ===== // 
//========================================================================================================//

$routes->group('api', ['namespace' => 'App\Controllers\Seller', 'filter' => 'SELLER_API_authentication'], function ($routes) {
    $routes->post('user-forget-password', 'SellerController::forget_password');
    $routes->post('forget-password-otp-validation', 'SellerController::forgot_password_otp_validation');
    $routes->post('update-password', 'SellerController::update_password');
    $routes->post('save-fcm-token', 'SellerController::save_fcm_token');
    $routes->get('friend-list', 'ChatApiController::getFriendList');
    $routes->get('chat-messages-list/(:any)', 'ChatApiController::getChatMessages/$1');
    $routes->post('send-message', 'ChatApiController::sendMessage');
    $routes->post('send-chat-request', 'ChatApiController::connect_buyer_seller_for_start_chat');
});


$routes->group('Seller', ['namespace' => 'App\Controllers\Seller', 'filter' => 'SELLER_API_authentication'], function ($routes) {
    // $routes->post('send-request', 'ChatApiController::send_friend_request');
    $routes->post('send-push-notification-to-buyer', 'ChatApiController::send_friend_request');
    $routes->post('send-push-notification', 'sendPushNotification::generateAccessToken');
});

$routes->group('Buyer', ['namespace' => 'App\Controllers\Buyer', 'filter' => 'API_authentication'], function ($routes) {
    $routes->post('signup', 'BuyerController::signup');
    $routes->post('login', 'BuyerController::login');
    $routes->post('send_otp', 'BuyerController::send_otp');
    $routes->post('otp-verification', 'BuyerController::otp_verification');
    $routes->post('forgot-password', 'BuyerController::forgot_password');
    $routes->post('update-password', 'BuyerController::update_password');
    $routes->get('get-user-details/(:any)', 'BuyerController::get_user_details/$1');
    $routes->post('product-category-list', 'BuyerController::product_category_list');
    $routes->get('store-list', 'BuyerController::store_list');
    $routes->post('store-details', 'BuyerController::store_details');
    $routes->post('get-store-referral-code', 'BuyerController::get_store_referral_code');
    $routes->post('product-list-storewise', 'BuyerController::product_list_storewise');
    $routes->post('store-offer', 'BuyerController::store_offer');
    $routes->post('product-details', 'BuyerController::product_details');
    $routes->post('my-profile', 'BuyerController::profile_detail');
    $routes->post('edit-profile', 'BuyerController::edit_profile');
    $routes->post('refer-earn', 'BuyerController::refer_earn');
    $routes->post('pay-bill', 'BuyerController::pay_bill');
    $routes->post('recent-transactions', 'BuyerController::recent_transactions');
    $routes->get('search', 'BuyerController::search');
    $routes->post('privecy-policy', 'BuyerController::privecy_policy');
    $routes->post('top-banner', 'BuyerController::top_banner');
    $routes->post('deals-of-the-day', 'BuyerController::deals_of_the_day');
    $routes->post('recommended-for-you', 'BuyerController::recommended_for_you');
    $routes->post('sign-out', 'BuyerController::sign_out');
    $routes->post('insert-buyer-banner', 'BuyerController::save_banner');
    $routes->post('banner-List', 'BuyerController::banner_list');
    $routes->post('add-product-favorites-list', 'BuyerController::add_product_favorites_list');
    $routes->post('product-list-from-favorites-list', 'BuyerController::favorites_list_product_list');
    $routes->post('remove-product-favorites-list', 'BuyerController::remove_product_favorites_list');
    $routes->post('save-user-location', 'BuyerController::save_user_location');
    $routes->post('popular-product', 'BuyerController::popular_product');
    $routes->post('similar-product', 'BuyerController::similar_product');
    $routes->post('store-drop-downlist', 'BuyerController::store_drop_downList');
    $routes->post('product-filter', 'BuyerController::product_filter');
    $routes->post('notify-me', 'BuyerController::notify_me');
    $routes->post('promo-code-cash-back', 'BuyerController::promo_code_case_back');

    $routes->post('store-near-by-location', 'BuyerController::calculation_nearest_store_location');
});


$routes->group('Seller', ['namespace' => 'App\Controllers\Seller', 'filter' => 'SELLER_API_authentication'], function ($routes) {
    $routes->post('delete-product', 'SellerController::delete_product');
    $routes->post('signup', 'SellerController::signup');
    $routes->post('signout', 'SellerController::seller_sign_out');
    $routes->post('login', 'SellerController::login');
    $routes->post('send-otp', 'SellerController::send_otp');
    $routes->post('otp-verification', 'SellerController::otp_verification');
    $routes->post('pan-card-upload', 'SellerController::document_upload');
    $routes->post('add-bank-account', 'SellerController::add_bank_account');
    $routes->post('add-new-product', 'SellerController::add_new_product');
    $routes->post('product-list', 'SellerController::product_list');
    $routes->post('my-profile', 'SellerController::my_profile');
    $routes->post('manage-offer', 'SellerController::manage_offer');
    $routes->post('add-offer', 'SellerController::add_offer');
    $routes->post('edit-offer', 'SellerController::edit_offer');
    $routes->post('product-request', 'SellerController::product_request');
    $routes->get('get-seller-referral-requests/(:any)', 'SellerController::get_seller_referral_requests/$1');
    $routes->post('create-seller-referral-reward', 'SellerController::create_seller_referral_reward');
    $routes->get('get-seller-referral-rewards-list/(:any)', 'SellerController::get_seller_referral_rewards_list/$1');

    $routes->post('all-payment', 'SellerController::all_payment');
    $routes->post('dashboard', 'SellerController::dashboard');
    $routes->post('saved-product-list', 'SellerController::saved_product_list');
    $routes->post('change-product-listing-status', 'SellerController::change_product_listing_status');
    $routes->post('add-store-details', 'SellerController::add_store_details');
    $routes->get('privecy-policy', 'SellerController::privecy_policy');
    $routes->post('create-push-notification', 'SellerController::create_push_notification');
    $routes->post('manage-push-notification', 'SellerController::manage_push_notification');
    $routes->get('get-push-notifications-list/(:any)', 'SellerController::get_push_notifications_list/$1');

    $routes->post('edit-push-notification', 'SellerController::edit_push_notification');
    $routes->post('delete-push-notification', 'SellerController::delete_push_notification');
    $routes->post('delete-store-offer', 'SellerController::delete_store_offer');
    $routes->put('deactivate-store-offer', 'SellerController::deactivate_store_offer');
    $routes->post('edit-user-profile', 'SellerController::edit_user_profile');
    $routes->post('update-user-profile', 'SellerController::update_user_profile');
    $routes->post('product-save-and-draft', 'SellerController::product_save_and_draft');
    $routes->post('user-online-status-change', 'SellerController::user_online_status_change');
    $routes->post('set-stock-status', 'SellerController::set_stock_status');
    $routes->post('save-new-product', 'SellerController::save_new_product');
    $routes->post('product-category-list', 'SellerController::product_category_list');
    $routes->post('product-type-list', 'SellerController::product_type_list');
    $routes->post('save-product-stock-status-change', 'SellerController::save_product_stock_status_change');
    $routes->post('save-product-listingStatus-change', 'SellerController::save_product_listingStatus_change');
    $routes->post('product-offer-list', 'SellerController::product_offer_list');
    $routes->post('get-country-list', 'SellerController::get_country_list');
    $routes->post('get-gst-list', 'SellerController::get_gst_list');
    $routes->post('update-profile', 'SellerController::update_profile');
    $routes->post('get-size', 'SellerController::get_size');
    $routes->post('edit-product', 'SellerController::edit_product');
    $routes->post('update-product', 'SellerController::update_product');
    $routes->post('upload-store-images', 'SellerController::upload_store_images');

    $routes->post('update-store-offers', 'SellerController::update_store_offers');
    $routes->put('activate-offers', 'SellerController::activate_offers');
    $routes->put('delete-all-push-notification', 'SellerController::deleteAll_push_notification');
    $routes->post('send-push-notification', 'SellerController::send_push_notification');
    $routes->post('get-product-storewise', 'SellerController::get_all_product_list');
    $routes->post('store-category-list', 'SellerController::store_category_list');
    $routes->post('delete-product-images', 'SellerController::delete_product_images');
    $routes->post('save-product-edit', 'SellerController::save_product_update');
    $routes->post('save-product-publish', 'SellerController::save_product_publish');
    $routes->post('get-store-category-list', 'SellerController::get_store_category_list');
    $routes->post('get-state-list', 'SellerController::get_state_list');
    $routes->post('get-city-list', 'SellerController::get_city_list_by_stateUid');
    $routes->post('send-again-push-notification', 'SellerController::send_again_push_notification');
    // $routes->post('send-push-notification-to-buyer', 'SellerController::send_friend_request');
    $routes->post('gst-number-validation', 'SellerController::user_gst_number_validation');
    $routes->post('only-for-product-image-upload', 'SellerController::only_for_product_image_upload');
});
