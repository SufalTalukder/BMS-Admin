<?php

namespace App\Controllers;

require_once APPPATH . 'Libraries/phpOffice/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
use CodeIgniter\Controller;
use App\Models\Admin\ProductModel;
//  use App\Controllers\Seller\Common ; 

class ExcelController extends Controller
{

    private function  GUID($prefix = "")
    {
        if (function_exists('com_create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }
        $unique_code = sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));

        if (!empty($prefix)) {
            return $prefix . "_" . $unique_code . "_" . time();
        } else {
            return $unique_code;
        }
    }

    public  function send_response($data, $status_code)
    {
        return $this->response->setJSON($data)->setStatusCode($status_code);
    }

    public function index()
    {
        try {

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setCellValue('A1', 'storeId');
            $sheet->setCellValue('B1', 'categoryId');
            $sheet->setCellValue('C1', 'typeId');
            $sheet->setCellValue('D1', 'name');
            $sheet->setCellValue('E1', 'brandName');
            $sheet->setCellValue('F1', 'listingstatus');
            $sheet->setCellValue('G1', 'title');
            $filename = 'ecomerceProudctExcelDataSheet.xlsx';
            $uploadPath = FCPATH . 'assets/uploads/excel/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $file_path = $uploadPath . $filename;
            $writer = new Xlsx($spreadsheet);
            $writer->save($file_path);
            echo "File created successfully at " . $file_path;
            return $this->response->download($file_path, null)->setFileName($filename);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setBody('Error: ' . $e->getMessage());
        }
    }
    public function Product_Bulk_listStore()
    {
        if (!$this->request->getFile('file')) {
            return $this->response->setStatusCode(400)->setBody('No file uploaded.');
        }

        $file = $this->request->getFile('file');
        if ($file->isValid() && !$file->hasMoved()) {
            $filePath = $file->getTempName();
            $spreadsheet = IOFactory::load($filePath);
            $data = $spreadsheet->getActiveSheet()->toArray();
            $productModel = new ProductModel();
            $response = ['status' => false, 'message' => 'No products were uploaded.'];
            foreach ($data as $index => $row) {
                if ($index === 0) {
                    continue; // Skip header
                }
                if (!empty($row[0]) && !empty($row[1])) {
                    $productId  = $this->GUID('PROD');
                    $offerId    = $this->GUID('P_OFFER');
                    $stockQty =  $row[12];
                    $stockStatus = ($stockQty > 0) ? 'ON' : 'OFF';
            
                    $productData = [
                        'uId'               => $productId,
                        'storeId'           => trim(str_replace(["\r", "\n"], ' ', $row[0])),
                        'categoryId'        => $row[1],
                        'typeId'            => $row[2],
                        'name'              => $row[3],
                        'brandName'         => $row[4],
                        'title'             => $row[5],
                        'description'       => $row[6],
                        'color'             => $row[7],
                        'availableSize'     => $row[8],
                        'idealFor'          => $row[9],
                        'mrpPrice'          => isset($row[10]) ? $row[10] : 0,
                        'sellingPrice'      => isset($row[11]) ? $row[11] : 0,
                        'stockQty'          => $stockQty,
                        'stock_status'      => $stockStatus,
                        'countryOfOrigin'   => isset($row[13]) ? $row[13] : null,
                        'manufacturerDetails' => isset($row[14]) ? $row[14] : null,
                        'hsnCode'           => isset($row[15]) ? $row[15] : null,
                        'gstPercent'        => isset($row[16]) ? $row[16] : null,
                        'createdAt'         => date('Y-m-d H:i:s'),
                    ];
            
                    $offerProductData = null; 
        
                    if (!empty($row[17])) {
                        $offerProductData = [
                            'uid'               => $offerId,
                            'prodId'            => $productId,
                            'storeId'          => $productData['storeId'],
                            'store_offer_id'    => $row[17],
                            'title'             => $row[18],
                            'description'       => $row[19],
                        ];
                    }
            
                    $bulkListSave = $productModel->saveProduct($productData);
            
                    if ($bulkListSave) {
                     
                        if ($offerProductData) {
                            $productModel->add_store_offer_By_addProduct($offerProductData);
                        }
                        $response['status'] = true; 
                        $response['message'] = 'Product Excel file uploaded successfully.';
                    } else {
                        $response['message'] = 'Failed to upload product. Please check your data.';
                    }
                }
            }

            return $this->send_response($response, 200);
        } else {
            // return $this->response->setStatusCode(500)->setBody('Error uploading file: ' . $file->getErrorString());
        }
    }

}
