<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class Product extends Common
{

    public function get_product_list_view()
    {
        $header['meta_title'] = 'Product | eCommerce';

        return view('admin/template/header', $header) .
            view('admin/template/sidebar') .
            view('admin/template/nav') .
            view('admin/product') .
            view('admin/template/footer');
    }
    public function get_product_category_list_view()
    {
        $header['meta_title'] = 'Product Category | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_PRODUCT_CATEGORY_MANAGEMENT;
        return view('admin/template/header', $header) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/product_category_list') .
            view('admin/template/footer');
    }
    public function get_product_type_list_view()
    {
        $header['meta_title'] = 'Product Type | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_PRODUCT_TYPE_MANAGEMENT;
        return view('admin/template/header', $header) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/product_type_list') .
            view('admin/template/footer');
    }

    public function get_all_product_list()
    {

        $productModel = $this->init_product_model();

        $get_product_list = $productModel->get_all_product_list();

        if ($get_product_list) {
            $response = ['status' => true, 'data' => $get_product_list];
        } else {
            $response = ['status' => false, 'message' => 'not found data'];
        }

        return $this->send_response($response, 200);
    }
    public function upload_image($image, $upload_directory_path, $user_uid)
    {
        $uploaded_image_path = NULL;
        if (!empty($image['tmp_name']) && !empty($upload_directory_path) && !empty($user_uid)) {
            $file_extension = pathinfo($image['name'], PATHINFO_EXTENSION);
            $file_name = $user_uid . '.' . $file_extension;
            $file_save_path = $upload_directory_path . $file_name;
            $file_upload_path = FCPATH . $file_save_path;
            if (move_uploaded_file($image['tmp_name'], $file_upload_path)) {
                $uploaded_image_path = $file_save_path;
            }
        }
        return $uploaded_image_path;
    }

    public function get_all_product_type_list()
    {
        $productModel = $this->init_product_model();
        $get_product_type_list = $productModel->get_product_type_list();
        if ($get_product_type_list) {
            $response = ['status' => true, 'data' => $get_product_type_list];
        } else {
            $response = ['status' => false, 'message' => 'Data not found '];
        }
        return $this->send_response($response, 200);
    }

    public function get_all_product_category_list()
    {
        $productModel = $this->init_product_model();
        $get_category_list = $productModel->get_product_category_list();
        if ($get_category_list) {
            $response = ['status' => true, 'data' => $get_category_list];
        } else {
            $response = ['status' => false, 'meassage' => 'Data not found'];
        }
        return $this->send_response($response, 200);
    }
    public function get_product_category_by_uid()
    {
        $uId = $this->request->getGet('uId');

        $productModel = $this->init_product_model();
        $get_category = $productModel->get_product_category_by_uid($uId);
        if (!empty($get_category)) {
            $response = ['status' => true, 'data' => $get_category];
        } else {
            $response = ['status' => false, 'message' => 'Not Found Any Category'];
        }
        return $this->send_response($response, 200);
    }

    public function add_product_category()
    {
        $categoryId = $this->GUID('CAT');
        $data = [
            'uId' => $categoryId,
            'name' => $this->request->getPost('name'),
            'createdAt' => date("Y-m-d H:i:s"),
        ];

        if (!empty($_FILES['categoryImage']['name'])) {
            $uploadedImageURL = $this->upload_image($_FILES['categoryImage'], 'assets/uploads/product_category/', $categoryId);
            if ($uploadedImageURL) {
                $data['imageUrl'] = $uploadedImageURL;
            }
        } else {
            $data['imageUrl'] = 'assets/uploads/Offer/no-image-found.png';
        }
        $Model = $this->init_product_model();
        $addCategory = $Model->addCategory($data);
        if (!empty($addCategory)) {
            $response = ['status' => true, 'message' => 'Product Category Add successfully .'];
        } else {
            $response = ['status' => false, 'message' => 'Product Category Not Add Please Try Again.'];
        }
        return $this->send_response($response, 200);
    }
    public function add_product_type()
    {
        $Model = $this->init_product_model();
        $typeId = $this->GUID('TYPE');
        $data = [
            'uId' => $typeId,
            'categoryId' => $this->request->getPost('categoryId'),
            'name' =>  $this->request->getPost('name'),
            'createdAt' => date("Y-m-d H:i:s"),
        ];
        if (!empty($_FILES['TypeImage']['name'])) {
            $uploadedImageURL = $this->upload_image($_FILES['TypeImage'], 'assets/uploads/product_category/', $typeId);
            if ($uploadedImageURL) {
                $data['imageUrl'] = $uploadedImageURL;
            }
        } else {
            $data['imageUrl'] = 'assets/uploads/Offer/no-image-found.png';
        }
        $SaveProductType = $Model->addProductType($data);
        if ($SaveProductType) {
            $response = ['status' => true, 'message' => 'Save SussecFully Product Type '];
        } else {
            $response = ['status' => false, 'message' => 'Not Save Your Data Please Try Again'];
        }
        return $this->send_response($response, 200);
    }

    public function get_product_category() // Drop Down For Product Type Form...
    {
        $Model = $this->init_product_model();
        $getProductCategory = $Model->get_product_category();
        if (!empty($getProductCategory)) {
            $response = ['status' => true, 'data' => $getProductCategory];
        } else {
            $response = ['status' => false, 'message' => 'Not Found Data .'];
        }
        return $this->send_response($response, 200);
    }

    public function get_product_type_by_uid()
    {

        $uId = $this->request->getPost('uId');
        $productModel = $this->init_product_model();
        $get_product_type = $productModel->get_product_type_by_uid($uId);
        if (!empty($get_product_type)) {
            $response = ['status' => true, 'data' => $get_product_type];
        } else {
            $response = ['status' => false, 'message' => 'Product Type Not Found ',];
        }
        return $this->send_response($response, 200);
    }

    public function update_product_type()
    {
        $newUid = $this->GUID('TYPE');
        $valid_data = $this->request->getPost();
        $uId  = $valid_data['uId'];

        $data = [
            'categoryId' => $valid_data['categoryId'],
            'name' => $valid_data['name'],
            'state' => PRODUCT_TYPE_STATE_ACTIVE,
            'updatedAt' => date('Y-m-d H:i:s')

        ];
        
        if (!empty($_FILES['images']['name'])) {
            $uploadedImageURL = $this->upload_image($_FILES['images'], 'assets/uploads/product_type/', $newUid);
            if ($uploadedImageURL) {
                $data['imageUrl'] = $uploadedImageURL;
            }
        }

        $productModel = $this->init_product_model();
        $update_product_type = $productModel->update_product_type($uId, $data);
        if (!empty($update_product_type)) {
            $response = ['status' => true, 'message' => 'Update SuccessFully', 'data' => $data];
        } else {
            $response = ['status' => false, 'Please Try Again Type Was Not Updated'];
        }
        return $this->send_response($response, 200);
    }
    public function delete_product_type()
    {
        $uId = $this->request->getPost('uId');
        $productModel = $this->init_product_model();
        $deleteProductType = $productModel->delete_product_type($uId);
        if ($deleteProductType) {
            $response = ['status' => true, 'message' => 'Type delete success fully'];
        } else {
            $response = ['status' => false, 'message' => 'Not Delete Try again'];
        }
        return $this->send_response($response, 200);
    }
    public function  update_product_category()
    {
        $valid_data = $this->request->getPost();
        $uId =  $valid_data['uId'];
        $newImageUid = $this->GUID('CAT');
        $data = [
            'name' => $valid_data['name'],
            'state' => PRODUCT_CATEGORY_STATE__ACTIVE,
            'updatedAt' => date('Y-m-d H:i:s')
        ];

        if (!empty($_FILES['image']['name'])) {
            $uploadedImageURL = $this->upload_image($_FILES['image'], 'assets/uploads/product_category/', $newImageUid);
            if ($uploadedImageURL) {
                $data['imageUrl'] = $uploadedImageURL;
            }
        }
        $productModel = $this->init_product_model();
        $updateProductCategory = $productModel->update_product_category($data, $uId);
        if ($updateProductCategory) {
            $response = ['status' => true, 'message' => 'Category update SuccessFully.'];
        } else {
            $response = ['status' => false, 'message' => 'Failed to update please try again .'];
        }
        return $this->send_response($response, 200);
    }
    public function delete_product_category()
    {
        $uId = $this->request->getPost('uId');
        $productModel = $this->init_product_model();
        $deleteProductCategory = $productModel->delete_product_category($uId);
        if ($deleteProductCategory) {
            $response = ['status' => true, 'message' => 'Category Deleted SuccessFully'];
        } else {
            $response = ['status' => false, 'message' => 'Failed to update '];
        }
        return $this->send_response($response, 200);
    }
    public function product_toggle_status_change()
    {

        $prodUid = $this->request->getPost('uId');
        $status = $this->request->getPost('status');
        $productModel = $this->init_product_model();
        $update = $productModel->update_product_status($prodUid, $status);

        if ($update) {
            $response = ['status' => true, 'message' => 'Product status updated successfully'];
        } else {
            $response = ['status' => false, 'message' => 'Failed to update product status'];
        }

        return $this->response->setJSON($response);
    }


    public function product_delete()
    {
        $productModel = $this->init_product_model();
        $uId = $_POST['uId'];

        $productDelete = $productModel->product_delete($uId);
        if ($productDelete) {
            $response = [
                "status" => true,
                "message" => "Product Deleted SuccessFully",

            ];
        } else {
            $response = [
                "status" => false,
                "message" => "Product Not Deleted !! ",

            ];
        }
        return $this->send_response($response, 200);
    }

    public function get_product_request_view()
    {
        $header['meta_title'] = 'Product Request | eCommerce';
        
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_PRODUCT_REQUEST;
        return view('admin/template/header', $header) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/product_request_view') .
            view('admin/template/footer');
    }
}
