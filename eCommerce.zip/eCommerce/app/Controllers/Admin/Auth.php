<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class Auth extends Common
{


    public function login_view()
    {
        $session = \Config\Services::session();

        if ($session->has('admin_logged_true') && $session->get('admin_logged_true') == true) {
            return redirect()->to('admin/buyer');
        }

        $header['meta_title'] = 'ADMIN LOGIN | eCommerce';
        return
            view('admin/template/header', $header) .
            view('admin/login_view') .
            view('admin/template/footer');
    }

    public function login_authentication()
    {
        $input = json_decode(
            $this->request->getBody(),
            true
        );

        $email = $input['email'];
        $password = $input['password'];
        if (empty($email)) {
            return $this->send_response([
                'status' => false,
                'message' => 'The email field is required.',
            ], 200);
        }
        if (empty($password)) {
            return $this->send_response([
                'status' => false,
                'message' => 'The password field is required.'
            ], 200);
        }
        $adminModel = $this->init_admin_model();
        $user = $adminModel->where(['email' => $email])->get()->getRow();
        if ($user) {
            if (password_verify($password, $user->password)) {
                $session = \Config\Services::session();
                $session_data = [
                    'admin_logged_true' => true,
                    'email' => $user->email
                ];
                $session->set($session_data);
                return $this->send_response(
                    ['status' => true, 'message' => 'User logged in'],
                    200
                );
            } else {
                return $this->send_response(
                    [
                        'status' => false,
                        'message' => 'Invalid email or password'
                    ],
                    200
                );
            }
        } else {
            return $this->send_response(
                [
                    'status' => false,
                    'message' => 'Invalid email or password'
                ],
                200
            );
        }
    }
    public function sign_out()
    {
        $session = session();
        $session->set('admin_logged_true', false);
        $session->remove('user');  // $session->destroy();
        return redirect()->to(base_url('admin/login'));
    }
}
