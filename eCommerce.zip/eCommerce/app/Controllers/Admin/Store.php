<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class Store extends Common
{

    public function get_store_list_view()
    {
        $header_date['meta_title'] = 'Store Manage | eCommerce  ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_STORE_MANAGE;
        $storeModel = $this->init_store_model();
        $data['store_list'] = $storeModel->get_store();

        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/store_view', $data) .
            view('admin/template/footer');
    }
    public function  get_store_detail_by_uid($storeId)
    {
        $header_date['meta_title'] = 'Store Details | eCommerce  ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_STORE_MANAGE;
        $storeModel  = $this->init_store_model();
        $data['store_details'] = $storeModel->get_store_detail_by_uid($storeId);
        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/store_details_view', $data) .
            view('admin/template/footer');
    }
    public function get_store_category_view()
    {

        $header_date['meta_title'] = 'Store Category | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_STORE_CATEGORY;
        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/store_category_view') .
            view('admin/template/footer');
    }

    public function get_store_type_view()
    {
        $header_date['meta_title'] = 'Store Type | eCommerce';
        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar') .
            view('admin/template/nav') .
            view('admin/store_type_view') .
            view('admin/template/footer');
    }


    public function get_store_category()
    {
        $storeModel = $this->init_store_model();

        $get_store_category = $storeModel->get_all_store_category();

        if ($get_store_category) {
            $response = ['status' => true, 'data' => $get_store_category];
        } else {
            $response = ['status' => false, 'message' => 'Data Not Found'];
        }

        return $this->send_response($response, 200);
    }

    public function add_store_category()
    {
        $this->validation->setRuleGroup('add_store_category');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();

            $storeModel = $this->init_store_model();
            $cateId = $this->GUID('CAT');
            $name = $valid_data['name'];
            $state = 'ACTIVE';
            $data = [
                'uId' => $cateId,
                'categoryName' => $name,
                'createdAt' => date('Y-m-d H:i:s'),
                'state' => $state,
            ];


            $addCategory = $storeModel->add_store_category($data);

            if ($addCategory) {
                $response = ['status' => true, 'message' => 'Category Added Successfully'];
            } else {
                $response = ['status' => true, 'message' => 'Not Inserted Category'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }
    public function get_category_by_uid()
    {
        $uId = $this->request->getGet('uId');

        $storeModel = $this->init_store_model();
        $get_category_by_uid = $storeModel->get_category_by_uid($uId);

        if ($get_category_by_uid) {
            $response = ['status' => true, 'data' => $get_category_by_uid];
        } else {
            $response = ['status' => false, 'message' => 'Data Not Found '];
        }

        return $this->send_response($response, 200);
    }
    public function update_category()
    {
        $uId = $this->request->getPost('uId');
        $categoryName = $this->request->getPost('categoryName');

        $data = [
            'uId'  => $uId,
            'categoryName' => $categoryName,
            'updatedAt'    => date('Y-m-d H:i:s')
        ];
        $storeModel = $this->init_store_model();
        $update_category = $storeModel->update_category($uId, $data);
        if ($update_category) {
            $response = ['status' => true, 'message' => 'Category Name Update Successfully '];
        } else {
            $response = ['status' => false, 'message' => 'Failed to Update Thank You '];
        }
        return $this->send_response($response, 200);
    }

    public function delete_category()
    {
        $post_data = $_POST;
        $cateId = $post_data['uId'];
        $storeModel = $this->init_store_model();
        $delete_category = $storeModel->delete_category($cateId);
        if ($delete_category) {
            $response = ['status' => true, 'message' => 'Category delete Successfully '];
        } else {
            $response = ['status' => false, 'message' => 'Something went wrong please Try again'];
        }
        return $this->send_response($response, 200);
    }



    public function get_store_payment_view()
    {
        $header_date['meta_title'] = 'Store Payment | eCommerce  ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_STORE_PAYMENT;
        $storeModel = $this->init_store_model();
        $data['store_payments'] = $storeModel->get_store_payment_details();
        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/store_payment_view', $data) .
            view('admin/template/footer');
    }
    public function get_referral_requests_view()
    {
        $header_date['meta_title'] = ' Referral Request | eCommerce  ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_REFERRAL_REQUEST;
        $storeModel = $this->init_store_model();
        $data['rereferral_requests'] = $storeModel->get_referral_requests_details();

        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/referral_requests_view', $data) .
            view('admin/template/footer');
    }
    public function delete_store_by_uId()
    {
        $uId  = $this->request->getPost('uId');
        $storeModel = $this->init_store_model();
        $deleteStore = $storeModel->delete_store_by_uId($uId);
        if ($deleteStore) {
            $response = ['status' => true, 'message' => 'Store Delete SuccussFully.'];
        } else {
            $response = ['status' => false, 'message' => 'Not Found'];
        }
        return $this->send_response($response, 200);
    }

    public function get_store_offer_view()
    {
        $header_date['meta_title'] = 'Store Offer | eCommerce  ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_STORE_OFFERS;
        $storeModel = $this->init_store_model();

        $data = ['store_offers' => $storeModel->get_store_offer_detail()];




        return view('admin/template/header', $header_date) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/store_offer_view', $data) .
            view('admin/template/footer');
    }

    public function store_offer_delete()
    {
        $storeModel = $this->init_store_model();
        $uId = $_POST['uId'];
        $deleteStoreOffer = $storeModel->store_offer_delete($uId);
        if (!empty($deleteStoreOffer)) {
            $response = [
                "status" => true,
                "message" => "Store Offer Delete SuccessFully",

            ];
        } else {
            $response = [
                "status" => false,
                "message" => "Not Delete Store Offer ",

            ];
        }
        return $this->send_response($response, 200);
    }
}
