<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class User extends Common
{

    public function get_user_list_view()
    {

        $header_data['meta_title'] = 'User Management | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_USER_MANAGEMENT;
        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/user_management') .
            view('admin/template/footer');
    }
    public function get_buyer_details_view()
    {
        $header_data['meta_title'] = 'User Management | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_USER_MANAGEMENT;

        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/buyer_management') .
            view('admin/template/footer');
    }
    public function get_seller_management_view()
    {

        $header_data['meta_title'] = ' Seller Management | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_SELLER_MANAGEMENT;
        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/seller_management') .
            view('admin/template/footer');
    }

    public function get_all_user()
    {

        $userModel = $this->init_user_model();

        $get_data = $userModel->get_all_user();

        if ($get_data) {
            $response = ['status' => true, 'data' => $get_data];
        } else {
            $response = ['status' => false, 'messsage' => 'data is not found '];
        }


        return $this->send_response($response, 200);
    }

    public function get_only_buyer_user()
    {

        $userModel = $this->init_user_model();

        $get_buyer = $userModel->get_only_buyer_user();

        if ($get_buyer) {
            $response = ['status' => true, 'data' => $get_buyer];
        } else {
            $response = ['status' => true, 'message' => 'User not found !!!'];
        }

        return $this->send_response($response, 200);
    }

    public function  get_buyer_details_by_id($uId)
    {
        $header_data['meta_title'] = ' Buyer Details | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_USER_MANAGEMENT;
        $Model = $this->init_user_model();
        $data['buyer'] = $Model->get_buyer_details_by_id($uId);
        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/buyer_details', $data) .
            view('admin/template/footer');
    }

    public function get_only_seller_user()
    {
        $userModel  = $this->init_user_model();

        $get_seller = $userModel->get_only_seller_user();

        if ($get_seller) {
            $response = ['status' => true, 'data' => $get_seller];
        } else {
            $response = ['status' => false, 'message' => 'Data Not Found'];
        }
        return $this->send_response($response, 200);
    }
    public function get_seller_details_by_id($userid)
    {
        $userModel = $this->init_user_model();
        $data['userid']      = $userid;
        $data['seller_info'] = $userModel->get_seller_by_uId($userid);

        $header_data['meta_title'] = ' Seller Details | eCommerce ';
        $sidebar_data['selected_option'] =  SIDEBAR_OPTION_SELLER_MANAGEMENT;
        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/seller_details', $data) .
            view('admin/template/footer');
    }

    public function get_single_seller_store_details()
    {
        if (!isset($_GET['userid']) || empty($_GET['userid'])) {
            echo "Error: userId not provided.";
            return;
        }
        $userid = $_GET['userid'];

        $userModel = $this->init_user_model();
        $get_data = $userModel->get_single_seller_store_details($userid);

        if (!empty($get_data)) {
            $response = ['status' => true, 'data' => $get_data];
        } else {
            $response = ['status' => false, 'message' => 'Data not Found'];
        }
        return $this->send_response($response, 200);
    }

    public function get_single_seller_store_product_details()
    {
        $userid = $_GET['userid'];

        $userModel = $this->init_user_model();

        $product   = $userModel->get_single_seller_store_product_details($userid);

        if ($product) {
            $response = ['status' => true, 'data' => $product];
        } else {
            $response = ['status' => false, 'message' => 'data is not found'];
        }
        return $this->send_response($response, 200);
    }

    public function get_product_details_by_uid($prodId, $userid)
    {
        $userModel = $this->init_user_model();

        $data['userid']      = $userid;
        $data['seller_info'] = $userModel->get_seller_by_uId($userid);
        $data['product'] = $userModel->get_product_details_by_uid($prodId);

        $header_data['meta_title'] = ' Seller Product Details | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_SELLER_MANAGEMENT;

        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/seller_product_details', $data) .
            view('admin/template/footer');
    }
    // 
    public function get_store_details_by_uid($storeid, $userid)
    {
        $Model = $this->init_user_model();
        $data['seller_info'] = $Model->get_seller_by_uId($userid);
        $data['store'] = $Model->get_store_details_by_uid($storeid);

        $header_data['meta_title'] = ' Seller Store Details | eCommerce ';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_SELLER_MANAGEMENT;

        return
            view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/seller_store_details', $data) .
            view('admin/template/footer');
    }
    public function delete_buyer_by_uId()
    {
        $uId = $this->request->getPost('uId');
        $userModel = $this->init_user_model();
        $deleteBuyer = $userModel->delete_buyer_by_uId($uId);
        if ($deleteBuyer) {
            $response = ['status' => true, 'message' => 'User Delete Sussecfully'];
        } else {
            $response = ['status' => false, 'message' => 'Not Found'];
        }
        return $this->send_response($response, 200);
    }

    public function delete_seller_by_uId()
    {
        $uId = $this->request->getPost('uId');
        $userModel = $this->init_user_model();
        $deleteBuyer = $userModel->delete_buyer_by_uId($uId);
        if ($deleteBuyer) {
            $response = ['status' => true, 'message' => 'Seller Details Delete Sussecfully'];
        } else {
            $response = ['status' => false, 'message' => 'Not Found'];
        }
        return $this->send_response($response, 200);
    }
    public function get_push_notification_view()
    {
        $get_push_notification = $this->db->table('push_notification')->orderBy('createdAt', 'DESC')->get()->getResult();
        $data = ['getPushNotifications' => $get_push_notification];
        $header_data['meta_title'] = ' Seller Push Notification | eCommerce ';
        $sidebar_data['selected_option'] =  SIDEBAR_OPTION_PUSH_NOTIFICATION;
        return  view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/push_notification', $data) .
            view('admin/template/footer');
    }
}
