<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class ChatController extends Common
{
    public function get_customer_query_view()
    {
        $header_data['meta_title'] = 'CUSTOMER QUERY | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_CUSTOMER_QUERY;

        // $chatModal = $this->init_chat_model();
        // $chatFriendModal = $this->init_chat_friend_model();

        $getFriendList = $this->db->table('chat AS CF  ')
            ->select('CF.chat_id , CF.created_at , CF.content AS message ,CF.status , UA.name AS userName , UA2.name AS friendName')
            ->join('user_accounts as UA', 'UA.uId = CF.sender_user_id', 'LEFT')
            ->join('user_accounts as UA2', 'UA2.uId = CF.receiver_user_id', 'LEFT')->orderBy('created_at' , 'DESC')->get()->getResult();
        $data  = ['FriendLists' => $getFriendList];


        return
            view('admin/template/header', $header_data) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/customer_query', $data) .
            view('admin/template/footer');
    }
    
    // public function get_chat_detail()
    // {
    //     $header_data['meta_title'] = 'CUSTOMER QUERY | eCommerce';
    //     $sidebar_data['selected_option'] = SIDEBAR_OPTION_CUSTOMER_QUERY;
    //     return
    //         view('admin/template/header', $header_data) .
    //         view('admin/template/sidebar', $sidebar_data) .
    //         view('admin/template/nav') .
    //         view('admin/customer_chat_view') .
    //         view('admin/template/footer');
    // }
}
