<?php

namespace App\Controllers\Admin;

require_once APPPATH . 'Libraries/phpOffice/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Controllers\Admin\Common;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx\ContentTypes;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;


class BulkProduct extends Common
{
    function bulk_product_view()
    {

        $header['meta_title'] = ' Product Management | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_PRODUCT_MANAGEMENT;
        $productModel = $this->init_product_model();
        $data['product'] = $productModel->get_product_details();
        return view('admin/template/header', $header) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/product', $data) .
            view('admin/template/footer');
    }

    public function get_signal_product_details($uId)
    {

        $productModel = $this->init_product_model();
        $productList['productList'] = $productModel->get_product_details_with_images($uId);
        $header['meta_title'] = 'Product Details | eCommerce';
        $sidebar_data['selected_option'] = SIDEBAR_OPTION_PRODUCT_MANAGEMENT;
        return view('admin/template/header', $header) .
            view('admin/template/sidebar', $sidebar_data) .
            view('admin/template/nav') .
            view('admin/product_details', $productList) .
            view('admin/template/footer');
    }

    public function download_excel_format()
    {
        try {
            $spreadsheet = new Spreadsheet();
            $activeWorksheet = $spreadsheet->getActiveSheet();


            $activeWorksheet->setCellValue('A1', 'storeId');
            $activeWorksheet->setCellValue('B1', 'categoryId');
            $activeWorksheet->setCellValue('C1', 'typeId');
            $activeWorksheet->setCellValue('D1', 'name');
            $activeWorksheet->setCellValue('E1', 'brandName');
            $activeWorksheet->setCellValue('F1', 'title');
            $activeWorksheet->setCellValue('G1', 'description');
            $activeWorksheet->setCellValue('H1', 'color');
            $activeWorksheet->setCellValue('I1', 'availableSize');
            $activeWorksheet->setCellValue('J1', 'mrpPrice');
            $activeWorksheet->setCellValue('K1', 'sellingPrice');
            $activeWorksheet->setCellValue('L1', 'stockQty');
            $activeWorksheet->setCellValue('M1', 'countryOfOrigin');
            $activeWorksheet->setCellValue('N1', 'manufacturerDetails');
            $activeWorksheet->setCellValue('O1', 'hsnCode');
            $activeWorksheet->setCellValue('P1', 'gstPercent');

            $headerRange = 'A1:P1';


            $activeWorksheet->getStyle($headerRange)->getFont()->setSize(15);
            $activeWorksheet->getStyle($headerRange)->getFont()->setColor(new Color('FFFFFF'));


            $activeWorksheet->getStyle($headerRange)->getFill()->setFillType(Fill::FILL_SOLID);
            $activeWorksheet->getStyle($headerRange)->getFill()->getStartColor()->setARGB('0000FF');

            $activeWorksheet->getColumnDimension('A')->setWidth(20);
            $activeWorksheet->getColumnDimension('B')->setWidth(20);
            $activeWorksheet->getColumnDimension('C')->setWidth(20);
            $activeWorksheet->getColumnDimension('D')->setWidth(30);
            $activeWorksheet->getColumnDimension('E')->setWidth(25);
            $activeWorksheet->getColumnDimension('F')->setWidth(30);
            $activeWorksheet->getColumnDimension('G')->setWidth(50);
            $activeWorksheet->getColumnDimension('H')->setWidth(15);
            $activeWorksheet->getColumnDimension('I')->setWidth(20);
            $activeWorksheet->getColumnDimension('J')->setWidth(20);
            $activeWorksheet->getColumnDimension('K')->setWidth(20);
            $activeWorksheet->getColumnDimension('L')->setWidth(20);
            $activeWorksheet->getColumnDimension('M')->setWidth(25);
            $activeWorksheet->getColumnDimension('N')->setWidth(25);
            $activeWorksheet->getColumnDimension('O')->setWidth(15);
            $activeWorksheet->getColumnDimension('P')->setWidth(15);

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="productExcelFormat.xlsx"');
            header('Cache-Control: max-age=0');

            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (\Exception $e) {
            echo "Error creating file: " . $e->getMessage();
        }
    }

    public function download_excel_data()
    {
        try {
            $productModel = $this->init_product_model();
            $products = $productModel->getProducts();
            $spreadsheet = new Spreadsheet();
            $activeWorksheet = $spreadsheet->getActiveSheet();
            $activeWorksheet->setCellValue('A1', 'ProductId');
            $activeWorksheet->setCellValue('B1', 'StoreId');
            $activeWorksheet->setCellValue('C1', 'CategoryId');
            $activeWorksheet->setCellValue('D1', 'TypeId');
            $activeWorksheet->setCellValue('E1', 'Name');
            $activeWorksheet->setCellValue('F1', 'BrandName');
            $activeWorksheet->setCellValue('G1', 'ListingStatus');
            $activeWorksheet->setCellValue('H1', 'Title');
            $activeWorksheet->setCellValue('I1', 'Description');
            $activeWorksheet->setCellValue('J1', 'Color');
            $activeWorksheet->setCellValue('K1', 'AvailableSize');
            $activeWorksheet->setCellValue('L1', 'IdealFor');
            $activeWorksheet->setCellValue('M1', 'MrpPrice');
            $activeWorksheet->setCellValue('N1', 'sellingPrice');
            $activeWorksheet->setCellValue('O1', 'StockQty');
            $activeWorksheet->setCellValue('P1', 'CountryOfOrigin');
            $activeWorksheet->setCellValue('Q1', 'ManufacturerDetails');
            $activeWorksheet->setCellValue('R1', 'HsnCode');
            $activeWorksheet->setCellValue('S1', 'GstPercent');

            $activeSheet = $spreadsheet->getActiveSheet();
            $activeSheet->getStyle('A:S')
                ->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)
                ->setVertical(Alignment::VERTICAL_CENTER);
            foreach (range('A', 'S') as $column) {
                $activeSheet->getColumnDimension($column)->setWidth(60);
            }
            $activeSheet->getRowDimension('1')->setRowHeight(26);
            $headerStyleArray = [
                'font' => [
                    'color' => ['rgb' => 'FFFFFF'],
                    'bold' => true,
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'rgb' => '0a86ed',
                    ],
                ],
                'borders' => [
                    'bottom' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => '000000'],
                    ],
                ],
            ];
            $activeSheet->getStyle('A1:S1')->applyFromArray($headerStyleArray);
            $row = 2;
            foreach ($products as $product) {
                $activeWorksheet->setCellValue('A' . $row, $product['uId']);
                $activeWorksheet->setCellValue('B' . $row, $product['storeId']);
                $activeWorksheet->setCellValue('C' . $row, $product['categoryId']);
                $activeWorksheet->setCellValue('D' . $row, $product['typeId']);
                $activeWorksheet->setCellValue('E' . $row, $product['name']);
                $activeWorksheet->setCellValue('F' . $row, $product['brandName']);
                $activeWorksheet->setCellValue('G' . $row, $product['listingstatus']);
                $activeWorksheet->setCellValue('H' . $row, $product['title']);
                $activeWorksheet->setCellValue('I' . $row, $product['description']);
                $activeWorksheet->setCellValue('J' . $row, $product['color']);
                $activeWorksheet->setCellValue('K' . $row, $product['availableSize']);
                $activeWorksheet->setCellValue('L' . $row, $product['idealFor']);
                $activeWorksheet->setCellValue('M' . $row, $product['mrpPrice']);
                $activeWorksheet->setCellValue('N' . $row, $product['sellingPrice']);
                $activeWorksheet->setCellValue('O' . $row, $product['stockQty']);
                $activeWorksheet->setCellValue('P' . $row, $product['countryOfOrigin']);
                $activeWorksheet->setCellValue('Q' . $row, $product['manufacturerDetails']);
                $activeWorksheet->setCellValue('R' . $row, $product['hsnCode']);
                $activeWorksheet->setCellValue('S' . $row, $product['gstPercent']);
                $row++;
            }
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="products.xlsx"');
            header('Cache-Control: max-age=0');
            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (\Exception $e) {
            session()->setFlashdata('error', 'Error creating file: ' . $e->getMessage());
            echo "Error creating file: " . $e->getMessage();
        }
    }

    public function upload_excel_file()
    {

        $headers = [
            'storeId',
            'categoryId',
            'typeId',
            'name',
            'brandName',
            'title',
            'description',
            'color',
            'availableSize',
            'mrpPrice',
            'sellingPrice',
            'stockQty',
            'countryOfOrigin',
            'manufacturerDetails',
            'hsnCode',
            'gstPercent',
        ];

        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == UPLOAD_ERR_OK) {
            $uploadFile = $_FILES['upload_file']['name'];
            $extension = pathinfo($uploadFile, PATHINFO_EXTENSION);

            if (in_array($extension, ['xlsx', 'xls'])) {
                $tempFilePath = $_FILES['upload_file']['tmp_name'];
                $destination = FCPATH . 'assets/uploads/excel/' . $uploadFile;

                if (move_uploaded_file($tempFilePath, $destination)) {
                    echo "File uploaded successfully.\n";

                    try {
                        $spreadsheet = IOFactory::load($destination);
                        $worksheet = $spreadsheet->getActiveSheet();
                        $data = [];
                        $headerRow = [];
                        foreach ($worksheet->getRowIterator(1, 1) as $row) {
                            $cellIterator = $row->getCellIterator();
                            $cellIterator->setIterateOnlyExistingCells(false);

                            foreach ($cellIterator as $cell) {
                                $headerRow[] = $cell->getValue();
                            }
                        }

                        if ($headerRow == $headers) {

                            foreach ($worksheet->getRowIterator(2) as $rowIndex => $row) {
                                $rowData = [];
                                $cellIterator = $row->getCellIterator();
                                $cellIterator->setIterateOnlyExistingCells(false);
                                foreach ($cellIterator as $cell) {

                                    $rowData[] = $cell->getValue();
                                    print_r($rowData);
                                }
                                $productId = $this->GUID('PROD');
                                $productData = [
                                    'uId' => $productId,
                                    'storeId' => trim(str_replace(["\r", "\n"], ' ', $rowData[0])),
                                    'categoryId' => $rowData[1],
                                    'typeId' => $rowData[2],
                                    'name' => $rowData[3],
                                    'brandName' => $rowData[4],
                                    'title' => $rowData[5],
                                    'description' => $rowData[6],
                                    'color' => $rowData[7],
                                    'availableSize' => $rowData[8],
                                    'mrpPrice' => isset($rowData[9]) ? $rowData[9] : 0,
                                    'sellingPrice' => isset($rowData[10]) ? $rowData[10] : 0,
                                    'stockQty' => isset($rowData[11]) ? $rowData[11] : 0,
                                    'stock_status' => ($rowData[11] > 0) ? 'ON' : 'OFF',
                                    'countryOfOrigin' => isset($rowData[12]) ? $rowData[12] : null,
                                    'manufacturerDetails' => isset($rowData[3]) ? $rowData[3] : null,
                                    'hsnCode' => isset($rowData[14]) ? $rowData[14] : null,
                                    'gstPercent' => isset($rowData[15]) ? $rowData[15] : 0,
                                    'createdAt' => date('Y-m-d H:i:s'),
                                ];
                                $productModel = $this->init_product_model();
                                $productModel->insert($productData);
                            }
                            session()->setFlashdata('success', 'Excel file uploaded and data imported successfully.');
                            header("Location:" . base_url('admin/product'));
                        } else {
                            session()->setFlashdata('error', 'Header mismatch in the uploaded file.');
                            return redirect()->to(base_url('admin/product'));
                        }
                    } catch (\Exception $e) {
                        session()->setFlashdata('error', 'Error reading Excel file: ' . $e->getMessage());
                        return redirect()->to(base_url('admin/product/upload/excel/file'));
                    }
                } else {
                    session()->setFlashdata('error', 'Failed to move uploaded file.');
                    return redirect()->to(base_url('admin/product'));
                }
            } else {
                session()->setFlashdata('error', 'Invalid file type. Please upload an Excel file..');
                return redirect()->to(base_url('admin/product'));
            }
        } else {
            session()->setFlashdata('error', 'Invalid file type. Please upload an Excel file..');
            return redirect()->to(base_url('admin/product'));
        }
    }
}
