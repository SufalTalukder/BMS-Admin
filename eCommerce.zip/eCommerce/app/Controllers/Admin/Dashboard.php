<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\Common;

class Dashboard extends Common
{

    public function dashboard_show()
    {

        return  view('admin/template/header') .
            view('admin/template/sidebar') .
            view('admin/template/nav') .
            view('admin/dashboard_view') .
            view('admin/template/footer');
    }
}
