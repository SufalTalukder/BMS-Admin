<?php

namespace App\Controllers\Buyer;

use App\Controllers\Buyer\Common;
use App\Models\Buyer\BuyerModel;

class BuyerController extends Common
{

    public function signup()
    {
        $this->validation->setRuleGroup('verify_signup');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $post_data = $this->request->getPost();
            $BuyerModel = $this->init_BuyerModel();

            if (!empty($post_data['referralCode'])) {
                $condition = ['uId' => $post_data['referralCode'], 'status' => 'PENDING'];
                $referral_request_details = $BuyerModel->get_referral_request_details($condition);
            }

            if (!empty($post_data['referralCode']) && !empty($referral_request_details)) {
                $referral_code_valid = true;
            } else if (!empty($post_data['referralCode']) && empty($referral_request_details)) {
                $referral_code_valid = false;
                $referral_error_message = "Referral Code is Invalid!";
            } else if (empty($post_data['referralCode'])) {
                $referral_code_valid = true;
            }

            if (!empty($post_data['referralCode']) && $referral_code_valid == false) {
                $response = ["status" => false, "message" => $referral_error_message];
            } else {
                $user_id = $this->GUID('USER');
                $password = password_hash($valid_data['password'], PASSWORD_DEFAULT);
                $data = [
                    'uId' => $user_id,
                    'name' => $valid_data['name'],
                    'mobileNo' => $valid_data['mobileNo'],
                    'email' => $valid_data['email'],
                    'password' => $password,
                    'userType' => 'BUYER',
                    'createdAt' => date("Y-m-d H:i:s"),
                    'state' => 'ACTIVE',
                    'ownReferralCode' => $this->generate_unique_referral_code(),
                    'referrerReferralCode' => (!empty($post_data['referralCode'])) ? $post_data['referralCode'] : NULL,
                    'gender' => $valid_data['gender']
                ];

                if (!empty($_FILES['profileImage'])) {
                    $profile_image_path = $this->upload_profile_image($user_id, $_FILES['profileImage']);
                    if (file_exists(FCPATH . $profile_image_path)) {
                        $data['profileImageLink'] = $profile_image_path;
                    }
                }

                $Buyer_data_saved = $BuyerModel->save_user($data);
                if ($Buyer_data_saved) {
                    if (!empty($referral_request_details)) {
                        $BuyerModel->update_referral_request_data([
                            'referredUserId' => $user_id,
                            'modifiedAt' => date('Y-m-d H:i:s'),
                            'status' => 'COMPLETE'
                        ], $condition);
                    }

                    $send_otp = $this->send_otp($user_id);
                    $save_otp = $this->save_otp($user_id);

                    $response = ["status" => true, "message" => "Login credentials Saved successfully.", "data" => ["otp" => $save_otp]];
                } else {
                    $this->delete_image($profile_image_path);
                    $response = ["status" => false, "message" => "User Data Not saved"];
                }
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function upload_profile_image($user_id, $profile_image)
    {
        $uploaded_image_path = NULL;
        $file_extension = pathinfo($profile_image['name'], PATHINFO_EXTENSION);
        $file_save_path = 'assets/uploads/profile_images/' . $user_id . '.' . $file_extension;
        $file_upload_path = FCPATH . $file_save_path;
        if (move_uploaded_file($profile_image['tmp_name'], $file_upload_path)) {
            $uploaded_image_path = $file_save_path;
        }

        return $uploaded_image_path;
    }

    public function delete_image($image_file_path)
    {
        return unlink(FCPATH . $image_file_path);
    }

    public function login()
    {
        $this->validation->setRuleGroup('verify_login');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $emailMobile = $valid_data['emailMobile'];
            $user_data = $BuyerModel->get_user_data_by_email_mobile($emailMobile);

            if (!empty($user_data)) {
                if ($user_data->state === STATE_ENUM_ACTIVE && $user_data->userType === USER_TYPE_BUYER) {
                    $password = $valid_data['password'];
                    if (password_verify($password, $user_data->password)) {
                        $userId = $user_data->uId;
                        // $send_otp = $this->send_otp($userId);
                        $save_otp = $this->save_otp($userId);

                        $response = ["status" => true, "message" => "Login credentials verified successfully.", "data" => ["otp" => $save_otp]];
                    } else {
                        $response = ["status" => false, "message" => "Password is wrong!"];
                    }
                } else {
                    $response = ["status" => false, "message" => "User Is not Active and please Login with buyer Account "];
                }
            } else {
                $response = ["status" => false, "message" => "Email Id Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    private function send_email_otp($email, $otp, $userName)
    {
        $emailService = service('email');
        $emailService->setFrom('u5459607@gmail.com', 'eCommerce Support Team');

        $emailService->setTo($email);
        $emailService->setSubject('Your OTP Code');

        $emailMessage = "Hello $userName,\n\n";
        $emailMessage .= "Your OTP for login is: $otp\n\n";
        $emailMessage .= "Thank you for using our service.\n\n";
        $emailMessage .= "Best regards,\n";
        $emailMessage .= "eCommerce Team";
        $emailService->setMessage($emailMessage);
        return $emailService->send();
    }

    public function send_otp($userId)
    {
        $response = false;
        ////send sms             
        $response = true;
        return $response;
    }

    public function save_otp($userId)
    {
        $SellerModel = $this->init_BuyerModel();
        $uId = $this->GUID('OTP');
        // $otp = rand(1000, 9999);
        $otp = 1234;
        $data = [
            "uId" => $uId,
            "userId" => $userId,
            "otp" => $otp,
            "createdAt" => date("Y-m-d H:i:s"),
            "isVerify" => 'I',
        ];
        $otp_data_saved = $SellerModel->save_otp($data);

        if ($otp_data_saved) {
            $userDetails = $SellerModel->get_user_account_data(['uId' => $userId]);
            if (filter_var($userDetails->email, FILTER_VALIDATE_EMAIL)) {
                $this->send_email_otp($userDetails->email, $otp, $userDetails->name);
            } else {
                $this->send_email_otp($userDetails->email, $otp, $userDetails->name);

                // $this->send_sms_otp($userDetails->mobileNo, $otp);
            }
            return $otp;
        } else {
            return 0;
        }
    }


    public function otp_verification()
    {
        $this->validation->setRuleGroup('otp_verification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $entered_otp = $valid_data['otp'];
            // 
            $otp_data = $BuyerModel->get_otp_data($entered_otp);
            if (!empty($otp_data)) {
                $BuyerModel->update_otp_data($entered_otp);
                $response = ["status" => true, "message" => "User Verified", "data" => ["userId" => $otp_data->userId]];
            } else {
                $response = ["status" => false, "message" => "OTP Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function forgot_password()
    {
        $this->validation->setRuleGroup('forgot_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $emailMobile = $valid_data['emailMobile'];
            $user_data = $BuyerModel->get_user_data_by_email_mobile($emailMobile);
            if (!empty($user_data)) {
                if ($user_data->state === 'ACTIVE') {
                    $userId = $user_data->uId;
                    $send_otp = $this->send_otp($userId);
                    $save_otp = $this->save_otp($userId);
                    $response = ["status" => true, "message" => "Users Found.", "data" => ["otp" => $save_otp]];
                } else {
                    $response = ["status" => false, "message" => "User Is not Active"];
                }
            } else {
                $response = ["status" => false, "message" => "User Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function update_password()
    {
        $this->validation->setRuleGroup('update_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $password = $valid_data['password'];
            $userId = $valid_data['userId'];
            $password = md5($password);

            $password_data_saved = $BuyerModel->save_password($password, $userId);
            if ($password_data_saved) {
                $response = ["status" => true, "message" => 'Password Updated'];
            } else {
                $response = ["status" => false, "message" => 'Password Not Updated'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function get_user_details($uId)
    {
        $BuyerModel = $this->init_BuyerModel();
        $user_data = $BuyerModel->get_user_data_by_uId($uId);
        if (!empty($user_data)) {
            $uId = $user_data->uId;
            $name = $user_data->name;
            $email = $user_data->email;
            $mobileNo = $user_data->mobileNo;
            $userType = $user_data->userType;
            $state = $user_data->state;
            $response = ["status" => true, "message" => "Users Found.", "data" => ["uId" => $uId, "name" => $name, "email" => $email, "mobileNo" => $mobileNo, "userType" => $userType, "state" => $state]];
        } else {
            $response = ["status" => false, "message" => "uId Not Found"];
        }

        return $this->send_response($response, 200);
    }

    public function upload_image($imageString, $image_upload_directory)
    {
        $uploaded_image_path = NULL;
        if (!empty($imageString) && !empty($image_upload_directory)) {
            $file_name = $this->GUID('PROFILE');
            // $file_extension = ".".pathinfo($image["name"], PATHINFO_EXTENSION);
            $file_extension = ".png";
            $file_save_path = $image_upload_directory . $file_name . $file_extension;
            $file_upload_path = FCPATH . $file_save_path;

            $data = base64_decode($imageString);
            // $im = imagecreatefromstring($data);
            // if ($im !== false) {
            //     header('Content-Type: image/png');
            //     imagepng($im);
            //     imagedestroy($im);
            // }

            // if (move_uploaded_file($im, $file_upload_path))
            if (file_put_contents($file_upload_path, $data)) {
                $uploaded_image_path = $file_save_path;
            }
        }
        return $uploaded_image_path;
    }

    public function product_category_list()
    {
        $BuyerModel = $this->init_BuyerModel();
        $category_data = $BuyerModel->get_category_list();
        if (!empty($category_data)) {
            $response = ["status" => true, "message" => "Product Category Lists .", "data" => $category_data];
        } else {
            $response = ["status" => false, "message" => "Data Not Found", "data" => []];
        }
        return $this->send_response($response, 200);
    }

    public function store_list()
    {
        try {
            $BuyerModel = $this->init_BuyerModel();
            $store_detail = $this->request->getVar('store_detail');
            $user_id = $this->request->getVar('user_id');
            $store_data = $BuyerModel->get_store_list($store_detail, $user_id);
            if (!empty($store_data)) {
                foreach ($store_data as $store) {
                    $getStoreImage = $this->db->table('store_image')->select('imageUrl AS StoreImage')->where('storeId', $store->storeId)->get()->getResult();
                    $store->images = array_map(function ($img) {
                        return base_url($img->StoreImage);
                    }, $getStoreImage);
                    $response = [
                        "status" => true,
                        "message" => "Store List.",
                        "data" => $store_data
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "No stores found.",
                    "data" => []
                ];
            }
            return $this->send_response($response, 200);
        } catch (\Exception $e) {

            print_r('error', $e->getMessage());
            return $this->send_response([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function store_details()
    {
        $this->validation->setRuleGroup('buyer_store_details');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $storeId = $valid_data['storeId'];
            $userId = $valid_data['userId'];
            $store_details = $BuyerModel->get_store_details($storeId, $userId);

            if (!empty($store_details)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $store_details];
            } else {
                $response = ["status" => false, "message" => "Data Not Found", "data" => []];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function product_list_storewise()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $storeId = $valid_data['storeId'];
            $store_details = $BuyerModel->get_product_list_storewise($storeId);
            if (!empty($store_details)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $store_details];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function store_offer()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $storeId = $valid_data['storeId'];
            $store_offer = $BuyerModel->get_store_offer($storeId);
            if (!empty($store_offer)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $store_offer];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function product_details()
    {
        $this->validation->setRuleGroup('search_by_productId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $productId = $valid_data['productId'];
            $userId = $valid_data['userId']; 
            $product_details = $BuyerModel->get_product_details($productId , $userId);
            // print_r($product_details); die;
            if (!empty($product_details)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $product_details];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function profile_detail()
    {
        $this->validation->setRuleGroup('search_by_userId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $userId = $valid_data['userId'];
            $user_details = $BuyerModel->get_user_details($userId);
            if (!empty($user_details)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $user_details];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function pay_bill()
    {
        $this->validation->setRuleGroup('pay_bill');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $uId = $this->GUID('PAY');
            $cashBackId = $this->GUID('CASH');

            $discount = 10;
            $discount_percentage = (!empty($discount)) ? $discount : 0;

            $payAmount = $valid_data['payAmount'];
            if ($discount_percentage > 0) {
                $discount = ($payAmount * $discount_percentage) / 100;
                $finalAmount = $payAmount - $discount;
            } else {
                $finalAmount = $payAmount;
            }

            $data = [
                "uId" => $uId,
                "cashBackId"  => $cashBackId,
                "storeId" => $valid_data['storeId'],
                "userId" => $valid_data['userId'],
                "payAmount" => $payAmount,
                "discount"  => $discount,
                "finalAmount"  => $finalAmount,
                "createdAt" => date("Y-m-d H:i:s"),
                "state" => 'ACTIVE',
            ];

            $save_payment_data = $BuyerModel->save_pay_amount($data);

            if ($save_payment_data) {
                $response = [
                    "status" => true,
                    "message" => "Data Inserted",
                    'data' => [
                        "payAmount" => $payAmount,
                        "CashBack" => $discount,
                        "finalAmount" => $finalAmount
                    ],
                    'payId' => [
                        'payId' => $uId,
                        'message' => "When Get to excess promoCode"
                    ],

                ];
            } else {
                $response = ["status" => false, "message" => "Data Not Inserted", 'data' => []];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function recent_transactions()
    {
        $this->validation->setRuleGroup('search_by_userId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();
            $userId = $valid_data['userId'];
            $recent_transactions = $BuyerModel->get_recent_transactions($userId);
            if (!empty($recent_transactions)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $recent_transactions];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function search()
    {
        $BuyerModel = $this->init_BuyerModel();
        $keyword = $this->request->getVar('keyword');
        if (!empty($keyword)) {
            $ProductSearch = $BuyerModel->search_product($keyword);
            if (!empty($ProductSearch)) {
                foreach ($ProductSearch as $product) {
                    $images = $this->db->table('product_image')
                        ->select('imageUrl')
                        ->where('prodId', $product->productId)
                        ->orderBy('createdAt', 'DESC')
                        ->get()
                        ->getResult();
                    $product->images = array_map(function ($img) {
                        return base_url($img->imageUrl);
                    }, $images);
                }
                $response = ["status" => true, "message" => "Data Found.", "data" => $ProductSearch];
            } else {
                $response = ["status" => false, "message" => "Data Not Found", "data" => []];
            }
        } else {
            $response = [
                "status" =>  false,
                "message" =>  "please add your Filter query",
                "data" => [],
            ];
        }
        return $this->send_response($response, 200);
    }

    public function get_store_referral_code()
    {
        $this->validation->setRuleGroup('get_store_referral_code');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $BuyerModel = $this->init_BuyerModel();

            $store_owner_data = $BuyerModel->get_user_data_by_store_id($valid_data['storeId']);
            if (!empty($store_owner_data)) {
                $user_data = $BuyerModel->get_user_data_by_uId($valid_data['userId']);
                if (!empty($user_data)) {
                    $referral_request_id = $this->generate_unique_referral_code(10);
                    $referral_request_data = [
                        'uId' => $referral_request_id,
                        'type' => $store_owner_data->userType,
                        'referralCode' => $store_owner_data->ownReferralCode,
                        'referrerUserId' => $user_data->uId,
                        'createdAt' => date('Y-m-d H:i:s'),
                        'modifiedAt' => date('Y-m-d H:i:s')
                    ];
                    // print_r($user_data); 

                    // print_r($store_owner_data); 
                    // print_r($referral_request_data);die ; 
                    $referral_request_added = $BuyerModel->add_new_referral_request($referral_request_data);

                    if ($referral_request_added) {
                        $response = ["status" => true, "message" => "Referral Code Get Successfully.", "referral_code" => $referral_request_id];
                    } else {
                        $response = ["status" => false, "message" => "Error Occurred! Failed to get referral code.", "referral_code" => ""];
                    }
                } else {
                    $response = ["status" => false, "message" => "User Account Details Not Found!"];
                }
            } else {
                $response = ["status" => false, "message" => "Store Owner Details Not Found!"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }
    public function edit_profile()
    {
        $this->validation->setRuleGroup('edit_buyer_profile');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $buyerModel =  $this->init_BuyerModel();
            $userId = $valid_data['userId'];
            $update_data = $this->request->getPost();
            $data = [
                'name'  => $update_data['name'],
                'email'  => $update_data['email'],
                'mobileNo' => $update_data['mobileNo'],
                'address' => $update_data['address'],
                'latitude'  => $update_data['latitude'],
                'longitude' => $update_data['longitude']
            ];
           
            if (!empty($_FILES['profileImage'])) {
                $profile_image_path = $this->upload_profile_image($userId, $_FILES['profileImage']);
                if (file_exists(FCPATH . $profile_image_path)) {
                    $data['profileImageLink'] = $profile_image_path;
                }
            }
            $updateProfile = $buyerModel->edit_profile($data, $userId);
            if (!empty($updateProfile)) {
                $response = ['status' => true, 'message' => 'Profile Updated SussesFully'];
            } else {
                $response = ['status' => false, 'message' => 'Please Try Again '];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }
    public function recommended_for_you()
    {
        $buyerModel = $this->init_BuyerModel();
        $userId = $this->request->getVar('userId');
        $productLists = $buyerModel->get_recommended_product_list();
        if (!empty($productLists)) {
            foreach ($productLists as $product) {
                $images = $this->db->table('product_image')
                    ->select('imageUrl')
                    ->where('prodId', $product->productId)
                    ->orderBy('createdAt', 'DESC')
                    ->get()
                    ->getResult();
                $product->images = array_map(function ($img) {
                    return base_url($img->imageUrl);
                }, $images);
            }
            $response = [
                'status' => true,
                'message' => 'Recommended Product List retrieved successfully.',
                'data' => $productLists
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'No recommended products found.',
                'data' =>  []
            ];
        }
        return $this->send_response($response, 200);
    }


    public function deals_of_the_day()
    {

        $buyerModel = $this->init_BuyerModel();
        $userId = $this->request->getVar('userId');
        $productLists = $buyerModel->deals_of_the_day();
        if (!empty($productLists)) {
            foreach ($productLists as $product) {
                $images = $this->db->table('product_image')
                    ->select('imageUrl')
                    ->where('prodId', $product->productId)
                    ->orderBy('createdAt', 'DESC')
                    ->get()
                    ->getResult();
                $product->images = array_map(function ($img) {
                    return base_url($img->imageUrl);
                }, $images);
            }
            $response = [
                'status' => true,
                'message' => 'Recommended Product List retrieved successfully.',
                'data' => $productLists
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'No recommended products found.',
                'data' =>  []
            ];
        }
        return $this->send_response($response, 200);
    }

    public function save_banner()
    {

        $bannerId = $this->GUID('BANNER');
        $image = $this->request->getFile('imagePath');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $uploadPath =  FCPATH . 'assets/uploads/banner/';
            // $newName = $bannerId . '.' . $image->getClientExtension(); 
            $newName = $bannerId;
            $image->move($uploadPath, $newName);
            $uploadedImagePath = 'assets/uploads/banner/' . $newName;
        } else {
            $uploadedImagePath = 'assets/uploads/Offer/no-image-found.png';
        }
        // Prepare data for database
        $data = [
            'uId' => $bannerId,
            'imagePath' => $uploadedImagePath,
        ];
        // Save to database (Example)
        $bannerModel = $this->init_BuyerModel();
        $saveBanner = $bannerModel->insert_banner($data);

        // Prepare Response
        if ($saveBanner) {
            $response = [
                'status' => true,
                'message' => 'Banner uploaded successfully.',
                'data' => $data,
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'Failed to upload banner.',
            ];
        }
        return $this->send_response($response, 200);
    }

    public function banner_list()
    {
        $buyerModel = $this->init_BuyerModel();
        $bannerList = $buyerModel->Banner_list();
        if (!empty($bannerList)) {
            $response = ['status' => true, 'message' => 'Banner List ', 'data' => $bannerList];
        } else {
            $response = ['status' => false, 'message' => 'Banner List Not Found !! ', 'data' => []];
        }
        return $this->send_response($response, 200);
    }

    public function sign_out()
    {

        $this->validation->setRuleGroup('buyer_sign_out');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            // $userId = $valid_data['userId'];
            //$this->db->table('user_accounts')->set('online_status', USER_STATUS_OFFLINE)->where('uId', $userId)->update();
            $userLogout = 1;
            if ($userLogout == 1) {
                $session = session();
                $session->destroy();
                $response =  ['status' => true, 'message' => 'Sign Out SuccessFully'];
            } else {
                $response = ['status' => false, 'message' => 'Please Try Again Something Went Wrong'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }
    public function add_product_favorites_list()
    {
        $this->validation->setRuleGroup('add_favorites_product');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $buyerModel = $this->init_BuyerModel();
            $uId = $this->GUID('FAV');

            $data = [
                'uId' => $uId,
                'userId' => $valid_data['userId'],
                'productId' => $valid_data['productId'],
                'storeId' => $valid_data['storeId'],
            ];

            $updateProductIsSaved = $this->db->table('product')->set('isSAved', true)->where('uId', $valid_data['productId'])->update();
            if ($updateProductIsSaved) {
                $existingFavorite = $buyerModel->get_favorite_by_product_user($valid_data['userId'], $valid_data['productId']);
                if ($existingFavorite) {
                    $response = ['status' => false, 'message' => 'Product is already in your favorites list'];
                } else {
                    $addFavoritesList = $buyerModel->add_product_favorites_list($data);
                    if (!empty($addFavoritesList)) {
                        $response = ['status' => true, 'message' => 'Item saved in favorites list'];
                    } else {
                        $response = ['status' => false, 'message' => 'Could not save, please try again'];
                    }
                }
            } else {
                $response = [
                    "status" =>  false,
                    "message" => "Not UPdate product ",
                    "data" => [],
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }
        return $this->send_response($response, 200);
    }
    public function favorites_list_product_list()
    {
        $this->validation->setRuleGroup('favorites_product_list');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $buyerModel = $this->init_BuyerModel();
            $userId  = $valid_data['userId'];
            $getFavoritesProductDetail = $buyerModel->get_favorites_product_by_user_id($userId);
            if (!empty($getFavoritesProductDetail)) {
                $response = ['status' => true, 'message' => 'Favorites Products List.', 'data' => $getFavoritesProductDetail];
            } else {
                $response = ['status' => false, 'message' => "Not any Product in list please select Product First", 'data' => []];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }
    public function remove_product_favorites_list()
    {
        $this->validation->setRuleGroup('remove_product_favorites_list');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $buyerModel = $this->init_BuyerModel();
            $conditions = [
                'userId' => $valid_data['userId'],
                'productId' => $valid_data['productId'],
                'storeId' => $valid_data['storeId']
            ];
            $updateProductFavList =  $this->db->table('product')->set('isSAved', false)->where('uId', $valid_data['productId'])->update();
            if ($updateProductFavList) {
                $removeProduct = $buyerModel->remove_product_favorites_list($conditions);
                if (!empty($removeProduct)) {

                    $response = ['status' => true, 'message' => 'Your Product Removed From favorite list '];
                } else {
                    $response = ['status' => false, 'message' => 'error occurred !!'];
                }
            } else {
                $response = ['status' => false, 'message' => 'not update error occurred !!'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }
    public function save_user_location()
    {
        $this->validation->setRuleGroup('save_user_location');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $userId = $valid_data['userId'];
            $data = [
                'address' => $valid_data['address'],
                'longitude' =>   $valid_data['longitude'],
                'latitude' => $valid_data['latitude'],
            ];

            $saveLocation = $this->db->table('user_accounts')->set($data)->where('uId', $userId)->update();
            if ($saveLocation) {
                $response = ['status' => true, 'message' => 'Your Current location are  Saved .'];
            } else {
                $response = ['status' => true, 'message' => 'Not Saved Please Try Again !!'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }

    public function popular_product()
    {
        try {
            $buyerModel = $this->init_BuyerModel();
            $similarProducts = $buyerModel->popular_product();
            if (!empty($similarProducts)) {
                foreach ($similarProducts as $product) {
                    $getProductImages = $this->db->table('product_image')
                        ->select('imageUrl')
                        ->where('prodId', $product->productId)
                        ->orderBy('createdAt', 'DESC')
                        ->get()
                        ->getResult();
                    $product->images = array_map(function ($img) {
                        return base_url($img->imageUrl);
                    }, $getProductImages);
                    $response = [
                        "status" => true,
                        "message" => "Popular Product List ",
                        "data" => $similarProducts,
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "Not found any similar product ",
                    "data" => [],
                ];
            }
            return $this->send_response($response, 200);
        } catch (\Exception $e) {

            log_message('error', $e->getMessage());
            return $this->send_response([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function similar_product()
    {
        try {
            $buyerModel = $this->init_BuyerModel();
            $similarProducts = $buyerModel->similar_product();
            if (!empty($similarProducts)) {
                foreach ($similarProducts as $product) {
                    $getProductImages = $this->db->table('product_image')
                        ->select('imageUrl')
                        ->where('prodId', $product->productId)
                        ->orderBy('createdAt', 'DESC')
                        ->get()
                        ->getResult();
                    $product->images = array_map(function ($img) {
                        return base_url($img->imageUrl);
                    }, $getProductImages);
                    $response = [
                        "status" => true,
                        "message" => "Similar Product List ",
                        "data" => $similarProducts,
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "Not found any similar product ",
                    "data" => [],
                ];
            }
            return $this->send_response($response, 200);
        } catch (\Exception $e) {

            log_message('error', $e->getMessage());
            return $this->send_response([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
    public function product_filter()
    {

        $response = [
            'status' => false,
            'message' => 'No filter data found.',
            'data' => []
        ];

        try {
            $brandQuery = $this->db->table('product')->select('DISTINCT(brandName) AS brand')->get()->getResultArray();
            $colorQuery = $this->db->table('product')->select('DISTINCT(color) AS color')->get()->getResultArray();
            $priceQuery = $this->db->table('product')->select('MIN(mrpPrice) AS min_price, MAX(mrpPrice) AS max_price')->get()->getRow();
            $productTypeQuery = $this->db->table('product_type')->select('id, name')->get()->getResultArray();
            $productDiscountQuery = $this->db->table('store_offer')->select('dicountType, discount')->get()->getResultArray();
            $brands = !empty($brandQuery) ? array_column($brandQuery, 'brand') : [];
            $colors = !empty($colorQuery) ? array_column($colorQuery, 'color') : [];
            $priceRange = ($priceQuery) ? ['min' => $priceQuery->min_price, 'max' => $priceQuery->max_price] : [];
            $productTypes = !empty($productTypeQuery) ? $productTypeQuery : [];
            $productDiscount = !empty($productDiscountQuery) ? $productDiscountQuery : [];
            $response = [
                'status' => true,
                'message' => 'Filters data fetched successfully.',
                'data' => [
                    'brands' => $brands,
                    'colors' => $colors,
                    'price_range' => $priceRange,
                    'product_types' => $productTypes,
                    'discount' => $productDiscount
                ]
            ];
        } catch (\Exception $e) {
            $response = [
                'status' => false,
                'message' => 'Error fetching filter data: ' . $e->getMessage(),
                'data' => []
            ];
        }
        return $this->send_response($response, 200);
    }
    public function notify_me()
    {
        $this->validation->setRuleGroup('notify_seller');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $REQuId = $this->GUID('REQ');
            $data = [
                'uId' => $REQuId,
                'userId' => $valid_data['userId'],
                'storeId' => $valid_data['storeId'],
                'productId' => $valid_data['productId']
            ];
            $saveNotifyMe = $this->db->table('customer_product_request')->insert($data);
            if (!empty($saveNotifyMe)) {
                $response = [
                    "status" => true,
                    "message" => "Send Product Request to Store Owner",
                ];
            } else {
                $response = [
                    "status" => false,
                    "message" => "Not send Please Try Again",
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }

    public function store_drop_downList()
    {
        try {
            $storeList = $this->db->table('store')->select('uId , name AS StoreName')->orderBy('createdAt', 'DESC')->get()->getResult();
            if (!empty($storeList)) {
                $response = [
                    "status" => true,
                    "message" => "Store Lists ",
                    "data" =>  $storeList,
                ];
            } else {
                $response = [
                    "status" => false,
                    "message" => "Not Found Any Stores ",
                    "data" => [],
                ];
            }
            return $this->send_response($response, 200);
        } catch (\Exception $e) {

            log_message('error', $e->getMessage());
            return $this->send_response([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function promo_code_case_back()
    {
        $input = $this->request->getPost();
        $promoCode = $input['promoCode'] ?? null;
        $payId = $input['payId'] ?? null;
        $storeId = $input['storeId'] ?? null;

        if (!$promoCode || !$payId || !$storeId) {
            $response = [
                "status" => false,
                "message" => "Missing required parameters.",
                "data" => []
            ];
            return $this->send_response($response, 200);
        }
        $promoCodeData = $this->db->table('promo_code')
            ->select('discountType, discount, created_at, endDate, status')
            ->where('promoCode', $promoCode)
            ->get()
            ->getRow();
        if (!$promoCodeData) {
            $response = [
                "status" => false,
                "message" => "Invalid promo code.",
                "data" => []
            ];
            return $this->send_response($response, 200);
        }
        if (!$promoCodeData->status == 'ACTIVE') {
            $response = [
                "status" => false,
                "message" => "Promo code expired or inactive.",
                "data" => []
            ];
            return $this->send_response($response, 200);
        }
        $billData = $this->db->table('store_payment')
            ->select('payAmount, finalAmount')
            ->where('uId', $payId)
            ->where('storeId', $storeId)
            ->get()
            ->getRow();

        if (!$billData) {
            $response = [
                "status" => false,
                "message" => "Payment record not found.",
                "data" => []
            ];
            return $this->send_response($response, 200);
        }

        $payAmount = $billData->finalAmount;



        $discount = 0;
        if ($promoCodeData->discountType === 'PERCENTAGE') {
            $discount = ($payAmount * $promoCodeData->discount) / 100;
        } elseif ($promoCodeData->discountType === 'FLAT') {
            $discount = $promoCodeData->discount;
        }


        $finalAmount = max(0, $payAmount - $discount);

        $response = [
            "status" => true,
            "message" => "Promo code applied successfully.",
            "data" => [
                "payAmount" => round($payAmount),
                "discount" => round($discount),
                "finalAmount" => round($finalAmount)
            ]
        ];
        return $this->send_response($response, 200);
    }

    public function calculation_nearest_store_location()
    {
        $this->validation->setRuleGroup('search_location');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $buyerModel = $this->init_BuyerModel();

            $searchLocation = $valid_data['searchLocation'];
            $userLat = $valid_data['latitude'];
            $userLng = $valid_data['longitude'];
            $radius = $valid_data['radius'];
            $result = $buyerModel->filter_stores_by_location($searchLocation, $userLat, $userLng, $radius);
            if (!empty($result)) {
                $response = [
                    "status" => true,
                    "message" => "Find  Location list",
                    "data" => $result,
                ];
            } else {
                $response = [
                    "status" => false,
                    "message" => "Not Exits any location ",
                    "data" => [],
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }
}
