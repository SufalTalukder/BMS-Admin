<?php

namespace App\Controllers\Buyer;

use CodeIgniter\RESTful\ResourceController;

class Common extends ResourceController
{

    protected $validation;
    protected $db;

    function __construct()
    {
        $this->validation = \Config\Services::validation();
        $this->request = \Config\Services::request();
        $this->db = \Config\Database::connect();
    }

    public function send_response($data, $status_code)
    {
        return $this->response->setJSON($data)->setStatusCode($status_code);
    }

    public function GUID($prefix = "")
    {
        if (function_exists('com_create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }

        $unique_code = sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));

        if (!empty($prefix)) {
            return $prefix . "_" . $unique_code . "_" . time();
        } else {
            return $unique_code;
        }
    }

    public function generate_unique_referral_code($length = 8)
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $charactersLength = strlen($characters);
        $referralCode = '';

        for ($i = 0; $i < $length; $i++) {
            $referralCode .= $characters[rand(0, $charactersLength - 1)];
        }

        return $referralCode;
    }

    public function init_BuyerModel()
    {
        $BuyerModel = new \App\Models\Buyer\BuyerModel();
        return $BuyerModel;
    }
}
