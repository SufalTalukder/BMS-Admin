<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }
    public function privacy_policy_view()
    {
        echo view('privacy_policy_view');
    }
    public function  terms_and_conditions_view()
    {
        echo view('terms_and_conditions_view');
    }
    public function buyer_privacy_policy_view()
    {
        echo view('buyer_privacy_policy_view');
    }
    public function buyer_terms_and_conditions_view()
    {
        echo view('buyer_terms_and_conditions_view');
    }
}
