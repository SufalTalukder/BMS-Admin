<?php

namespace App\Controllers\Seller;

use CodeIgniter\RESTful\ResourceController;

class Common extends ResourceController
{
    protected $current_datetime;
    protected $validation;
    protected $db;
    protected $input;
    function __construct()
    {
        $this->validation = \Config\Services::validation();
        $this->current_datetime = date('Y-m-d H:i:s');
        $this->input = \Config\Services::request();
        $this->db = \Config\Database::connect();
    }

    public function send_response($data, $status_code)
    {
        return $this->response->setJSON($data)->setStatusCode($status_code);
    }

    public function GUID($prefix = "")
    {
        if (function_exists('com_create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }

        $unique_code = sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));

        if (!empty($prefix)) {
            return $prefix . "_" . $unique_code . "_" . time();
        } else {
            return $unique_code;
        }
    }

    public function generate_unique_referral_code()
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $charactersLength = strlen($characters);
        $referralCode = '';

        for ($i = 0; $i < 8; $i++) {
            $referralCode .= $characters[rand(0, $charactersLength - 1)];
        }

        return $referralCode;
    }

    public function init_SellerModel()
    {
        $sellerModel = new \App\Models\Seller\SellerModel();
        return $sellerModel;
    }

    public function COUN($prefix = "")
    {
        if (function_exists('create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }

        $unique_code = sprintf(mt_rand(0, 65));

        if (!empty($prefix)) {
            return $prefix . "_" . $unique_code . "_" . time();
        } else {
            return $unique_code;
        }
    }

    public function init_ChatFriendModel()
    {
        $chatModel = new \App\Models\Seller\ChatFriendModel();
        return $chatModel;
    }
    public function init_ChatModel()
    {
        $chat = new \App\Models\Seller\ChatModel();
        return $chat;
    }
    public function init_userModel()
    {
        $user = new \App\Models\Seller\UserAccountModel();
        return $user;
    }
}
