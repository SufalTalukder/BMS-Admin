<?php

namespace App\Controllers\Seller;

use App\Controllers\Seller\Common;
use App\Models\Seller\SellerModel;

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

require_once(APPPATH . 'ThirdParty/firebase/php-jwt/src/JWT.php');
require_once(APPPATH . 'ThirdParty/firebase/php-jwt/src/Key.php');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


class SellerController extends Common
{

    function uploadFileToS3($fileName, $fileTempName)
    {
        $path = getenv('AWS_URL');
        $bucket = getenv('AWS_S3_BUCKET');
        $aws_region = getenv('AWS_REGION');
        $aws_key = getenv('AWS_KEY');
        $aws_secret = getenv('AWS_SECRET');
        try {
            $s3Client = new S3Client([
                'version' => 'latest',
                'region' => aws_region,
                'credentials' => [
                    'key' => aws_key,
                    'secret' => aws_secret,
                ],
            ]);

            // Generate a unique name for the file
            $filename_array = explode(".", $fileName);
            $file_name = $this->GUID('FILE');
            $file_extension = end($filename_array);
            $file_save_path = $file_name . "." . $file_extension;
            $image_path = $path . $file_save_path;

            $result = $s3Client->putObject([
                'Bucket' => $bucket,
                'Key' => $image_path,
                'SourceFile' => $fileTempName,
                'ACL' => 'public-read', // Adjust the ACL as needed
                'ContentDisposition' => 'inline',
                'ContentType' => mime_content_type($fileTempName)
            ]);

            return $result['ObjectURL'];
        } catch (Exception $error) {
            return "";
        }
    }

    public function signup()
    {
        $this->validation->setRuleGroup('verify_signup_seller');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $user_id = $this->GUID('USER');
            $data = [
                "uId" => $user_id,
                "name" => $valid_data['name'],
                "mobileNo" => $valid_data['mobileNo'],
                "email" => $valid_data['email'],
                "address" => $valid_data['address'],
                "password" => password_hash($valid_data['password'], PASSWORD_DEFAULT),
                "userType" => 'SELLER',
                'ownReferralCode' => $this->generate_unique_referral_code(),
                "createdAt" => date("Y-m-d H:i:s"),
                "state" => 'ACTIVE',
            ];

            if (!empty($_FILES['profileImage'])) {
                $profile_image_path = $this->upload_profile_image($user_id, $_FILES['profileImage']);
                if (file_exists(FCPATH . $profile_image_path)) {
                    $data['profileImageLink'] = $profile_image_path;
                }
            }

            $seller_data_saved = $SellerModel->save_user($data);
            if ($seller_data_saved) {
                $send_otp = $this->send_otp($user_id);
                $save_otp = $this->save_otp($user_id);
                $response = ["status" => true, "message" => "User Saved", "data" => ["otp" => $save_otp]];
            } else {
                $response = ["status" => false, "message" => "User Data Not saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function upload_profile_image($user_id, $profile_image)
    {
        $uploaded_image_path = NULL;
        $file_extension = pathinfo($profile_image['name'], PATHINFO_EXTENSION);
        $file_save_path = 'assets/uploads/profile_images/' . $user_id . '.' . $file_extension;
        $file_upload_path = FCPATH . $file_save_path;
        if (move_uploaded_file($profile_image['tmp_name'], $file_upload_path)) {
            $uploaded_image_path = $file_save_path;
        }

        return $uploaded_image_path;
    }

    public function delete_image($image_file_path)
    {
        return unlink(FCPATH . $image_file_path);
    }

    public function login()
    {
        $this->validation->setRuleGroup('verify_login');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $emailMobile = $valid_data['emailMobile'];

            if (filter_var($emailMobile, FILTER_VALIDATE_EMAIL)) {
                $user_data = $SellerModel->get_user_account_data(['email' => $emailMobile]);
            } else {
                $user_data = $SellerModel->get_user_account_data(['mobileNo' => $emailMobile]);
            }

            if (!empty($user_data)) {
                if ($user_data->state === STATE_ENUM_ACTIVE && $user_data->userType === USER_TYPE_SELLER) {
                    $password = $valid_data['password'];
                    if (password_verify($password, $user_data->password)) {
                        $userId = $user_data->uId;
                        $save_otp = $this->save_otp($userId);
                        if ($save_otp) {
                            $response = [
                                "status" => true,
                                "message" => "Login credentials verified successfully. Please check your email for OTP."
                            ];
                        } else {
                            $response = [
                                "status" => false,
                                "message" => "Failed to generate OTP. Please try again."
                            ];
                        }
                    } else {
                        $response = [
                            "status" => false,
                            "message" => "Password is incorrect!"
                        ];
                    }
                } else {
                    $response = [
                        "status" => false,
                        "message" => "User is not active and please Try with seller ID  ."
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "Email/Mobile not found."
                ];
            }
        } else {
            // Validation failed
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }


    public function send_otp()
    {
        $response = false;
        ////send sms             
        $response = true;
        return $response;
    }

    private function send_email_otp($email, $otp, $userName)
    {
        $emailService = service('email');
        $emailService->setFrom('u5459607@gmail.com', 'eCommerce Support Team');

        $emailService->setTo($email);
        $emailService->setSubject('Your OTP Code');

        $emailMessage = "Hello $userName,\n\n";
        $emailMessage .= "Your OTP for login is: $otp\n\n";
        $emailMessage .= "Thank you for using our service.\n\n";
        $emailMessage .= "Best regards,\n";
        $emailMessage .= "eCommerce Team";
        $emailService->setMessage($emailMessage);
        return $emailService->send();
    }

    private function send_sms_otp($mobileNo, $otp)
    {
        // Placeholder for SMS logic
        // Use your SMS gateway provider's API here to send the OTP
        return true;
    }


    public function for_save_otp($userId)
    {
        $SellerModel = $this->init_SellerModel();
        $uId = $this->GUID('OTP');
        // $otp = rand(1000, 9999);
        $otp = 1234;
        $data = [
            "uId" => $uId,
            "userId" => $userId,
            "otp" => $otp,
            "createdAt" => date("Y-m-d H:i:s"),
        ];
        $otp_data_saved = $SellerModel->save_otp($data);
        if ($otp_data_saved) {
            $response = $otp;
        } else {
            $response = 0;
        }
        return $response;
    }

    public function save_otp($userId)
    {
        $SellerModel = $this->init_SellerModel();
        $uId = $this->GUID('OTP');
        // $otp = rand(1000, 9999);
        $otp = 1234;
        $data = [
            "uId" => $uId,
            "userId" => $userId,
            "otp" => $otp,
            "createdAt" => date("Y-m-d H:i:s"),
            "isVerify" => 'I',
        ];
        $otp_data_saved = $SellerModel->save_otp($data);

        if ($otp_data_saved) {
            $userDetails = $SellerModel->get_user_account_data(['uId' => $userId]);
            if (filter_var($userDetails->email, FILTER_VALIDATE_EMAIL)) {
                $this->send_email_otp($userDetails->email, $otp, $userDetails->name);
            } else {
                $this->send_email_otp($userDetails->email, $otp, $userDetails->name);

                // $this->send_sms_otp($userDetails->mobileNo, $otp);
            }
            return $otp;
        } else {
            return 0;
        }
    }


    public function otp_verification()
    {
        $this->validation->setRuleGroup('otp_verification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            if (filter_var($valid_data['emailMobile'], FILTER_VALIDATE_EMAIL)) {
                $user_data = $SellerModel->get_user_account_data(['email' => $valid_data['emailMobile']]);
            } else {
                $user_data = $SellerModel->get_user_account_data(['mobileNo' => $valid_data['emailMobile']]);
            }

            if (!empty($user_data->uId)) {
                $otp_data = $this->db->table('otp_list')
                    ->where(['userId' => $user_data->uId, 'isVerify' => 'I'])
                    ->orderBy('createdAt', 'DESC')
                    ->get()->getRow();

                if (!empty($otp_data->otp)) {
                    if ($valid_data['otp'] == $otp_data->otp) {
                        $this->db->table('otp_list')
                            ->set('isVerify', 'V')
                            ->where('uId', $otp_data->uId)
                            ->update();

                        $stores_list = $SellerModel->get_stores_list_by_user_id($user_data->uId);
                        $data = [
                            "userId" => $user_data->uId,
                            "storeId" => (!empty($stores_list[0]->uId)) ? $stores_list[0]->uId : ""
                        ];
                        $response = ["status" => true, "message" => "User Authentication Successfull.", "data" => $data];
                    } else {
                        $response = ["status" => false, "message" => "OTP is Invalid!"];
                    }
                } else {
                    $response = ["status" => false, "message" => "OTP is Expired!"];
                }
            } else {
                $response = ["status" => false, "message" => "User account is not found!"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function add_store_details()
    {
        $SellerModel = $this->init_SellerModel();
        $this->validation->setRuleGroup('add_store');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $store_id = $this->GUID('STORE');
            $data = [
                "uId" => $store_id,
                "userId" => $valid_data['userId'],
                "gstNo" => $valid_data['gstNo'],
                "name" => $valid_data['name'],
                "description" => (!empty($_POST['description'])) ? $_POST['description'] : NULL,
                "storeCatId" => $valid_data['catId'],
                "panNo" => $valid_data['panNo'],
                "address" => $valid_data['address'],
                'latitude' => $valid_data['latitude'],
                'longitude' => $valid_data['longitude'],
                "pinCode" => $valid_data['pinCode'],
                "stateId" => $valid_data['stateId'],
                "cityId" => $valid_data['cityId'],
                "createdAt" => date('Y-m-d H:i:s'),
                "updatedAt" => date('Y-m-d H:i:s')
            ];

            if (!empty($_FILES['image'])) {
                $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $file_name = $store_id . '.' . $file_extension;
                $file_save_path = 'assets/uploads/store_images/' . $file_name;
                $file_upload_path = FCPATH . $file_save_path;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $file_upload_path)) {
                    $data["logoUrl"] = $file_save_path;
                }
            }
            $save_store = $SellerModel->save_store_details($data);
            if ($save_store) {
                $response = ["status" => true, "message" => "Store Details Saved", "data" => ["storeId" => $store_id]];
            } else {
                $response = ["status" => false, "message" => "Store Details Not saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function document_upload()
    {
        $SellerModel = $this->init_SellerModel();
        $this->validation->setRuleGroup('verify_seller_document');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $uId = $this->GUID('STORE');
            $docImage = $valid_data['docImage'];
            if (getenv('DOCUMENT_UPLOAD_TO') == 'LOCAL') {
                $imageUrl = $this->upload_base64_image($docImage, "assets/uploads/Document/");
            } else {
                $imgtemp_name = $valid_data["tmp_name"];
                $imageUrl = $this->uploadFileToS3($docImage, $imgtemp_name);
            }

            $data = [
                "uId" => $uId,
                "type" => $valid_data['type'],
                "variation" => $valid_data['variation'],
                "createdAt" => date('Y-m-d H:i:s'),
                "imgUrl" => $imageUrl,
                "state" => 'ACTIVE',
            ];
            $save_store = $SellerModel->save_document($data);
            if ($save_store) {
                $response = ["status" => true, "message" => "Store Details Saved"];
            } else {
                $response = ["status" => false, "message" => "Store Details Not saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function upload_image($image, $upload_directory_path)
    {
        $uploaded_image_path = NULL;
        if (!empty($image['name']) && !empty($upload_directory_path)) {
            $file_extension = pathinfo($image['name'], PATHINFO_EXTENSION);
            $file_name = $this->GUID('IMG') . '.' . $file_extension;
            $file_save_path = $upload_directory_path . $file_name;
            $file_upload_path = FCPATH . $file_save_path;
            if (move_uploaded_file($image['tmp_name'], $file_upload_path)) {
                $uploaded_image_path = $file_save_path;
            }
        }
        return $uploaded_image_path;
    }

    public function upload_base64_image($imageString, $image_upload_directory)
    {
        $uploaded_image_path = NULL;
        if (!empty($imageString) && !empty($image_upload_directory)) {
            $file_name = $this->GUID('DOC');
            $file_extension = ".png";
            $file_save_path = $image_upload_directory . $file_name . $file_extension;
            $file_upload_path = FCPATH . $file_save_path;
            $data = base64_decode($imageString);
            if (file_put_contents($file_upload_path, $data)) {
                $uploaded_image_path = $file_save_path;
            }
        }
        return base_url() . $uploaded_image_path;
    }

    // public function upload_product_images($product_id, $product_images)
    // {
    //     $seller_model = $this->init_SellerModel();
    //     foreach ($product_images['name'] as $i => $image_name) {
    //         $unique_image_ID = $this->GUID('IMG');
    //         $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
    //         $file_save_path = 'assets/uploads/product_images/' . $unique_image_ID . '.' . $file_extension;
    //         $file_upload_path = FCPATH . $file_save_path;
    //         if (move_uploaded_file($product_images['tmp_name'][$i], $file_upload_path)) {
    //             $seller_model->add_product_image([
    //                 'uId' => $unique_image_ID,
    //                 'prodId' => $product_id,
    //                 'imageUrl' => $file_save_path,
    //                 'createdAt' => date('Y-m-d H:i:s'),
    //                 'updatedAt' => date('Y-m-d H:i:s')
    //             ]);
    //         }
    //     }
    // }


    public function upload_update_product_images($productId, $product_images)
    {
        $seller_model = $this->init_SellerModel();
        foreach ($product_images['name'] as $i => $image_name) {
            $unique_image_ID = $this->GUID('IMG');
            $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
            $file_save_path = 'assets/uploads/product_images/' . $unique_image_ID . '.' . $file_extension;
            $file_upload_path = FCPATH . $file_save_path;
            if (move_uploaded_file($product_images['tmp_name'][$i], $file_upload_path)) {
                $seller_model->add_product_image([
                    'uId' => $unique_image_ID,
                    'prodId' => $productId,
                    'imageUrl' => $file_save_path,
                    'createdAt' => date('Y-m-d H:i:s'),
                    'updatedAt' => date('Y-m-d H:i:s')
                ]);
            }
        }
    }

    public function upload_save_product_images($save_id, $product_images)
    {
        $seller_model = $this->init_SellerModel();


        if (isset($product_images['name']) && is_array($product_images['name'])) {
            foreach ($product_images['name'] as $i => $image_name) {
                $unique_image_ID = $this->GUID('IMG');
                $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
                $file_save_path = 'assets/uploads/product_images/' . $unique_image_ID . '.' . $file_extension;
                $file_upload_path = FCPATH . $file_save_path;
                if (is_uploaded_file($product_images['tmp_name'][$i])) {
                    if (move_uploaded_file($product_images['tmp_name'][$i], $file_upload_path)) {
                        $image_data = [
                            'uId' => $unique_image_ID,
                            'savePid' => $save_id,
                            'imageUrl' => $file_save_path,
                            'createAt' => date('Y-m-d H:i:s'),
                            // 'updateAt' => date('Y-m-d H:i:s')
                        ];
                        $seller_model->save_product_images($image_data);
                    } else {
                        echo "Failed to move uploaded file: " . $image_name . "<br>";
                    }
                } else {
                    echo "Temporary file not found or not valid: " . $product_images['tmp_name'][$i] . "<br>";
                }
            }
        } else {
            echo "No files uploaded or invalid file format.";
        }
    }

    private function validate_ifsc_code($ifsc_code)
    {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => 'https://ifsc.razorpay.com/' . $ifsc_code,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_MAXREDIRS => 10,
        ));

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            return json_decode($response, true);
        } else {
            return null;
        }
    }


    public function add_bank_account()
    {
        $SellerModel = $this->init_SellerModel();
        $this->validation->setRuleGroup('add_bank_account');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $custom_key = getenv('CUSTOM_KEY');
            $initialization_vector = getenv('INITIALIZATION_VECTOR');
            $pattern = "/^[A-Z]{4}0[A-Z0-9]{6}$/";
            $ifsc_code = $valid_data['ifscCode'];
            if (preg_match($pattern, $ifsc_code)) {
                $ifsc_data = $this->validate_ifsc_code($ifsc_code);
                if ($ifsc_data) {
                    $accountDetails = [
                        "accountHolderName" => $valid_data['accountHolderName'],
                        "accountNumber" => $valid_data['accountNumber'],
                        "ifscCode" => $ifsc_code,
                    ];
                    $accountDetailsJson = json_encode($accountDetails);
                    $accDetails = openssl_encrypt($accountDetailsJson, "aes-256-cbc", $custom_key, 0, $initialization_vector);
                    $uId = $this->GUID('ACC');
                    $data = [
                        "uId" => $uId,
                        "userId" => $valid_data['userId'],
                        "accDetails" => $accDetails,
                        "createdAt" => date('Y-m-d H:i:s'),
                        "state" => "ACTIVE",
                    ];
                    $saveBankDetail = $SellerModel->save_bank_details($data);
                    if ($saveBankDetail) {
                        $response = ["status" => true, "message" => "Bank Details Saved", "ifscDetails" => $ifsc_data,];
                    } else {
                        $response = ["status" => false, "message" => "Bank Details Not saved"];
                    }
                } else {
                    $response = ['status' => false, 'message' => 'Invalid IFSC code. Unable to verify.'];
                }
            } else {
                $response = ['status' => false, 'message' => 'Invalid IFSC code format.'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function add_new_product()
    {

        $SellerModel = $this->init_SellerModel();
        $this->validation->setRuleGroup('add_new_product');

        if ($this->validation->withRequest($this->request)->run()) {
            $postedData = $this->request->getPost();
            $product_id = $this->GUID('PROD');
            $offerId = $this->GUID('P_OFFER');

            $stockQty = $postedData['stockQty'];
            $stockStatus = ($stockQty > 0) ? 'ON' : 'OFF';

            $data = [
                "uId" => $product_id,
                "storeId" => $postedData['storeId'],
                "categoryId" => $postedData['categoryId'],
                "typeId" => $postedData['typeId'],
                "name" => $postedData['name'],
                "brandName" => $postedData['brandName'],
                "listingstatus" => $postedData['listingstatus'],
                "title" => $postedData['title'],
                "description" => $postedData['description'],
                "color" => $postedData['color'],
                "availableSize" => $postedData['availableSize'],
                // "idealFor"           => $postedData['idealFor'],
                "mrpPrice" => $postedData['mrpPrice'],
                "sellingPrice" => $postedData['sellingPrice'],
                "stockQty" => $stockQty,
                "stock_status" => $stockStatus,
                "countryOfOrigin" => $postedData['countryOfOrigin'],
                "manufacturerDetails" => $postedData['manufacturerDetails'],
                "hsnCode" => $postedData['hsnCode'],
                "gstPercent" => $postedData['gstPercent'],
                "createdAt" => date('Y-m-d H:i:s'),
                // "updatedAt"          => date('Y-m-d H:i:s')
            ];


            if (!empty($postedData['offerDescription']) && !empty($postedData['offerTitle'])) {
            } {
                $offerstoredata = [
                    "uid" => $offerId,
                    "prodId" => $product_id,
                    "storeId" => $postedData['storeId'],
                    "store_offer_id" => $postedData['StoreOfferId'],
                    "description" => $postedData['offerDescription'],
                    "title" => $postedData['offerName'],
                ];
            }


            $results = [
                "productSave" => $SellerModel->save_product($data)
            ];


            if (isset($offerstoredata)) {
                $results['offerStore'] = $SellerModel->add_store_offer_By_addProduct($offerstoredata);
            }

            if ($results['productSave']) {
                if (!empty($_FILES['images']['name'])) {
                    $this->upload_product_images($product_id, $_FILES['images']);
                }

                $response = [
                    "status" => true,
                    "messages" => [
                        "product" => "Product Details Saved",
                        "offers" => isset($results['offerStore']) ? "Product Offers Details Saved" : "Offer details not provided or incomplete"
                    ]
                ];
            } else {
                $response = ["status" => false, "message" => "Product Details Not Saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }
    public function product_list()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            $productList = $SellerModel->get_seller_products_list($storeId);
            if (!empty($productList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $productList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function my_profile()
    {
        $this->validation->setRuleGroup('search_by_userId');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();

            $userId = $valid_data['userId'];
            $user_details = $SellerModel->get_user_details($userId);

            if (!empty($user_details)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $user_details];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function manage_offer()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            $offerList = $SellerModel->get_store_offer($storeId);
            if (!empty($offerList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $offerList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    //  <!-----------------------Add Offer ------------------------------------- > 

    public function add_offer()
    {
        $this->validation->setRuleGroup('add_new_offer');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $postedData = $this->request->getPost();
            $uId = $this->GUID('OFFER');
            // $offer_state = $postedData['INACTIVE'];

            if (!empty($_FILES['offerImage']['name'])) {
                $uploadedImageURL = $this->upload_image($_FILES['offerImage'], 'assets/uploads/Offer/');
            } else {
                $uploadedImageURL = 'assets/uploads/Offer/no-image-found.png';
            }

            $data = [
                "uId" => $uId,
                "storeId" => $postedData['storeId'],
                "title" => $postedData['title'],
                "applicableOnProduct" => $postedData['applicableOnProduct'],
                "description" => $postedData['description'],
                "mrpPrice" => $postedData['mrpPrice'],
                "dicountType" => $postedData['dicountType'],
                "discount" => $postedData['discount'],
                "startDate" => $postedData['startDate'],
                "startTime" => $postedData['startTime'],
                "endDate" => $postedData['endDate'],
                "endTime" => $postedData['endTime'],
                "minAmount" => $postedData['minAmount'],
                "imageUrl" => $uploadedImageURL,
                "state" => $postedData['state'],
            ];
            // print_r($data) ; die ; 
            $save_offer = $SellerModel->save_offer($data);

            if ($save_offer) {
                $response = ["status" => true, "message" => "Offer Details Saved",];
            } else {
                $response = ["status" => false, "message" => "Offer Details Not saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function edit_offer()
    {
        $SellerModel = $this->init_SellerModel();
        $postedData = $this->request->getPost();


        $image = '';
        if (isset($_FILES['offerImage']) && !empty($_FILES['offerImage']['name'])) {
            $image = $this->upload_image($_FILES['offerImage'], 'assets/uploads/Offer/');
        } else {

            $image = $postedData['offerImage'] ?? '';
        }

        // Prepare data for update
        $data = [
            "title" => $postedData['title'],
            "applicableOnProduct" => $postedData['applicableOnProduct'],
            "description" => $postedData['description'],
            "mrpPrice" => $postedData['mrpPrice'],
            "dicountType" => $postedData['dicountType'],
            "discount" => $postedData['discount'],
            "startDate" => $postedData['startDate'],
            "startTime" => $postedData['startTime'],
            "endDate" => $postedData['endDate'],
            "endTime" => $postedData['endTime'],
            "minAmount" => $postedData['minAmount'],
            "state" => $postedData['state'],
            "imageUrl" => $image,
        ];

        $condition = [
            "uId" => $postedData['offerId'],
        ];

        // Save the offer details
        $save_offer = $SellerModel->edit_offer($data, $condition);

        // Response
        if ($save_offer) {
            $response = ["status" => true, "message" => "Offer Details Edit Successfully"];
        } else {
            $response = ["status" => false, "message" => "Offer Details Not Saved"];
        }

        return $this->send_response($response, 200);
    }


    public function change_offer_status()
    {
        $this->validation->setRuleGroup('change_offer_status');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $condition = ['storeId' => $valid_data['storeId'], 'uId' => $valid_data['offerId']];
            $offer_details = $SellerModel->get_store_offer_details($condition);

            if (!empty($offer_details)) {
            } else {
                $response = ["status" => false, "message" => "Offer not found!"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function product_request()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            $productList = $SellerModel->get_requested_product_list($storeId);
            //  print_r($productList); die;
            if (!empty($productList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $productList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found", "data" => []];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function get_seller_referral_requests($storeId)
    {
        $SellerModel = $this->init_SellerModel();
        $response = $SellerModel->get_seller_referral_requests_by_store_id($storeId);
        return $this->send_response($response, 200);
    }

    // public function create_seller_referral_reward()
    // {
    //     $this->validation->setRuleGroup('create_seller_referral_reward');
    //     if ($this->validation->withRequest($this->request)->run()) {
    //         $valid_data = $this->validation->getValidated();
    //         $SellerModel = $this->init_SellerModel();
    //         $referral_reward_added = $SellerModel->add_seller_referral_reward($valid_data['referralRequestId'], [
    //             'referrerUserRewardType' => $valid_data['referrerRewardType'],
    //             'referrerUserReward' => $valid_data['referrerReward'],
    //             'referredUserRewardType' => $valid_data['referredRewardType'],
    //             'referredUserReward' => $valid_data['referredReward'],
    //             'modifiedAt' => date('Y-m-d H:i:s'),
    //             'status' => 'REWARDED'
    //         ]);
    //         // print_r($valid_data);
    //         // die;
    //         if ($referral_reward_added) {
    //             $response = ["status" => true, "message" => "Referral Reward Created Successfully."];
    //         } else {
    //             $response = ["status" => false, "message" => "Error Occurred! Failed to create referral reward."];
    //         }
    //     } else {
    //         $validation_errors = $this->validation->getErrors();
    //         $error_messages = array_values($validation_errors);
    //         $response = ["status" => false, "message" => $error_messages[0]];
    //     }

    //     return $this->send_response($response, 200);
    // }

    public function create_seller_referral_reward()
    {
        $this->validation->setRuleGroup('create_seller_referral_reward');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $referral_reward_added = $SellerModel->add_seller_referral_reward($valid_data['referralRequestId'], [
                'referredUserId' => $valid_data['referredUserId'],
                'referrerUserRewardType' => $valid_data['referrerRewardType'],
                'referrerUserReward' => $valid_data['referrerReward'],
                'referredUserRewardType' => $valid_data['referredRewardType'],
                'referredUserReward' => $valid_data['referredReward'],
                'modifiedAt' => date('Y-m-d H:i:s'),
                'status' => REFERRAL_REQUESTS_STATUS_REWARDED
            ]);

            if ($referral_reward_added) {
                $response = ["status" => true, "message" => "Referral Reward Created Successfully."];
            } else {
                $response = ["status" => false, "message" => "Error Occurred! Failed to create referral reward."];
            }
        } else {
            $validation_errors = $this->validation->getErrors();

            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function get_seller_referral_rewards_list($storeId)
    {
        $SellerModel = $this->init_SellerModel();
        $response = $SellerModel->get_seller_referral_rewards_by_store_id($storeId);
        return $this->send_response($response, 200);
    }

    public function all_payment()
    {
        $this->validation->setRuleGroup('search_by_storeId');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];

            // Check for sorting criteria in the request
            $get_data = $this->request->getGet();
            $sortBy = (!empty($get_data['sortBy']) && strtolower($get_data['sortBy']) === 'asc') ? 'ASC' : 'DESC';

            // Pass the sortBy parameter to get_recent_transactions method
            $transactionList = $SellerModel->get_recent_transactions($storeId, $sortBy);

            if (!empty($transactionList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $transactionList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }


    public function dashboard()
    {
        $this->validation->setRuleGroup('search_by_storeId');

        if ($this->validation->withRequest($this->request)->run()) {

            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $storeId = $valid_data['storeId'];

            $dashboardData = $SellerModel->get_dashboard_data($storeId);

            // print_r($dashboardData) ;die ; 

            // var_dump($dashboardData); die ; 
            if (!empty($dashboardData)) {

                $response = ["status" => true, "message" => "Data Found.", "data" => $dashboardData];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();

            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }


    public function saved_product_list()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            // $productList = $SellerModel->saved_product_list_storewise($storeId);
            $saveList = $SellerModel->get_save_product_list($storeId);

            if (!empty($saveList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $saveList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found", "data" => []];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function change_product_listing_status()
    {
        $this->validation->setRuleGroup('change_product_listing_status');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $condition = [
                'storeId' => $valid_data['storeId'],
                'uId' => $valid_data['productId']
            ];


            $product_details = $SellerModel->get_product_details($condition);

            if (!empty($product_details)) {

                $product_details_updated = $SellerModel->update_product_listing_status(
                    $valid_data['listingStatus'],
                    $valid_data['storeId'],
                    $valid_data['productId']
                );

                if ($product_details_updated) {
                    $response = ["status" => true, "message" => "Product listing status changed successfully."];
                } else {
                    $response = ["status" => false, "message" => "Error occurred! Failed to change product listing status."];
                }
            } else {
                $response = ["status" => false, "message" => "Store product is not found!"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }



    public function privecy_policy()
    {
        $SellerModel = $this->init_SellerModel();
        $privacy_policy = $SellerModel->get_system_preference_data(['name' => 'privacy_policy']);
        if (!empty($privacy_policy)) {
            $response = ["status" => true, "message" => "Data Found.", "data" => $privacy_policy];
        } else {
            $response = ["status" => false, "message" => "Data Not Found"];
        }

        return $this->send_response($response, 200);
    }

    public function create_push_notification()
    {
        $this->validation->setRuleGroup('create_push_notification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $uId = $this->GUID('NOTIF');
            $data = [
                "uId" => $uId,
                "storeId" => $valid_data['storeId'],
                "userType" => $valid_data['userType'],
                "distanceUnder" => $valid_data['distanceUnder'],
                "notificationTitle" => $valid_data['notificationTitle'],
                "notificationDescription" => $valid_data['notificationDescription'],
                "createdAt" => date('Y-m-d H:i:s'),
            ];

            if (!empty($_FILES['image']['name'])) {
                if (env('DOCUMENT_UPLOAD_TO') == 'LOCAL') {
                    $uploaded_image_path = $this->upload_image($_FILES['image'], 'assets/uploads/push_notification_images/');
                } else {
                    $uploaded_image_path = $this->uploadFileToS3(
                        $_FILES['image']['name'],
                        $_FILES['image']['tmp_name']
                    );
                }
                $data['imageUrl'] = (!empty($uploaded_image_path)) ? $uploaded_image_path : NULL;
            }

            $dataSaved = $SellerModel->saved_push_notification_storewise($data);
            $send_notification = $this->send_push_notification_buyer($valid_data['notificationTitle'], $valid_data['notificationDescription'], $data['imageUrl']);
            if (!empty($dataSaved) && $send_notification) {
                $response = ["status" => true, "message" => "Notification Send to Buyer ."];
            } else {
                if (env('DOCUMENT_UPLOAD_TO') == 'LOCAL' && !empty($uploaded_image_path)) {
                    unlink(FCPATH . $uploaded_image_path);
                }
                $response = ["status" => false, "message" => "Data Not Saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function manage_push_notification()
    {
        $this->validation->setRuleGroup('search_by_storeId');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            $notificationList = $SellerModel->get_push_notification($storeId);
            //print_r($notificationList); die;
            if (!empty($notificationList)) {
                $response = ["status" => true, "message" => "Data Found.", "data" => $notificationList];
            } else {
                $response = ["status" => false, "message" => "Data Not Found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function send_again_push_notification()
    {
        $this->validation->setRuleGroup('send_again_push_notification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $uId = $valid_data['uId'];
            $NotificationData = $SellerModel->send_again_push_notification($uId);
            if ($NotificationData) {
                $image = $NotificationData->imageUrl;
                $this->send_push_notification_buyer($NotificationData->notificationTitle, $NotificationData->notificationDescription, $image);
                $response =  ['status' => true, 'message' => 'Notification Send SussesFully '];
            } else {
                $response =  ['status' => false, 'message' => 'Notification Are not valid for this ID'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function get_push_notifications_list($storeId)
    {


        $get_data = $this->request->getGet();
        $searchText = (!empty($get_data['search'])) ? $get_data['search'] : '';
        $sortBy = (!empty($get_data['sortBy'])) ? $get_data['sortBy'] : '';
        $SellerModel = $this->init_SellerModel();
        $response = $SellerModel->get_push_notifications_list($storeId, $searchText, $sortBy);
        if (empty($response)) {
            log_message('error', 'Empty response for storeId: ' . $storeId);
            return $this->send_response(['error' => 'No data found'], 404);
        }

        return $this->send_response($response, 200);
    }


    public function edit_push_notification()
    {
        $this->validation->setRuleGroup('edit_push_notification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();
            $condition = ["uId" => $valid_data['notificationId']];
            $updateData = $this->request->getPost();
            $data = [
                "userType" => $updateData['userType'],
                "distanceUnder" => $updateData['distanceUnder'],
                "notificationTitle" => $updateData['notificationTitle'],
                "notificationDescription" => $updateData['notificationDescription'],
                "updatedAt" => date('Y-m-d H:i:s'),
            ];

            if (!empty($_FILES['image']['name'])) {
                if (env('DOCUMENT_UPLOAD_TO') == 'LOCAL') {
                    $uploaded_image_path = $this->upload_image($_FILES['image'], 'assets/uploads/push_notification_images/');
                } else {
                    $uploaded_image_path = $this->uploadFileToS3(
                        $_FILES['image']['name'],
                        $_FILES['image']['tmp_name']
                    );
                }
                $data['imageUrl'] = !empty($uploaded_image_path) ? $uploaded_image_path : NULL;
            }
            $push_notification_edited = $SellerModel->edit_push_notification($data, $condition);
            if ($push_notification_edited) {
                $response = ["status" => true, "message" => "Push notification edited."];
            } else {
                $response = ["status" => false, "message" => "Error occurred! Failed to edit push notification data."];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function delete_push_notification()
    {
        $this->validation->setRuleGroup('delete_push_notification');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $response = $SellerModel->delete_push_notification($valid_data['storeId'], $valid_data['notificationId']);
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function deactivate_store_offer()
    {

        $input = $this->request->getJSON();
        $OfferIdsList = $input->offerIdsList;

        $model = $this->init_SellerModel();
        $deactivateOfferIdsList = $model->deactivate_store_offer($OfferIdsList);
        if ($deactivateOfferIdsList) {
            $response = ['status' => true, 'message' => 'Store Offer  Deactivates . '];
        } else {
            $response = ['status' => false, 'message' => 'Empty Store Offers'];
        }
        return $this->send_response($response, 200);
    }



    public function edit_user_profile()
    {
        $this->validation->setRuleGroup('get_user_by_id');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $userId = $valid_data['uId'];

            print_r($userId);

            $get_user_by_id = $SellerModel->get_user_profile_by_id($userId);

            if ($get_user_by_id) {
                $response = [
                    'status' => true,
                    'data' => $get_user_by_id
                ];
            } else {
                $response = [
                    'status' => false,
                    'Message' => 'User are not found '
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }

    public function update_user_profile()
    {
        $this->validation->setRuleGroup('get_user_by_id');

        if ($this->validation->withRequest($this->request)->run()) {

            $valid_data = $this->validation->getValidated();

            // $postData  = $this->request->getPost();

            $SellerModel = $this->init_SellerModel();

            $userId = $valid_data['uId'];

            $get_user_by_id = $SellerModel->get_user_profile_by_id($userId);

            if ($get_user_by_id) {
                $data = [
                    'name' => $valid_data['name'],
                    'mobileNo' => $valid_data['mobileNo'],
                    'email' => $valid_data['email'],
                    'address' => $valid_data['address'],
                    'password' => md5($valid_data['password']),

                ];
                $update_data = $SellerModel->update_user_profile($data, ["uId" => $userId]);
                if ($update_data) {
                    $response = [
                        'status' => true,
                        'data' => $data,
                    ];
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Update failed',
                    ];
                }
            } else {
                $response = [
                    'status' => false,
                    'message' => 'User not found',
                ];
            }
        } else {
            // Validation failed
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                'status' => false,
                'message' => $error_messages[0],
            ];
        }

        // Return JSON response
        return $this->response->setJSON($response);
    }

    public function seller_sign_out()
    {
        $this->validation->setRuleGroup('sign_out');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $user = $valid_data['userId'];
            if (empty($user)) {
                return $this->failNotFound('User ID is required.');
            }
           
            // print_r($condition); 
            $update = 1;
            

            // print_r($update);
            if ($update) {
                session()->destroy();
                $response = ['status' => true, 'message' => 'User signed out successfully.'];
                return $this->respond($response, 200);
            } else {

                $response = ['status' => false, 'message' => 'Failed to sign out.'];
                return $this->respond($response, 500);
            }
        } else {

            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
            return $this->respond($response, 400);
        }
    }

    public function product_save_and_draft()
    {
        $this->validation->setRuleGroup();
        if ($this->validation->withRequest($this->request)->run()) {
            $SellerModel = $this->init_SellerModel();
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_message = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_message[0]];
            return $this->respond($response, 400);
        }
    }
    public function delete_store_offer()
    {
        $this->validation->setRuleGroup('delete_store_offer');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();
            $response = $SellerModel->delete_store_offer($valid_data['storeId'], $valid_data['offerId']);
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }


    public function delete_product()
    {
        $this->validation->setRuleGroup('delete_product');
        if ($this->validation->withRequest($this->request)->run()) {

            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $response = $SellerModel->delete_product($valid_data['productId']);
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function set_stock_status()
    {
        $this->validation->setRuleGroup('stock_status');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();


            $condition = [
                'storeId' => $valid_data['storeId'],
                'uId' => $valid_data['productId']
            ];


            $Check_stock_product = $SellerModel->get_product_details_for_stock_status_change($condition);

            if (empty($Check_stock_product)) {
                $response = ["status" => false, "message" => "Store product is not found!"];
            } elseif ($Check_stock_product->stockQty == 0) {
                $response = ['status' => false, 'message' => 'Please update your stock quantity.'];
            } else {
                // Product exists and stockQty is greater than 0, so proceed with status change
                $product_details_updated = $SellerModel->update_stock_status(
                    $valid_data['stockStatus'],
                    $valid_data['storeId'],
                    $valid_data['productId']
                );

                if ($product_details_updated) {
                    $response = ["status" => true, "message" => "Stock status updated successfully"];
                } else {
                    $response = ["status" => false, "message" => "Error occurred! Failed to change stock status."];
                }
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->send_response($response, 200);
    }



    public function user_online_status_change()
    {
        $this->validation->setRuleGroup('user_online_status_change');

        if ($this->validation->withRequest($this->request)->run()) {
            $SellerModel = $this->init_SellerModel();
            $valid_data = $this->validation->getValidated();

            $condition = ["uId" => $valid_data['userId']];

            $get_user_online_profile = $SellerModel->get_user_profile_by_id($condition);
            // print_r($get_user_online_profile) ; die ; 
            if (!empty($get_user_online_profile)) {
                $update_user_online_status = $SellerModel->update_user_online_status_change(
                    $valid_data['userId'],
                    $valid_data['OnlineStatus']
                );

                if ($update_user_online_status) {
                    $response = [
                        "status" => true,
                        "message" => "User Online status changed successfully"
                    ];
                } else {
                    $response = [
                        "status" => false,
                        "message" => "Error occurred! Failed to change user online status."
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "User is not found!"
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }

    public function save_new_product()
    {
        $SellerModel = $this->init_SellerModel();
        $this->validation->setRuleGroup('save_new_product');

        if ($this->validation->withRequest($this->request)->run()) {
            $postedData = $this->request->getPost();


            $save_id = $this->GUID('SAVE');
            $offerId = $this->GUID('SP_OFFER');


            $data = [
                "uId" => $save_id,
                "storeId" => $postedData['storeId'],
                "categoryId" => $postedData['categoryId'],
                "typeId" => $postedData['typeId'],
                "name" => $postedData['name'],
                "brandName" => $postedData['brandName'],
                "title" => $postedData['title'],
                "description" => $postedData['description'],
                "color" => $postedData['color'],
                "availableSize" => $postedData['availableSize'],
                "mrpPrice" => $postedData['mrpPrice'],
                "sellingPrice" => $postedData['sellingPrice'],
                "stockQty" => $postedData['stockQty'],
                "countryOfOrigin" => $postedData['countryOfOrigin'],
                "manufacturerDetails" => $postedData['manufacturerDetails'],
                "hsnCode" => $postedData['hsnCode'],
                "gstPercent" => $postedData['gstPercent'],
                "createdAt" => date('Y-m-d H:i:s'),
                "updatedAt" => date('Y-m-d H:i:s')
            ];


            if (!empty($postedData['offerDescription']) && !empty($postedData['offerTitle'])) {
            } {
                $offerstoredata = [
                    "uid" => $offerId,
                    "prodId" => $save_id,
                    "storeId" => $postedData['storeId'],
                    "store_offer_id" => $postedData['StoreOfferId'],
                    "description" => $postedData['offerDescription'],
                    "title" => $postedData['offerName'],
                ];
            }

            $results = [
                "productSave" => $SellerModel->save_new_product_list($data)
            ];


            if (isset($offerstoredata)) {
                $results['offerStore'] = $SellerModel->add_store_offer_By_addProduct($offerstoredata);
            }

            if ($results['productSave']) {
                if (!empty($_FILES['images']['name'])) {

                    $this->upload_save_product_images($save_id, $_FILES['images']);
                }

                $response = [
                    "status" => true,
                    "messages" => [
                        "product" => "Product Details Saved",
                        "offers" => isset($results['offerStore']) ? "Product Offers Details Saved" : "Offer details not provided or incomplete"
                    ]
                ];
            } else {
                $response = ["status" => false, "message" => "Product Details Not Saved"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        // die();
        return $this->send_response($response, 200);
    }


    public function product_category_list()
    {

        $SellerModel = $this->init_SellerModel();
        $categories = $SellerModel->get_product_category_list();

        if ($categories) {

            $response = [
                'status' => true,
                'message' => 'Product Category List ',
                'data' => $categories
            ];
        } else {

            $response = [
                'status' => false,
                'message' => 'No categories found',
                'data'  => []
            ];
        }


        return $this->send_response($response, 200);
    }

    public function product_type_list()
    {

        $SellerModel = $this->init_SellerModel();

        $getTypeList = $SellerModel->get_product_type_list();

        if ($getTypeList) {
            $response = [
                'status' => true,
                'message' => 'Product Type List ',
                'data' => $getTypeList
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'No categories found',
                'data' => []
            ];
        }
        return $this->response->setJSON($response);
    }

    public function save_product_stock_status_change()
    {
        $this->validation->setRuleGroup('save_stock_status_change');
        if ($this->validation->withRequest($this->request)->run()) {

            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $condition = [
                'uId' => $valid_data['saveId'],
                'storeId' => $valid_data['storeId'],

            ];

            $get_save_data_list = $SellerModel->get_save_product_list_by_id($condition);


            if (!empty($get_save_data_list)) {

                $update_stock_live_status = $SellerModel->update_save_stock_status_change(
                    $valid_data['stockStatus'],
                    $valid_data['storeId'],
                    $valid_data['saveId']
                );

                if ($update_stock_live_status) {
                    $response = [
                        'status' => true,
                        'message' => 'Save Live Status Sussecfully ',
                        'data' => [
                            'stockStatus' => $valid_data['stockStatus'],
                        ]
                    ];
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Save Product stock status update failed ',
                    ];
                }
            } else {
                $response = ["status" => false, "message" => "Data Not found"];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }
        return $this->send_response($response, 200);
    }

    public function save_product_listingStatus_change()
    {
        $this->validation->setRuleGroup('save_product_listingStatus_change');

        if ($this->validation->withRequest($this->request)->run()) {

            $valid_data = $this->validation->getValidated();

            $SellerModel = $this->init_SellerModel();

            $condition = [
                'uId' => $valid_data['saveId'],
                'storeId' => $valid_data['storeId'],
            ];

            $get_save_product_list = $SellerModel->get_save_product_list_by_id($condition);
            // print_r($get_save_product_list);
            // die;
            if (!empty($get_save_product_list)) {

                $update_listingStatus = $SellerModel->update_save_listingStatus_change(
                    $valid_data['listingstatus'],
                    $valid_data['storeId'],
                    $valid_data['saveId']
                );

                if ($update_listingStatus) {
                    $response = [
                        'status' => true,
                        'message' => 'Save product listing updated successfully',
                        'data' => [
                            'listingstatus' => $valid_data['listingstatus'],
                        ]
                    ];
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Product listing status update failed',
                    ];
                }
            } else {
                $response = [
                    'status' => false,
                    'message' => 'Data Not Found!',
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_messages[0]];
        }

        return $this->response->setJSON($response, 200);
    }

    public function product_offer_list()
    {

        $SellerModel = $this->init_SellerModel();

        $get_offer_list = $SellerModel->get_product_offer_list();

        if ($get_offer_list) {
            $response = [
                'status' => true,
                'message' => 'Product Offer List',
                'data' => $get_offer_list,
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'Not Found !! ',
                'data'  => []
            ];
        }
        return $this->response->setJSON($response, 200);
    }

    public function get_country_list()
    {

        $SellerModel = $this->init_SellerModel();

        $get_country = $SellerModel->get_country();

        if ($get_country) {
            $response = [
                'status' => true,
                'data' => $get_country
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'Not Found Data !! '
            ];
        }
        return $this->response->setJSON($response, 200);
    }

    public function validate_and_get_user()
    {

        $this->validation->setRuleGroup('get_user_by_id');
        if (!$this->validation->withRequest($this->request)->run()) {
            return [
                'status' => false,
                'message' => $this->validation->getErrors()
            ];
        }
        $valid_data = $this->validation->getValidated();
        $SellerModel = $this->init_SellerModel();
        $userId = $valid_data['uId'];


        $get_user_by_id = $SellerModel->get_user_profile_by_id($userId);


        if ($get_user_by_id) {

            return [
                'status' => true,
                'user' => $get_user_by_id
            ];
        } else {
            return [
                'status' => false,
                'message' => 'User not found'
            ];
        }
    }

    public function update_profile()
    {
        $userId = $this->request->getPost('userId');
        $valid_data = $this->request->getPost();
        if (empty($valid_data['name']) || empty($valid_data['mobileNo']) || empty($valid_data['email']) || empty($valid_data['address'])) {
            return $this->send_response([
                'status' => false,
                'message' => 'All fields are required.'
            ], 400);
        }
        $data = [
            "name" => $valid_data['name'],
            "mobileNo" => $valid_data['mobileNo'],
            "email" => $valid_data['email'],
            "address" => $valid_data['address'],
        ];

        if (!empty($_FILES['profileImage'])) {
            $profile_image_path = $this->upload_profile_image($userId, $_FILES['profileImage']);
            if (file_exists(FCPATH . $profile_image_path)) {
                $data['profileImageLink'] = $profile_image_path;
            }
        }
        $model = $this->init_SellerModel();
        $update_user = $model->update_user_profile($data, $userId);
        if ($update_user) {
            $response = [
                'status' => true,
                'message' => 'Update Profile Successfully',
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'Please Try Again ',
            ];
        }
        return $this->send_response($response, 200);
    }
    // Here to change Size Array if need 
    private $sizes = [
        ['name' => 'Extra Small', 'code' => 'XS'],
        ['name' => 'Small', 'code' => 'S'],
        ['name' => 'Medium', 'code' => 'M'],
        ['name' => 'Large', 'code' => 'L'],
        ['name' => 'Extra Large', 'code' => 'XL'],
        ['name' => 'Double Extra Large', 'code' => 'XXL'],
        ['name' => 'Triple Extra Large', 'code' => 'XXXL']

    ];

    public function get_size()
    {
        $sizeCodes = array_column($this->sizes, 'code');
        return $this->respond(['status' => true, 'data' => $sizeCodes]);
    }


    public function get_gst_list()
    {
        $SellerModel = $this->init_SellerModel();

        $gstList = $SellerModel->get_gst_list();
        if ($gstList) {
            $response = [
                'status' => true,
                'data' => $gstList,
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'Data Not Found ',
            ];
        }
        return $this->response->setJSON($response, 200);
    }


    public function get_product_by_uid()
    {
        $this->validation->setRuleGroup('get_product_by_uid');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $response = $SellerModel->fetch_product_by_uid($valid_data['productId']);


            return [
                'status' => true,
                'product_details' => $response
            ];
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            return [
                'status' => false,
                'message' => $error_messages[0]
            ];
        }
    }

    public function edit_product()
    {
        $result = $this->get_product_by_uid();

        if (isset($result['status']) && $result['status']) {
            $product = $result['product_details'];

            $postData = $this->request->getPost();


            $data = [
                'name' => !empty($postData['name']) ? $postData['name'] : $product->name,
                'brandName' => !empty($postData['brandName']) ? $postData['brandName'] : $product->brandName,
                'description' => !empty($postData['description']) ? $postData['description'] : $product->description,
                'sellingPrice' => !empty($postData['sellingPrice']) ? $postData['sellingPrice'] : $product->sellingPrice,
                'stockQty' => !empty($postData['stockQty']) ? $postData['stockQty'] : $product->stockQty,
            ];

            $SellerModel = $this->init_SellerModel();
            $condition = ["uId" => $product->uId];
            $update_data = $SellerModel->update_product($data, $condition);

            if ($update_data) {
                $response = [
                    'status' => true,
                    'message' => 'Product updated successfully.',
                    'data' => $data,
                ];
            } else {
                $response = [
                    'status' => false,
                    'message' => 'Update failed.',
                ];
            }
        } else {
            $response = [
                'status' => false,
                'message' => isset($result['message']) ? $result['message'] : 'An error occurred.',
            ];
        }
        return $this->response->setJSON($response);
    }

    public function update_store_offers()
    {
        $offerId = $this->request->getPost('offerId');

        $valid_input = $this->request->getPost();
        $data = [];
        if (!empty($valid_input['title'])) {
            $data['title'] = $valid_input['title'];
        }
        if (!empty($valid_input['applicableOnProduct'])) {
            $data['applicableOnProduct'] = $valid_input['applicableOnProduct'];
        }
        if (!empty($valid_input['description'])) {
            $data['description'] = $valid_input['description'];
        }
        if (!empty($valid_input['mrpPrice'])) {
            $data['mrpPrice'] = $valid_input['mrpPrice'];
        }
        if (!empty($valid_input['dicountType'])) {
            $data['dicountType'] = $valid_input['dicountType'];
        }
        if (!empty($valid_input['discount'])) {
            $data['discount'] = $valid_input['discount'];
        }
        if (!empty($valid_input['startDate'])) {
            $data['startDate'] = $valid_input['startDate'];
        }
        if (!empty($valid_input['endDate'])) {
            $data['endDate'] = $valid_input['endDate'];
        }
        if (!empty($valid_input['endTime'])) {
            $data['endTime'] = $valid_input['endTime'];
        }
        if (!empty($valid_input['minAmount'])) {
            $data['minAmount'] = $valid_input['minAmount'];
        }
        if (!empty($_FILES['imageUrl']['name'])) {
            $data['imageUrl'] = $this->upload_image($_FILES['imageUrl'], 'assets/uploads/Offer/');
        } else {
            $data['imageUrl'] = 'assets/uploads/Offer/no-image-found.png';
        }

        $SellerModel = $this->init_SellerModel();
        $update_offersList = $SellerModel->update_store_offers($data, $offerId);
        if (!empty($update_offersList)) {
            $response = ['status' => true, 'message' => 'Store Offer  Updated Successfully'];
        } else {
            $response = ['status' => true, 'message' => 'Store Offer  Updated Successfully'];
        }
        return $this->send_response($response, 200);
    }
    public function activate_offers()
    {

        $input = $this->request->getJSON();
        $offerIdsList = $input->offerIdsList;
        $sellerModel = $this->init_SellerModel();
        $active_offerIdsList = $sellerModel->activate_store_offer($offerIdsList);
        if (!empty($active_offerIdsList)) {
            $response = ['status' => true, 'message' => 'Store Offer Activated Successfully'];
        } else {
            $response = ['status' => false, 'message' => 'Empty Store Offers '];
        }
        return $this->send_response($response, 200);
    }

    public function send_push_notification_by_id() {}

    public function deleteAll_push_notification()
    {

        $input = $this->request->getJSON();
        $notificationId = $input->notificationId;
        $SellerModel = $this->init_SellerModel();
        $delete_push_noti = $SellerModel->deleteAll_push_notification($notificationId);
        if ($delete_push_noti) {
            $response = ['status' => true, 'message' => 'Successfully delete all push notification.'];
        } else {
            $response = ['status' => false, 'message' => 'Failed to delete notifications.'];
        }
        return $this->send_response($response, 200);
    }


    public function get_all_product_list()
    {
        $this->validation->setRuleGroup('get_product_list');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $SellerModel = $this->init_SellerModel();
            $storeId = $valid_data['storeId'];
            $get_store_wise_product = $SellerModel->get_all_product_name($storeId);
            if ($get_store_wise_product) {
                $response = ['status' => true, 'data' => $get_store_wise_product];
            } else {
                $response = ['status' => false, 'message' => 'Data not found in this store'];
            }
        } else {
            $validation_errors = $this->validation->getError();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }
        return $this->send_response($response, 200);
    }

    public function send_push_notification()
    {
        $buyer = 1;
        if ($buyer == 1) {
            $response = ['status' => true, 'message' => 'Send notification to buyer successfully '];
        } else {
            $response = ['status' => false, 'message' => 'please Try again '];
        }
        return $this->send_response($response, 200);
    }

    public function store_category_list()
    {
        $sellerModel = $this->init_SellerModel();
        $categoryList = $sellerModel->store_category_list();
        if (!empty($categoryList)) {
            $response = ['status' => true, 'data' => $categoryList];
        } else {
            $response = ['status' => false, 'message' => 'Data Not Found . '];
        }
        return $this->send_response($response, 200);
    }


    public function update_product()
    {
        $sellerModel = $this->init_SellerModel();
        $valid_data = $this->request->getPost();

        // Validate product ID
        if (empty($valid_data['productId'])) {
            return $this->send_response(['status' => false, 'message' => 'Product Id is required'], 400);
        }

        $productId = $valid_data['productId'];
        $stockQty = $valid_data['stockQty'];

        $stockStatus = ($stockQty > 0) ? 'ON' : 'OFF';
        $productData = [
            'categoryId' => $valid_data['categoryId'],
            'typeId' => $valid_data['typeId'],
            'name' => $valid_data['name'],
            'brandName' => $valid_data['brandName'],
            'listingstatus' => $valid_data['listingstatus'],
            'title' => $valid_data['title'],
            'description' => $valid_data['description'],
            'color' => $valid_data['color'],
            'availableSize' => $valid_data['availableSize'],
            'mrpPrice' => $valid_data['mrpPrice'],
            'sellingPrice' => $valid_data['sellingPrice'],
            'stockQty' => $stockQty,
            'stock_status' => $stockStatus,
            'countryOfOrigin' => $valid_data['countryOfOrigin'],
            'manufacturerDetails' => $valid_data['manufacturerDetails'],
            'hsnCode' => $valid_data['hsnCode'],
            'gstPercent' => $valid_data['gstPercent'],
            'updatedAt' => date('Y-m-d H:i:s')
        ];
        $offerData = [
            'store_offer_id' => $valid_data['storeOfferId'],
            'title' => $valid_data['offerName'] ?? null,
            'description' => $valid_data['offerDescription'] ?? null,
            'updatedAt' => date('Y-m-d H:i:s')
        ];
        $results = [
            "updateProduct" => $sellerModel->update_product($productData, $productId)
        ];

        if (!empty($offerData['title'])) {
            $results['updateOffer'] = $sellerModel->update_product_offer($offerData, $productId);
        }
        $deletionResponse = [
            'status' => true,
            'deletedImages' => [],
            'errors' => []
        ];

        if (!empty($valid_data['deleteImageId'])) {
            $imageIds = is_string($valid_data['deleteImageId']) ? explode(',', trim($valid_data['deleteImageId'])) : (array) $valid_data['deleteImageId'];
            foreach ($imageIds as $imageId) {
                $imageDetails = $sellerModel->get_image_details($productId, $imageId);
                if ($imageDetails) {
                    $imagePath = FCPATH . $imageDetails->imageUrl;
                    if (file_exists($imagePath) && unlink($imagePath)) {
                        $sellerModel->delete_product_image($imageId);
                        $deletionResponse['deletedImages'][] = $imageId;
                    } else {
                        $deletionResponse['errors'][] = "Failed to delete image for ID: $imageId.";
                    }
                }
            }
        }
        if ($results['updateProduct']) {
            if (!empty($_FILES['images']['name'])) {
                $this->upload_update_product_images($productId, $_FILES['images']);
            }

            $response = [
                "status" => true,
                "messages" => [
                    "product" => "Product updated successfully.",
                    "offers" => isset($results['updateOffer']) ? "Product offers updated successfully." : "No offer details provided.",
                    "deletedImages" => $deletionResponse['deletedImages'],

                ]
            ];
        } else {
            $response = ["status" => false, "message" => "Product details not saved."];
        }

        return $this->send_response($response, 200);
    }

    public function delete_product_images($productId, $imageIds)
    {
        $seller_model = $this->init_SellerModel();
        $deletedImages = [];

        foreach ($imageIds as $imageId) {
            $imageDetails = $seller_model->get_image_details($productId, $imageId);
            if ($imageDetails) {
                $imagePath = FCPATH . $imageDetails->imageUrl;
                if (file_exists($imagePath) && unlink($imagePath)) {
                    $seller_model->delete_product_image($imageId);
                    $deletedImages[] = $imageId;
                }
            }
        }

        return ['status' => true, 'deletedImages' => $deletedImages];
    }

    public function save_product_update()
    {
        $sellerModel = $this->init_SellerModel();

        $valid_data = $this->request->getPost();

        if (empty($valid_data['saveId'])) {
            echo "Please give product Id ";
        }
        $saveId = $valid_data['saveId'];
        $stockQty = $valid_data['stockQty'];
        $stockStatus = ($stockQty > 0) ? 'ON' : 'OFF';

        $data = [
            'categoryId'    => $valid_data['categoryId'],
            'typeId'        => $valid_data['typeId'],
            'name'          => $valid_data['name'],
            'brandName'     => $valid_data['brandName'],
            'listingstatus' => $valid_data['listingstatus'],
            'title'         => $valid_data['title'],
            'description'   => $valid_data['description'],
            'color'         => $valid_data['color'],
            'availableSize' => $valid_data['availableSize'],
            'mrpPrice'      => $valid_data['mrpPrice'],
            'sellingPrice'  => $valid_data['sellingPrice'],
            'stockQty'      => $stockQty,
            'stock_status'  => $stockStatus,
            'countryOfOrigin'     => $valid_data['countryOfOrigin'],
            'manufacturerDetails' => $valid_data['manufacturerDetails'],
            'hsnCode'    => $valid_data['hsnCode'],
            'gstPercent' => $valid_data['gstPercent'],
            'updatedAt'  => date('Y-m-d H:i:s')
        ];
        $saveOffer = [
            'store_offer_id' => $valid_data['storeOfferId'],
            'title'          => $valid_data['offerName'],
            'description'    =>  $valid_data['offerDescription'],
            'updatedAt'      => date('Y-m-d H:i:s')
        ];
        $results = [
            'saveProductUpdate' => $sellerModel->save_product_update($data, $saveId)
        ];
        if (!empty($saveOffer['title'])) {
            $results['saveOfferUpdate'] = $sellerModel->update_product_offer($saveOffer, $saveId);
        }


        $imageIds = explode(',', $valid_data['deleteImageIds']);
        $imagePaths = $sellerModel->get_image_paths_by_ids($imageIds);
        $imageIdsToDelete = [];
        foreach ($imageIds as $index => $imageId) {
            if (isset($imagePaths[$index])) {
                $imagePath = $imagePaths[$index];
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
                $imageIdsToDelete[] = $imageId;
            }
        }
        if (!empty($imageIdsToDelete)) {
            $sellerModel->delete_product_images_by_ids($imageIdsToDelete);
        }

        if ($results['saveProductUpdate']) {
            if (!empty($_FILES['images']['name'])) {

                $this->upload_save_product_images($saveId, $_FILES['images']);
            }
        }

        if ($results) {
            $response = ['status' => true, 'message' => 'Product update Successfully '];
        } else {
            $response   = ['status' => false, 'message' => 'not update any thing'];
        }
        return $this->send_response($response, 200);
    }
    private function store_images($storeImage, $storeId,)
    {
        $sellerModel = $this->init_SellerModel();
        foreach ($storeImage['name'] as $i => $imageName) {
            $uniqueImageID = $this->GUID('IMG');
            $fileExtension = pathinfo($imageName, PATHINFO_EXTENSION);
            $saveFilePath = 'assets/uploads/store_images/' . $uniqueImageID . '.' . $fileExtension;
            $fileUploadPath = FCPATH . $saveFilePath;

            if (move_uploaded_file($storeImage['tmp_name'][$i], $fileUploadPath)) {
                $sellerModel->add_store_image([
                    'uId' => $uniqueImageID,
                    'storeId' => $storeId,
                    'imageUrl' => $saveFilePath,
                    'createdAt' => date('Y-m-d H:i:s'),
                ]);
            }
        }
        return true;
    }

    public function upload_store_images()
    {

        $storeId = $this->request->getPost('storeId');

        if (!empty($_FILES['images']['name'])) {
            $uploadSuccess = $this->store_images($_FILES['images'], $storeId);

            if ($uploadSuccess) {
                $response = ['status' => true, 'message' => 'Store images uploaded successfully.'];
            } else {
                $response = ['status' => false, 'message' => 'Image upload failed in processing.'];
            }
        } else {
            $response = ['status' => false, 'message' => 'Failed to upload. Please try again.'];
        }
        return $this->send_response($response, 200);
    }

    public function save_product_publish()
    {
        $valid_data = $this->request->getPost();
        $saveId = $valid_data['saveId'];
        $model = $this->init_SellerModel();
        $publishedSaveProduct = $model->save_product_publish($saveId);
        if ($publishedSaveProduct) {
            $response = ['status' => true, 'message' => 'Product Published '];
        } else {
            $response = ['status' => false, 'message' => 'Try Again'];
        }
        return $this->send_response($response, 200);
    }

    public function forget_password()
    {

        $email = service('email');
        $email->setFrom('u5459607@gmail.com', 'eCommerce Seller');
        $this->validation->setRuleGroup('forget_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $PhoneEmail = $valid_data['PhoneEmail'];
            $sellerModel = $this->init_SellerModel();
            $user_data = $sellerModel->get_user_data_by_email_mobile($PhoneEmail);
            if (!empty($user_data)) {
                if ($user_data->state == STATE_ENUM_ACTIVE) {
                    $userId = $user_data->uId;
                    $otp = $this->for_save_otp($userId);
                    $subject = 'OTP for Password Reset';
                    $message = "Dear $user_data->name  ,\n\nHere is your OTP for password reset: " . $otp . "\n\nIf you did not request this, please ignore this email.";
                    $email->setTo($user_data->email);
                    $email->setSubject($subject);
                    $email->setMessage($message);
                    if ($email->send()) {
                        $response = [
                            'status' => true,
                            'message' => 'OTP sent successfully to your email.',
                            'data' => ['otp' => $otp]
                        ];
                    } else {
                        $response = [
                            'status' => false,
                            'message' => 'Failed to send OTP, please try again.'
                        ];
                    }
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'User account is not active. Please contact support.'
                    ];
                }
            } else {
                $response = [
                    'status' => false,
                    'message' => 'User not found with the provided email or phone number.'
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                'status' => false,
                'message' => $error_messages[0]
            ];
        }
        return $this->send_response($response, 200);
    }


    public function forgot_password_otp_validation()
    {
        $this->validation->setRuleGroup('forget_password_otp_validation');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $PhoneEmail = $valid_data['PhoneEmail'];
            $sellerModel = $this->init_SellerModel();
            if (filter_var($PhoneEmail, FILTER_VALIDATE_EMAIL)) {
                $user_data = $sellerModel->get_user_account_data(['email' => $valid_data['PhoneEmail']]);
            } else {
                $user_data = $sellerModel->get_user_account_data(['mobileNo' => $valid_data['PhoneEmail']]);
            }
            if (!empty($user_data->uId)) {
                $otp_verify = $this->db->table('otp_list')
                    ->where(['userId' => $user_data->uId, 'isVerify' => 'I'])
                    ->orderBy('createdAt', 'DESC')
                    ->get()->getRow();
                if (!empty($otp_verify->otp)) {
                    if ($valid_data['otp'] == $otp_verify->otp) {
                        $this->db->table('otp_list')
                            ->set('isVerify', 'V')
                            ->where('userId', $otp_verify->userId)
                            ->update();
                        $data = ['userId' => $user_data->uId];
                        $response = [
                            "status" => true,
                            "message" => "OTP verified successfully.",
                            "data" => $data,
                        ];
                    } else {
                        $response = [
                            "status" => false,
                            "message" => "Invalid OTP."
                        ];
                    }
                } else {
                    $response = [
                        "status" => false,
                        "message" => "No OTP found or already verified."
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "User not found with the provided email or phone number."
                ];
            }
        } else {

            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }

    public function update_password()
    {

        $this->validation->setRuleGroup('update_password');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $userId = $valid_data['userId'];
            $password = password_hash($valid_data['password'], PASSWORD_DEFAULT);

            $update_password = $this->db->table('user_accounts')->set('password', $password)->where('uId', $userId)->update();
            if (!empty($update_password)) {
                $response = ['status' => true, 'message' => 'Password updated SuccessFully'];
            } else {
                $response = ['status' => false, 'message' => 'Password Not Updated Please Try Again !! '];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_message = array_values($validation_errors);
            $response = ["status" => false, "message" => $error_message[0]];
        }
        return $this->send_response($response, 200);
    }

    public function get_store_category_list()
    {
        $getStoreList = $this->db->table('store_category')->select('uId , categoryName')->where('state', STORE_CATEGORY_ACTIVE)->orderBY('createdAt', 'DESC')->get()->getResult();
        if (!empty($getStoreList)) {
            $response = ['status' => true, 'data' => $getStoreList];
        } else {
            $response = ['status' => false, 'message' => 'Not Found Any Store Category'];
        }
        return $this->send_response($response, 200);
    }

    public function get_city_list_by_stateUid()
    {
        $stateId = $this->request->getVar('stateId');

        if ($stateId) {
            $cities = $this->db->table('city')
                ->select('city.name as cityName, city.uId As cityId,  state.uId as stateId, state.name as stateName')
                ->join('state', 'state.uId = city.stateId')
                ->where('stateId', $stateId)
                ->orderBy('city.name', 'ASC')
                ->get()
                ->getResult();
            if (!empty($cities)) {
                $response = ["status" => true, "message" => "City Found ", "data" => $cities];
            } else {
                $response = ["status" => false,  "message" => "No cities found for the given state", "data" => []];
            }
        }
        return $this->send_response($response, 200);
    }

    public function get_state_list()
    {
        $state_list = $this->db->table('state')->select('uId , name')->orderBy('name', 'ASC')->get()->getResult();
        if (!empty($state_list)) {
            $response = ['status' => true,  'message' => 'States List ', 'data' => $state_list];
        } else {
            $response = ['status' => false, 'message' => 'State Are Not Found', 'data' => []];
        }
        return $this->send_response($response, 200);
    }

    public function send_push_notification_real_time()
    {
        $sellerModel = $this->init_SellerModel();

        // Step 1: Fetch buyers with FCM tokens
        $buyers = $sellerModel->get_buyers_with_fcm_tokens();

        if (empty($buyers)) {
            return $this->send_response([
                'status' => false,
                'message' => 'No buyers found with valid FCM tokens.'
            ], 404);
        }

        // Step 2: Fetch Firebase authentication data
        $authenticationData = $this->getFirebaseAuthenticationData();
        $projectId = !empty($authenticationData['project_id']) ? $authenticationData['project_id'] : '';
        $token = !empty($authenticationData['access_token']) ? $authenticationData['access_token'] : '';

        if (empty($projectId) || empty($token)) {
            return $this->send_response([
                'status' => false,
                'message' => 'Firebase authentication data is invalid.'
            ], 400);
        }

        $title = "Hello Buyers!";
        $body = "This is an offer alert from eCommerce seller to buyer.";
        $results = [];

        // Step 4: Send notifications to each buyer
        foreach ($buyers as $buyer) {
            if (empty($buyer->fcm_token)) {
                $results[] = [
                    'buyer' => $buyer->name,
                    'status' => false,
                    'error' => 'FCM token is missing.'
                ];
                continue;
            }

            $FCM_token = $buyer->fcm_token;

            $jsonData = [
                "message" => [
                    "notification" => [
                        "title" => $title,
                        "body" => $body,
                    ],
                    "data" => [
                        "title" => $title,
                        "body" => $body,
                    ],
                    "token" => $FCM_token,
                ],
            ];

            $jsonString = json_encode($jsonData);


            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonString);

            $headers = [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
            ];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if (curl_errno($ch)) {
                $results[] = [
                    'buyer' => $buyer->name,
                    'status' => false,
                    'error' => curl_error($ch),
                ];
            } else {
                $response = json_decode($result, true);

                if ($httpCode === 200) {
                    $results[] = [
                        'buyer' => $buyer->name,
                        'status' => true,
                        'response' => $response,
                    ];
                } else {
                    $results[] = [
                        'buyer' => $buyer->name,
                        'status' => false,
                        'error' => $response['error'] ?? 'Unknown error occurred.',
                    ];
                }
            }

            curl_close($ch);
        }

        // Step 5: Aggregate response
        $successCount = count(array_filter($results, fn($res) => $res['status'] === true));
        $failureCount = count($results) - $successCount;

        return $this->send_response([
            'status' => true,
            'message' => "Notifications processed.",
            'success_count' => $successCount,
            'failure_count' => $failureCount,
            'results' => $results,
        ], 200);
    }

    public function save_fcm_token()
    {
        $this->validation->setRuleGroup('save_fcm_token');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $userModel = $this->init_userModel();
            $userId = $valid_data['userId'];
            $fcmToken = $valid_data['fcm_token'];

            $user = $userModel->select('state')->where(['uId' => $userId])->first();
            if (!$user) {
                $response = ['status' => false, 'message' => 'User not found'];
                return $this->send_response($response, 404);
            }

            if ($user['state'] !== STATE_ENUM_ACTIVE) {
                $response = ['status' => false, 'message' => 'User status is not active'];
                return $this->send_response($response, 403);
            }

            $fcmTokenSave = $userModel->set(['fcm_token' => $fcmToken, 'updatedAt' => $this->current_datetime])
                ->where(['uId' => $userId, 'state' => STATE_ENUM_ACTIVE])->update();

            if ($fcmTokenSave) {
                $response = ['status' => true, 'message' => 'FCM Token updated successfully'];
            } else {
                $response = ['status' => false, 'message' => 'Failed to update FCM Token. Please try again'];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                'status' => false,
                'message' => $error_messages[0]
            ];
        }
        return $this->send_response($response, 200);
    }

    public function user_gst_number_validation()
    {

        $demo_gst_data = [
            "22AAAAA0000A1Z5" => [
                "gstin" => "22AAAAA0000A1Z5",
                "state" => "WEST BENGAL",
                "status" => "Active",
                "name" => "Demo Company Pvt Ltd",
                "address" => "123 Demo Address, Raipur, Chhattisgarh",
                "phone" => "9876543210",
                "pan" => "AAAAA0000A",
                "pinCOde" => "714505"
            ],
            "27BBBBB1111B2Z6" => [
                "gstin" => "27BBBBB1111B2Z6",
                "state" => "ASSAM",
                "status" => "Active",
                "name" => "Test Business Ltd",
                "address" => "456 Test Address, Mumbai, Maharashtra",
                "phone" => "9988776655",
                "pan" => "BBBBB1111B",
                "pinCOde" => "714505"
            ]
        ];


        $gst_no = $this->request->getPost('gstNo');
        if (array_key_exists($gst_no, $demo_gst_data)) {
            $response = [
                "status" => true,
                "message" => "GST Number is valid.",
                "data" => $demo_gst_data[$gst_no]
            ];
        } else {
            $response = [
                "status" => false,
                "message" => "Invalid GST Number. Please provide a valid GST number."
            ];
        }
        return $this->response->setJSON($response)->setStatusCode(200);
    }
    public function upload_product_images($product_id, $product_images)
    {
        $seller_model = $this->init_SellerModel();
        $uploaded_images = [];

        foreach ($product_images['name'] as $i => $image_name) {
            $unique_image_ID = $this->GUID('IMG');
            $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);

            if (empty($file_extension)) {
                return [
                    'status' => false,
                    'message' => 'Invalid file extension.',
                    'data' => []
                ];
            }
            $file_save_path = 'assets/uploads/product_images/' . $unique_image_ID . '.' . $file_extension;
            $file_upload_path = FCPATH . $file_save_path;
            if (move_uploaded_file($product_images['tmp_name'][$i], $file_upload_path)) {
                $seller_model->add_product_image([
                    'uId' => $unique_image_ID,
                    'prodId' => $product_id,
                    'imageUrl' => $file_save_path,
                    'createdAt' => date('Y-m-d H:i:s'),
                    'updatedAt' => date('Y-m-d H:i:s')
                ]);

                // Collect successful upload results
                $uploaded_images[] = $file_save_path;
            } else {
                return [
                    'status' => false,
                    'message' => 'Failed to move uploaded file.',
                    'data' => []
                ];
            }
        }

        // If at least one image is uploaded successfully
        if (!empty($uploaded_images)) {
            return [
                'status' => true,
                'message' => 'Image(s) uploaded successfully.',
                'file_paths' => $uploaded_images
            ];
        }

        return [
            'status' => false,
            'message' => 'No images were uploaded.',
            'data' => []
        ];
    }

    public function only_for_product_image_upload()
    {
        $this->validation->setRuleGroup('only_for_product_image_upload');

        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $productId = $valid_data['productId'];

            if (isset($_FILES['images']['name'])) {
                $uploadResult = $this->upload_product_images($productId, $_FILES['images']);

                if ($uploadResult['status'] === true) {
                    $response = [
                        "status" => true,
                        "message" => $uploadResult['message'],
                        "data" => [
                            'prodID' => $productId,
                            'imageUrls' => array_map(function ($path) {
                                return base_url($path);
                            }, $uploadResult['file_paths'])
                        ]
                    ];
                } else {
                    $response = [
                        "status" => false,
                        "message" => $uploadResult['message'],
                        "data" => []
                    ];
                }
            } else {
                $response = [
                    "status" => false,
                    "message" => "No image selected for upload.",
                    "data" => []
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0],
                "data" => []
            ];
        }

        return $this->send_response($response, 200);
    }

    private  function send_push_notification_buyer($title, $body, $imageUrl)
    {
        $sellerModel = $this->init_SellerModel();
        $buyers = $sellerModel->get_buyers_with_fcm_tokens();
        if (empty($buyers)) {
            return ['status' => false, 'message' => 'No buyers found with valid FCM tokens.'];
        }

        $authenticationData = $this->getFirebaseAuthenticationData();
        $projectId = $authenticationData['project_id'];
        $token = $authenticationData['access_token'];

        if (empty($projectId) || empty($token)) {
            return ['status' => false, 'message' => 'Firebase authentication data is invalid.'];
        }

        $results = [];
        foreach ($buyers as $buyer) {
            if (empty($buyer->fcm_token)) {
                continue;
            }

            $FCM_token = $buyer->fcm_token;

            $jsonData = [
                "message" => [
                    "notification" => [
                        "title" => $title,
                        "body"  => $body,
                        "image"  => base_url($imageUrl)
                    ],
                    "token" => $FCM_token,
                ],
            ];
            $jsonString = json_encode($jsonData);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonString);

            $headers = [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
            ];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);

            if (curl_errno($ch)) {
                $results[] = [
                    'buyer' => $buyer->name,
                    'status' => false,
                    'error' => curl_error($ch),
                ];
            } else {
                $results[] = [
                    'buyer' => $buyer->name,
                    'status' => true,
                    'response' => json_decode($result, true),
                ];
            }
            curl_close($ch);
        }
        return $results;
    }

    private function getFirebaseAuthenticationData()
    {
        $getJsonFile = file_get_contents(APPPATH . 'Controllers/Buyer/firebase-service.json', true);
        $jsonData = json_decode($getJsonFile, true);
        $newTime = time();
        $privateKey = $jsonData['private_key'];
        $payload = [
            'iss' => $jsonData['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => $jsonData['token_uri'],
            'exp' => $newTime + (60 * 60),
            'iat' => $newTime
        ];
        $jwt = jwt::encode($payload, $privateKey, 'RS256');
        $ch = curl_init();
        $post = [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ];
        $ch = curl_init($jsonData['token_uri']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $response = curl_exec($ch);
        curl_close($ch);
        $jsonObj = json_decode($response, true);
        return ["project_id" => $jsonData['project_id'], "access_token" => $jsonObj['access_token']];
    }
}
