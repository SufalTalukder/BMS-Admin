<?php

namespace App\Controllers\Seller;


use App\Controllers\Seller\Common;

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

require_once(APPPATH . 'ThirdParty/firebase/php-jwt/src/JWT.php');
require_once(APPPATH . 'ThirdParty/firebase/php-jwt/src/Key.php');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class ChatApiController extends Common
{
    public function connect_buyer_seller_for_start_chat()
    {
        $this->validation->setRuleGroup('send_friend_request');
        if ($this->validation->withRequest($this->request)->run()) {
            $chatModel = $this->init_ChatFriendModel();
            $valid_data = $this->validation->getValidated();
            $existingChat = $chatModel
                ->select('chat_id')
                ->groupStart()
                ->where('user_id', $valid_data['userId'])
                ->where('friend_id', $valid_data['friendId'])
                ->groupEnd()
                ->orGroupStart()
                ->where('user_id', $valid_data['friendId'])
                ->where('friend_id', $valid_data['userId'])
                ->groupEnd()
                ->get()
                ->getRow();
            if ($existingChat) {
                $response = [
                    'status' => true,
                    'message' => 'You are already friend ',
                    'data' => ['chatId' => $existingChat->chat_id]
                ];
            } else {
                $chatId = $this->GUID('CHAT');
                $data = [
                    [
                        'chat_id' => $chatId,
                        'user_id' => $valid_data['userId'],
                        'friend_id' => $valid_data['friendId']
                    ],
                    [
                        'chat_id' => $chatId,
                        'user_id' => $valid_data['friendId'],
                        'friend_id' => $valid_data['userId']
                    ]
                ];
                $friendRequest = $chatModel->insertBatch($data);
                if ($friendRequest) {
                    $response = [
                        'status' => true,
                        'message' => 'Friend request sent successfully',
                        'data' => ['chatId' => $chatId]
                    ];
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Failed to send friend request'
                    ];
                }
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $error_messages = array_values($validation_errors);
            $response = [
                "status" => false,
                "message" => $error_messages[0]
            ];
        }

        return $this->send_response($response, 200);
    }

    public function send_friend_request()
    {
        $fcmToken = 'cVkOqzitRLubDlvKLA5FEL:APA91bEViys7JupG8y7UgZF8hYawVziqSTbdoda899OaNcsH8xRQVYRls0XsnCCBwsLTjT2mTOCX0TQ1rF8RsBTuxSMQjG7Q7aMtcDgvvNGFzfiGnCvmAQk'; // Replace with the FCM token you want to test
        $firebaseData = $this->getFirebaseAuthenticationData();
        // print_r($firebaseData) ;die  ; 
        if (!isset($firebaseData['access_token'])) {
            return $this->response->setJSON([
                'status' => false,
                'message' => 'Failed to generate access token.'
            ]);
        }

        $accessToken = $firebaseData['access_token'];
        $projectId = $firebaseData['project_id'];

        $url = "https://fcm.googleapis.com/v1/projects/$projectId/messages:send";
        $randNum = rand(100, 100);
        $notificationData = [
            'message' => [
                'token' => $fcmToken,
                'notification' => [
                    'title' => 'Test Notification' . $randNum,
                    'body' => 'This is a test notification from Firebase!',
                    'image' => "https://dev.v-xplore.com/ecommerce/assets/uploads/profile_images/USER_7751D21C-FC68-4EA1-8FFD-F63987235E57_1731999565.jfif",
                ],
                'data' => [
                    'key1' => 'value1',
                    'key2' => 'value2'
                ]
            ]
        ];
        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notificationData));

        $response = curl_exec($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($httpStatus == 200) {
            return $this->response->setJSON([
                'status' => true,
                'message' => 'Notification sent successfully!',
                'response' => json_decode($response)
            ]);
        } else {
            return $this->response->setJSON([
                'status' => false,
                'message' => 'Failed to send notification',
                'response' => json_decode($response)
            ]);
        }
    }

    public function getChatMessages($chatId)
    {
        $chatModel = $this->init_ChatModel();
        $chatFriendModel = $this->init_ChatFriendModel();
        $request_data = $this->request->getVar();
        if (!empty($request_data['user_id'])) {
            $messages = $chatModel->getMessagesByChatId($chatId);
            if ($messages) {
                $updateResult = $chatFriendModel
                    ->set('unread_count', 0)
                    ->where('user_id', $request_data['user_id'])
                    ->where('chat_id', $chatId)
                    ->update();
                if (!$updateResult) {
                    print_r('error', 'Failed to reset unread_count for user_id: ' . $request_data['user_id'] . ' in chat_id: ' . $chatId);
                }
                $response = [
                    'status' => true,
                    'message' => 'Message List Retrieved Successfully',
                    'data' => $messages
                ];
            } else {
                $response = [
                    'status' => false,
                    'message' => 'No Messages Found',
                    'data' => []
                ];
            }
        } else {
            $response = [
                'status' => false,
                'message' => 'User ID is required to fetch messages',
                'data' => []
            ];
        }
        return $this->send_response($response, 200);
    }
    // public function getFriendList()
    // {
    //     $model = $this->init_ChatFriendModel();
    //     $request_data = $this->request->getVar();

    //     if (!empty($request_data['id'])) {
    //         $friends_list = [];
    //         $friends_data = $model->select('friend_id, chat_id, unread_count')
    //             ->where('user_id', $request_data['id'])
    //             ->orderBy('unread_count', 'DESC')
    //             ->get()
    //             ->getResult();
    //         if (!empty($friends_data)) {
    //             $userModel = $this->init_userModel();
    //             $chatModel = $this->init_ChatModel();
    //             foreach ($friends_data as $friend) {
    //                 $user_data = $userModel->select("name, profileImageLink AS ProfileImage")
    //                     ->where('uId', $friend->friend_id)
    //                     ->get()
    //                     ->getRow();
    //                 $last_message_data = $chatModel->select('sender_user_id AS senderId, type, content, created_at AS sendTime')
    //                     ->where(['chat_id' => $friend->chat_id, 'status' => 'ACTIVE'])
    //                     ->orderBy('created_at', 'DESC')
    //                     ->get()
    //                     ->getRow();
    //                 if (!empty($last_message_data)) {
    //                     $sendTime = new \DateTime($last_message_data->sendTime);
    //                     $currentTime = new \DateTime();
    //                     $timeDifference = $currentTime->diff($sendTime);
    //                     if ($timeDifference->days < 1) { // Within 24 hours
    //                         $last_message_data->sendTime = $sendTime->format('H:i A');
    //                     } else { // More than 24 hours
    //                         $last_message_data->sendTime = $sendTime->format('Y-m-d');
    //                     }
    //                 }
    //                 $friends_list[] = [
    //                     'friend_id' => $friend->friend_id,
    //                     'chat_id' => $friend->chat_id,
    //                     'name' => $user_data->name ?? 'Unknown',
    //                     'profileImage' => !empty($user_data->ProfileImage) ? base_url($user_data->ProfileImage) : null,
    //                     'lastMessage' => $last_message_data,
    //                     'unreadCount' => $friend->unread_count
    //                 ];
    //             }

    //             $response = [
    //                 "status" => true,
    //                 "message" => "Friends list retrieved successfully.",
    //                 "data" => $friends_list
    //             ];
    //         } else {
    //             $response = [
    //                 "status" => false,
    //                 "message" => "No friends found.",
    //                 "data" => []
    //             ];
    //         }
    //     } else {
    //         $response = [
    //             "status" => false,
    //             "message" => "Please provide your user ID to retrieve the friends list!",
    //             "data" => []
    //         ];
    //     }
    //     return $this->send_response($response, 200);
    // }


    public function getFriendList()
    {
        $model = $this->init_ChatFriendModel();
        $request_data = $this->request->getVar();

        if (!empty($request_data['id'])) {
            $friends_list = [];
            $friends_data = $model->select('friend_id, chat_id, unread_count')
                ->where('user_id', $request_data['id'])
                ->orderBy('unread_count', 'DESC')
                ->get()
                ->getResult();

            if (!empty($friends_data)) {
                $userModel = $this->init_userModel();
                $chatModel = $this->init_ChatModel();
                foreach ($friends_data as $friend) {
                    $user_data = $userModel->select("userType, name AS UserName, profileImageLink AS ProfileImage")
                        ->where('uId', $friend->friend_id)
                        ->get()
                        ->getRow();


                    $profileImage = null;
                    $name = null;
                    if (!empty($user_data)) {
                        if ($user_data->userType === USER_TYPE_SELLER) {
                            $store_data = $this->db->table('store')->select('logoUrl , name ')
                                ->where('userId', $friend->friend_id)
                                ->get()
                                ->getRow();
                            $name = !empty($store_data->name) ?  $store_data->name : null;
                            $profileImage = !empty($store_data->logoUrl) ? base_url($store_data->logoUrl) : null;
                        } else {
                            $profileImage = !empty($user_data->ProfileImage) ? base_url($user_data->ProfileImage) : null;
                            $name = !empty($user_data->UserName) ? $user_data->UserName : null;
                        }
                    }

                    $last_message_data = $chatModel->select('sender_user_id AS senderId, type, content, created_at AS sendTime')
                        ->where(['chat_id' => $friend->chat_id, 'status' => STATE_ENUM_ACTIVE])
                        ->orderBy('created_at', 'DESC')
                        ->get()
                        ->getRow();

                    if ($last_message_data) { // Check if data exists
                        $sendTime = new \DateTime($last_message_data->sendTime, new \DateTimeZone('UTC'));
                        $currentTime = new \DateTime('now', new \DateTimeZone('Asia/Kolkata'));
                        $sendTime->setTimezone(new \DateTimeZone('Asia/Kolkata'));
                        $timeDifference = $currentTime->diff($sendTime);
                        if ($timeDifference->days < 1) { // Within 24 hours
                            $last_message_data->sendTime = $sendTime->format('h:i A'); // 12-hour format with AM/PM
                        } else { // More than 24 hours
                            $last_message_data->sendTime = $sendTime->format('d/m/Y');
                        }
                    } else {
                        $last_message_data = null; // Handle the case where no last message exists
                    }



                    $friends_list[] = [
                        'friend_id' => $friend->friend_id,
                        'chat_id' => $friend->chat_id,
                        'name' => $name,
                        'profileImage' => $profileImage,
                        'lastMessage' => $last_message_data,
                        'unreadCount' => $friend->unread_count
                    ];
                }

                $response = [
                    "status" => true,
                    "message" => "Friends list retrieved successfully.",
                    "data" => $friends_list
                ];
            } else {
                $response = [
                    "status" => false,
                    "message" => "No friends found.",
                    "data" => []
                ];
            }
        } else {
            $response = [
                "status" => false,
                "message" => "Please provide your user ID to retrieve the friends list!",
                "data" => []
            ];
        }
        return $this->send_response($response, 200);
    }


    // public function sendMessage()
    // {
    //     $this->validation->setRuleGroup('send_chat_message');
    //     if ($this->validation->withRequest($this->request)->run()) {
    //         $valid_data = $this->validation->getValidated();
    //         $chatModel = $this->init_ChatModel();
    //         $chatFriendModel = $this->init_ChatFriendModel();
    //         $messagesId = $this->GUID('MESS');
    //         $current_datetime = $this->current_datetime;
    //         if ($valid_data['type'] == 'TEXT') {
    //             $data = [
    //                 'uId' => $messagesId,
    //                 'chat_id' => $valid_data['chatId'],
    //                 'sender_user_id' => $valid_data['senderUserId'],
    //                 'receiver_user_id' => $valid_data['receiverUserId'],
    //                 'content' => $valid_data['content'],
    //                 'type' => $valid_data['type'],
    //                 'created_at' => $current_datetime,
    //             ];
    //             $sendMessage = $chatModel->insert($data);
    //             if ($sendMessage) {
    //                 $friendRecord = $chatFriendModel->where('chat_id', $valid_data['chatId'])
    //                     ->where('user_id', $valid_data['receiverUserId'])
    //                     ->first();
    //                 if ($friendRecord) {
    //                     if ($valid_data['receiverUserId'] != $valid_data['senderUserId']) {
    //                         $update = $chatFriendModel->set('unread_count', 'unread_count + 1', false)
    //                             ->where('user_id', $valid_data['receiverUserId'])
    //                             ->where('chat_id', $valid_data['chatId'])
    //                             ->update();
    //                         if ($update) {
    //                             $response = [
    //                                 'status' => true,
    //                                 'message' => 'Message Sent SuccessFully.',
    //                             ];
    //                         } else {
    //                             $response = [
    //                                 'status' => false,
    //                                 'message' => 'Message Sent but Failed to Update Unread Count for Receiver.',
    //                             ];
    //                         }
    //                     }
    //                 } else {
    //                     $response = [
    //                         'status' => false,
    //                         'message' => 'No existing chat_friend record found for receiver.',
    //                     ];
    //                 }
    //             } else {
    //                 $response = [
    //                     'status' => false,
    //                     'message' => 'Failed to send message.',
    //                 ];
    //             }
    //         } else {
    //             $response = [
    //                 'status' => false,
    //                 'message' => 'Other types of chat are not supported!',
    //             ];
    //         }
    //     } else {
    //         $validation_errors = $this->validation->getErrors();
    //         $error_messages = array_values($validation_errors);
    //         $response = [
    //             "status" => false,
    //             "message" => $error_messages[0],
    //         ];
    //     }

    //     return $this->send_response($response, 200);
    // }

    public function sendMessage()
    {
        $this->validation->setRuleGroup('send_chat_message');
        if ($this->validation->withRequest($this->request)->run()) {
            $valid_data = $this->validation->getValidated();
            $chatModel = $this->init_ChatModel();
            $chatFriendModel = $this->init_ChatFriendModel();

            $messageId = $this->GUID('MESS');
            $current_datetime = $this->current_datetime;

            $data = [
                'uId' => $messageId,
                'chat_id' => $valid_data['chatId'],
                'sender_user_id' => $valid_data['senderUserId'],
                'receiver_user_id' => $valid_data['receiverUserId'],
                'content' => $valid_data['content'],
                'created_at' => $current_datetime,
            ];
            $sendMessage = $chatModel->insert($data);
            if ($sendMessage) {
                $updateUnread = $chatFriendModel->set('unread_count', 'unread_count + 1', false)
                    ->where('user_id', $valid_data['receiverUserId'])
                    ->where('chat_id', $valid_data['chatId'])
                    ->update();
                $receiverData = $this->getUserDetails($valid_data['receiverUserId']);
                if ($receiverData && $receiverData['fcm_token']) {
                    $this->sendPushNotification($receiverData['fcm_token'], [
                        'title' => 'New Message from ' ,
                        'body' => $valid_data['content'],
                        'chatId' => $valid_data['chatId'],
                    ], $receiverData['userType']);
                }
                $response = [
                    'status' => true,
                    'message' => 'Message sent successfully.',
                ];
            } else {
                $response = [
                    'status' => false,
                    'message' => 'Failed to send the message.',
                ];
            }
        } else {
            $validation_errors = $this->validation->getErrors();
            $response = [
                'status' => false,
                'message' => array_values($validation_errors)[0],
            ];
        }

        return $this->send_response($response, 200);
    }

    public function sendPushNotification($fcmToken, $messageData, $appType)
    {
        $firebaseAuth = $this->getFirebaseAuthentication($appType);
        $fcmUrl = 'https://fcm.googleapis.com/v1/projects/' . $firebaseAuth['project_id'] . '/messages:send';
        $notificationData = [
            'message' => [
                'token' => $fcmToken,
                'notification' => [
                    'title' => $messageData['title'],
                    'body' => $messageData['body'],
                ],
                'data' => [
                    'chatId' => $messageData['chatId'],
                ],
            ],
        ];

        $headers = [
            'Authorization: Bearer ' . $firebaseAuth['access_token'],
            'Content-Type: application/json',
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $fcmUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notificationData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    private function getUserDetails($userId)
    {
        $builder = $this->db->table('user_accounts');
        $builder->select('uId, name, userType, fcm_token');
        $builder->where('uId', $userId);
        $user = $builder->get()->getRowArray();
        if ($user) {
            return $user;
        }
        return null;
    }

    private function getFirebaseAuthentication($appType)
    {
        $folderName = ucfirst(strtolower($appType));
        $filePath = APPPATH . "Controllers/" . ucfirst($folderName) . "/firebase-service.json";
        if (!file_exists($filePath)) {
            throw new Exception("Firebase configuration file not found for $folderName.");
        }

        $jsonInfo = json_decode(file_get_contents($filePath), true);
        $now_seconds = time();
        $privateKey = $jsonInfo['private_key'];

        $payload = [
            'iss' => $jsonInfo['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => $jsonInfo['token_uri'],
            'exp' => $now_seconds + (60 * 60), // Expire after 1 hour.                               
            'iat' => $now_seconds
        ];
        $jwt = JWT::encode($payload, $privateKey, 'RS256');
        $ch = curl_init();
        $post = [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ];
        curl_setopt($ch, CURLOPT_URL, $jsonInfo['token_uri']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $response = curl_exec($ch);
        curl_close($ch);
        $jsonObj = json_decode($response, true);

        if (isset($jsonObj['access_token'])) {
            return ["project_id" => $jsonInfo['project_id'], "access_token" => $jsonObj['access_token']];
        } else {
            throw new Exception("Failed to authenticate with Firebase for $appType.");
        }
    }
}
