<?php

namespace App\Controllers\Seller;


use App\Controllers\Seller\Common;

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

class sendPushNotification extends Common
{
    public function generateAccessToken()
    {
        $jsonInfo = json_decode(file_get_contents(APPPATH . 'Controllers/Seller/firebase-service.json'), true);

        $now_seconds = time();
        $privateKey = $jsonInfo['private_key'];
        $payload = [
            'iss' => $jsonInfo['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => $jsonInfo['token_uri'],
            'exp' => $now_seconds + (60 * 60),
            'iat' => $now_seconds
        ];
        print_r($payload);
        die;
        $jwt = JWT::encode($payload, $privateKey, 'RS256');
        $ch = curl_init();
        $post = [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ];

        $ch = curl_init($jsonInfo['token_uri']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

        // execute!
        $response = curl_exec($ch);

        // close the connection, release resources used
        curl_close($ch);

        // do anything you want with your response
        $jsonObj = json_decode($response, true);

        return ["project_id" => $jsonInfo['project_id'], "access_token" => $jsonObj['access_token']];
    }
}
