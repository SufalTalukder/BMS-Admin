<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions</title>
    <style>
        /* Reset */
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Lato', sans-serif;
            line-height: 1.6;
            background-color: #f4f6f9;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 850px;
            margin: 0 auto;
            padding: 40px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            font-size: 2.8em;
            color: #2c3e50;
            margin-bottom: 30px;
            font-weight: 700;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            text-transform: uppercase;
        }

        h2 {
            font-size: 1.8em;
            color: #3498db;
            margin-top: 35px;
            margin-bottom: 15px;
            font-weight: 600;
            border-left: 6px solid #3498db;
            padding-left: 15px;
            text-transform: uppercase;
        }

        p {
            margin-bottom: 20px;
            line-height: 1.7;
            font-size: 1.1em;
            color: #555;
        }

        ul {
            list-style-type: disc;
            margin: 10px 0 20px 40px;
            color: #666;
            font-size: 1em;
        }

        li {
            margin-bottom: 10px;
        }

        .section {
            margin-bottom: 35px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eaeaea;
        }

        footer {
            text-align: center;
            font-size: 0.9em;
            color: #999;
            margin-top: 30px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }

        /* Buttons (optional if you have links or call-to-action items) */
        a.button {
            display: inline-block;
            background-color: #3498db;
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        a.button:hover {
            background-color: #2980b9;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 20px;
            }

            h1 {
                font-size: 2.2em;
            }

            h2 {
                font-size: 1.6em;
            }
        }
    </style>
</head>

<body>

    <div class="container">
        <h1>Terms and Conditions</h1>

        <div class="section">
            <h2>1. Acceptance of Terms</h2>
            <p>By accessing and using our services, you agree to comply with these Terms and Conditions. If you do not agree to any part of these terms, you may not use our services.</p>
        </div>

        <div class="section">
            <h2>2. Use of the Service</h2>
            <p>You agree to use our service only for lawful purposes. You are prohibited from using the service to:</p>
            <ul>
                <li>Violate any laws or regulations.</li>
                <li>Infringe upon the intellectual property rights of others.</li>
                <li>Harass, abuse, or harm others.</li>
                <li>Distribute harmful or malicious content.</li>
            </ul>
        </div>

        <div class="section">
            <h2>3. Account Registration</h2>
            <p>If you are required to create an account, you agree to provide accurate and complete information. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>
        </div>

        <div class="section">
            <h2>4. Termination</h2>
            <p>We reserve the right to suspend or terminate your access to our service at any time, without notice, if we believe you have violated these Terms and Conditions.</p>
        </div>

        <div class="section">
            <h2>5. Intellectual Property</h2>
            <p>All content, trademarks, and other intellectual property on this service are owned by us or our licensors. You may not use any content from the service without our prior written permission.</p>
        </div>

        <div class="section">
            <h2>6. Limitation of Liability</h2>
            <p>To the extent permitted by law, we shall not be liable for any damages that result from the use of, or inability to use, our service. This includes, but is not limited to, damages for errors, omissions, interruptions, or delays in the service.</p>
        </div>

        <div class="section">
            <h2>7. Changes to Terms</h2>
            <p>We may modify these Terms and Conditions at any time. Changes will be effective immediately upon posting. It is your responsibility to review these terms periodically for updates.</p>
        </div>

        <div class="section">
            <h2>8. Governing Law</h2>
            <p>These Terms and Conditions shall be governed by and construed in accordance with the laws of [Your Jurisdiction]. Any disputes relating to these terms will be subject to the exclusive jurisdiction of the courts of [Your Jurisdiction].</p>
        </div>

        <div class="section">
            <h2>9. Contact Us</h2>
            <p>If you have any questions about these Terms and Conditions, please contact us at: <a href="mailto:support@example.com">support@example.com</a></p>
        </div>

        <footer>
            &copy; 2023 Your Company Name. All Rights Reserved.
        </footer>
    </div>

</body>

</html>