<main id="main" class="main">

    <div class="pagetitle">
        <h1>Push Notification</h1>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="card-body p-3 ">
                        <table id="customerQuery" class="table .table-striped .table-hover datatable  ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Description</th>

                                    <th>imageUrl</th>
                                    <th>Create </th>


                                    <th>Update</th>
                                    <th>status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($getPushNotifications as $i => $PushNotification) { ?>
                                    <tr>
                                        <td><?= $i + 1  ?></td>
                                        <td><?= $PushNotification->notificationTitle ?></td>
                                        <td><?= $PushNotification->notificationDescription ?></td>
                                        <td>
                                            <?php $img =  base_url($PushNotification->imageUrl) ?>
                                            <img src="<?= $img ?>" height="40px" width="40px">
                                        </td>
                                        <td><?= date('d/m/Y', strtotime($PushNotification->createdAt)) . '<br/>' . date('h:i ', strtotime($PushNotification->createdAt)) ?></td>
                                        <td><?= date('d/m/Y', strtotime($PushNotification->updatedAt)) . '<br/>' . date('h:i ', strtotime($PushNotification->updatedAt)) ?></td>
                                        <td><?php
                                            if ($PushNotification->state == PUSH_NOTIFICATION_INACTIVE) {
                                                echo '<span class="badge text-dark bg-warning rounded">Inactive</span>';
                                            } elseif ($PushNotification->state == PUSH_NOTIFICATION_ACTIVE) {
                                                echo '<span class="badge bg-success rounded">Active</span>';
                                            } elseif ($PushNotification->state == PUSH_NOTIFICATION_DELETED) {
                                                echo '<span class="badge bg-danger rounded">Delete</span>';
                                            }
                                            ?></td>


                                    </tr>
                                <?php } ?>
                            </tbody>

                        </table>

                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->
<script>
    $(document).ready(function() {
        $('#customerQuery').DataTable();
    });
</script>