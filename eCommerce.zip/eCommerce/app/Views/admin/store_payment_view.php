<main id="main" class="main">

    <div class="pagetitle">
        <h1>Store Payment</h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="card-body p-3">
                        <table id="paymentTable" class="table table-hover ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><b>Store</b></th>
                                    <th>Buyer</th>
                                    <th>Pay Amount</th>
                                    <th>Discount Amount </th>
                                    <th>Final Amount</th>
                                    <th>Pay Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php foreach ($store_payments as $i => $payment) { ?>
                                    <tr>
                                        <td><?= $i + 1 ?></td>
                                        <td><a href="<?= base_url('admin/store/') . $payment->storeId ?>"><?= $payment->storeName ?></a></td>
                                        <td><a href="<?= base_url('admin/buyer/') . $payment->userId ?>"><?= $payment->userName ?></a></td>
                                        <td><?= $payment->payAmount ?></td>
                                        <td><?= ($payment->discount) ?></td>
                                        <td><?= ($payment->finalAmount) ?></td>
                                        <td><?= date('d/m/Y', strtotime($payment->createdAt)) . '<br/>' . date('h:i A', strtotime($payment->createdAt)) ?></td>
                                        <td>
                                            <?php
                                            if ($payment->status == STORE_PAYMENT_STATUS_PENDING) {
                                                echo '<span class="badge rounded bg-warning text-white">Pending</span>';
                                            } elseif ($payment->status == STORE_PAYMENT_STATUS_SUCCESS) {
                                                echo '<span class="badge rounded bg-success text-white">Success</span>';
                                            } elseif ($payment->status == STORE_PAYMENT_STATUS_FAILED) {
                                                echo '<span class="badge rounded bg-danger text-white">Failed</span>';
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        $(document).ready(function() {
            $('#paymentTable').DataTable();
        });
    </script>