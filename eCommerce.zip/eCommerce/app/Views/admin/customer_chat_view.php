<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Box</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Chat Container */
        .chat-container {
            max-width: 50%;
            width: 90%;
            height: 600px;
            margin: 50px auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            background-color: #e5ddd5;
        }

        /* Chat Header */
        .chat-header {
            background-color: #075e54;
            color: #fff;
            padding: 10px 15px;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #ccc;
        }

        .chat-header .chat-title {
            font-weight: bold;
        }

        .chat-header .chat-options {
            font-size: 16px;
            cursor: pointer;
        }

        /* Chat Messages */
        .chat-messages {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background-color: #d9d9d9;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        /* Individual Messages */
        .message {
            max-width: 75%;
            padding: 10px 15px;
            border-radius: 10px;
            font-size: 14px;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* Received Messages */
        .message.received {
            background-color: #fff;
            align-self: flex-start;
        }

        .message.received::after {
            content: "";
            position: absolute;
            top: 0;
            left: -10px;
            border-width: 10px;
            border-style: solid;
            border-color: transparent #fff transparent transparent;
        }

        /* Sent Messages */
        .message.sent {
            background-color: #dcf8c6;
            align-self: flex-end;
        }

        .message.sent::after {
            content: "";
            position: absolute;
            top: 0;
            right: -10px;
            border-width: 10px;
            border-style: solid;
            border-color: transparent transparent transparent #dcf8c6;
        }

        /* Timestamps */
        .message .time {
            font-size: 10px;
            margin-top: 5px;
            color: #999;
            align-self: flex-end;
        }

        /* Chat Input */
        .chat-input {
            display: flex;
            padding: 10px;
            border-top: 1px solid #ccc;
            background-color: #fff;
        }

        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
        }

        .chat-input button {
            margin-left: 10px;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            background-color: #075e54;
            color: #fff;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .chat-input button:hover {
            background-color: #064839;
        }

        /* Responsive Design */
        @media (max-width: 500px) {
            .chat-container {
                width: 100%;
                height: 100vh;
            }
        }
    </style>

</head>

<body>
    <div class="chat-container">
        <div class="chat-header">
            <h3>Chat Box</h3>
        </div>
        <div class="chat-messages">
            <div class="message received">
                <p>Hello! How can I help you?</p>
                <span class="time">10:30 AM</span>
            </div>
            <div class="message sent">
                <p>Hi! I need some help.</p>
                <span class="time">10:31 AM</span>
            </div>
        </div>
      
    </div>
</body>

</html>