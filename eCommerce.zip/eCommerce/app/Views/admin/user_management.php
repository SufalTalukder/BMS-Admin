<main id="main" class="main">

    <div class="pagetitle">
        <h1>User Management</h1>

    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">

                        <table id="myTable" class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>
                                        <b>N</b>ame
                                    </th>
                                    <th>Mobile Number</th>
                                    <th>Email</th>
                                    <!-- <th data-type="date" data-format="YYYY/DD/MM">Start Date</th> -->
                                    <th>User Type</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="9">
                                        <center>User List Loading...</center>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>


            </div>
        </div>
    </section>
</main>

<script>
    $(document).ready(function() {

        function fetchUserData() {
            $.ajax({
                url: "<?= base_url('fetch/user') ?>",
                type: 'POST',
                dataType: 'json',
                success: function(response) {
                    if (response.status) {

                        $('.tbody').empty();

                        $.each(response.data, function(index, user) {
                            // console.log("User Data: ", user);
                            $('.tbody').append(`
                            <tr>
                                <td>${user.id}</td>
                                <td>${user.name}</td>
                                <td>${user.mobileNo}</td>
                                <td>${user.email}</td>
                                <td>${user.userType}</td>
                                 <td>
                                <div class="d-flex gap-2 align-items-center">
                                    <a class="editbtn bgedit bg-primary pointer" title="visit property" onclick="visit_url('')">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </div>
                            </td>
                                
                            </tr>
                        `);
                        });
                    } else {
                        alert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    alert("An error occurred while fetching user data.");
                }
            });
        }
        fetchUserData();
    });
  
</script>