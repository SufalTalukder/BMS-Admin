<style>
    #basicModal .modal-dialog {
        max-width: 600px;
        width: 100%;
    }

    #basicModal .modal-content {
        padding: 20px;
    }

    .modal-body {
        max-height: 400px;
        overflow-y: auto;

    }
</style>
<main id="main" class="main">

    <div class="pagetitle d-flex justify-content-between align-items-center">
        <h1 class="mb-0">Store Category</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal">
            Add Category
        </button>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body p-3">
                        <!-- Table with stripped rows -->
                        <table id="table" class="table datatable table-sm  table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>

                                    <th>
                                        <b></b>Name
                                    </th>
                                    <th data-type="date" data-format="YYYY/DD/MM">Created  </th>
                                    <th data-type="date" data-format="YYYY/DD/MM">Update  </th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="S-category">
                                <tr>
                                    <td colspan="9">
                                        <center>Store Category List Loading...</center>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

    <div class="modal fade" id="basicModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Basic Modal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Add Store Category </h5>
                            <!-- General Form Elements -->
                            <form id="add_category">
                                <div class="row mb-3">
                                    <label for="inputText" class="col-sm-4 col-form-label">Category Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="categoryName">
                                    </div>
                                </div>
                            </form><!-- End General Form Elements -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                    <button type="button" id="btn_add" class="btn btn-primary">Add Now</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Form Start here  -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Basic Modal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Edit Store Category </h5>
                            <!-- General Form Elements -->
                            <form id="editFrom">
                                <div class="row mb-3">
                                    <input type="hidden" id="editCategoryId" name="uId">
                                    <label for="inputText" class="col-sm-4 col-form-label">Category Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="categoryName"
                                            id="editCategoryName">
                                    </div>
                                </div>
                            </form><!-- End General Form Elements -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                    <button type="button" id="update_button" class="btn btn-primary">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit From End Here -->
</main>
<script>
 
    const STORE_CATEGORY_ACTIVE = '<?= STORE_CATEGORY_ACTIVE ?>';
    const STORE_CATEGORY_INACTIVE = '<?= STORE_CATEGORY_INACTIVE ?>';
    const STORE_CATEGORY_DELETED = '<?= STORE_CATEGORY_DELETED ?>';
    $(document).ready(function() {
        function categoryFetch() {
            $.ajax({
                url: "<?= base_url('fetch/store-category') ?>",
                type: 'POST',
                dataType: "JSON",
                success: function(response) {
                    if (response.status) {
                        $('.datatable tbody').empty();
                        let counter = 1;
                        $.each(response.data, function(index, category) {
                            let statusText, statusClass;
                            if (category.state == STORE_CATEGORY_DELETED) {
                                statusText = 'Deleted';
                                statusClass = 'badge bg-danger rounded';
                            } else if (category.state == STORE_CATEGORY_ACTIVE) {
                                statusText = 'Active';
                                statusClass = 'badge bg-success rounded';
                            } else if (category.state == STORE_CATEGORY_INACTIVE) {
                                statusText = 'Inactive';
                                statusClass = 'badge bg-warning text-dark rounded';
                            } else {
                                statusText = 'Unknown';
                                statusClass = 'badge bg-secondary rounded';
                            }
                            $('.datatable tbody').append(`
                                <tr>
                                    <td>${counter}</td>
                                    <td>${category.categoryName}</td>
                                    <td>${formatDate(category.createdAt)}</td>
                                    <td>${formatDate(category.updatedAt)}</td>
                                    <td><span class="${statusClass}">${statusText}</span></td>
                                    <td>
                                        // <button  class="btn btn-sm btn-info rounded-pill title="Edit Category" onclick="return editCategory('${category.uId}') "  ${category.state == STORE_CATEGORY_DELETED ? 'disabled' : ''}>
                                           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                            </svg>
                                        </button>
                                        <button class="btn btn-danger btn-sm rounded-pill"   onclick="return deleteCategory('${category.uId}')" ${category.state == STORE_CATEGORY_DELETED ? 'disabled' : ''} >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                                <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                            </svg>
                                        </button>
                                    </td>
                                </tr>`);
                            counter++;
                        });
                        $('#table').DataTable()
                        $('[title]').tooltip();
                    } else {
                        console.error('Error: ', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                }
            });
        }
        categoryFetch();
    });
</script>



<script>
    function deleteCategory(uId) {
        if (confirm('Are you sure you want to delete this category?')) {
            $.ajax({
                url: "<?= base_url('/delete-category') ?>",
                method: "POST",
                data: {
                    uId: uId
                },
                dataType: "JSON",
                success: function(response) {
                    if (response.status == true) {
                        showToast("Category deleted successfully");
                        window.location.href = "<? base_url('admin/store/category') ?>";

                    } else {
                        showToast("Error: " + response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + error);
                    console.error("Response Text: " + xhr.responseText);
                    alert('An error occurred. Please try again.');
                }
            });
        }
    }
</script>

<script>
    $(document).ready(() => {
        $("#btn_add").click((e) => {
            e.preventDefault();
            let categoryName = $('#categoryName').val();
            if (!categoryName) {
                showToast("Category name is required");
                return;
            }
            let data = {
                name: categoryName
            };
            fetch('<?= base_url("/add-store-category") ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                })
                .then(response => response.json())
                .then(data => {
                    // Handle the response
                    if (data.status) {
                        showToast(data.message);
                        $('#add_category')[0].reset();
                        $('#basicModal').modal('hide');
                        setTimeout(() => {
                            window.location.reload();
                        }, 100);
                    } else {
                        showToast('Error: ' + data.message);
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    alert('An error occurred while processing the request.');
                });
        });
    });
</script>
<script>
    function editCategory(uId) {
        $.ajax({
            url: "<?= base_url('/edit-category') ?>",
            method: 'GET',
            data: {
                uId: uId
            },
            dataType: 'JSON',
            success: function(response) {
                if (response.status) {
                    const category = response.data[0];
                    $('#editCategoryName').val(category.categoryName);
                    $('#editCategoryId').val(category.uId); 
                    $('#editModal').modal('show'); 
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                alert("AJAX request failed.");
            }
        });
    }
</script>
<script>
    $(document).ready(function() {
        $('#editFrom').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                url: "<?= base_url('/update-category') ?>",
                method: "POST",
                data: formData,
                dataType: "JSON",
                success: function(response) {
                    if (response.status === true) {
                        showToast(response.message);
                        window.location.href = "<?= base_url('admin/store/category') ?> ";

                    } else {
                        showToast('Try Again');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Status: " + status);
                    console.error("Error: " + error);
                    console.error("Response Text: " + xhr.responseText);

                    alert('An error occurred while updating. Please check console for more details.');
                }
            });
        });
        $('#update_button').on('click', function() {
            $('#editFrom').submit();
        });
    });
</script>

