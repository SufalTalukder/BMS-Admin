<style>
  #basicModal .modal-dialog {
    max-width: 600px;
    width: 100%;
  }

  #basicModal .modal-content {
    padding: 20px;
  }

  .modal-body {
    max-height: 400px;
    overflow-y: auto;

  }

  .custom-modal-header {
    background-color: #C0392B;
    /* Dark Red Background */
    color: white;
    /* White Text Color */
  }

  .custom-modal-header .modal-title {
    font-weight: bold;
    /* Bold Text */
  }

  .red-bold {
    color: red;
    font-weight: bold;
  }
</style>
<main id="main" class="main">

  <div class="pagetitle d-flex justify-content-between align-items-center">
    <h1 class="mb-0">Product Category</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal">
      Add Category
    </button>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12 px-0">

        <div class="card">
          <div class="card-body p-3">
            <!-- Table with stripped rows -->
            <table class="table datatable table-sm  table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>
                    <b>N</b>ame
                  </th>

                  <th>Created At </th>
                  <th>Update At </th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="tcategory">
                <tr>
                  <td colspan="9">
                    <center>Category List Loading...</center>
                  </td>
                </tr>
              </tbody>
            </table>
            <!-- End Table with stripped rows -->

          </div>
        </div>

      </div>
    </div>
  </section>

  <div class="modal fade" id="basicModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header custom-modal-header ">
          <h5 class="modal-title  "> Add Product Category</h5>
          <button type="button" class="btn-close red-bold " data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <h5></h5>
              <form id="uploadForm">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-4 col-form-label"> Name</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" id="categoryName">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-4 col-form-label"> Image</label>
                  <div class="col-sm-8">
                    <input type="file" class="form-control" id="categoryImage">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
          <button type="button" id="addTypeBtn" class="btn btn-primary">Add Now</button>
        </div>
      </div>
    </div>
  </div>


  <!-- Edit Form Start here  -->
  <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Product Type</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Edit Product Type</h5>
              <!-- General Form Elements -->
              <form id="editForm" enctype="multipart/form-data">
                <input type="hidden" id="editProductCategoryId" name="uId">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-4 col-form-label">Name</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" id="editProductCategoryName">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-sm-12">
                    <img id="oldProductCategoryImage" src="" alt="Old Image" style="width: 100%; height: auto; margin-bottom: 10px;">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputFile" class="col-sm-4 col-form-label">Upload New Image</label>
                  <div class="col-sm-8">
                    <input type="file" class="form-control" name="image" id="editImageFile" accept="">
                    <!-- <img id="previewImage" src="" alt="Image Preview" style="display: none; margin-top: 10px; width: 100%; height: auto;"> -->
                  </div>
                </div>
              </form><!-- End General Form Elements -->
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" id="update_button" class="btn btn-primary">Edit</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Edit From End Here -->

  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
      <div class="modal-content text-center">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete this item?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
          <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  base_url = '<?= base_url();  ?>';
  let deleteCategoryId;

  function openEditModal(uId) {
    $.ajax({
      url: '<?= base_url('edit-product-category') ?>',
      method: 'GET',
      dataType: 'json ',
      data: {
        uId: uId
      },
      success: function(response) {
        if (response.status) {
          let category = response.data;
          $('#editProductCategoryId').val(category.uId);
          $('#editProductCategoryName').val(category.name);
          $('#oldProductCategoryImage').attr('src', base_url + category.imageUrl);
          $('#editModal').modal('show');
        } else {
          showToast('Not Found Any data ')
        }
      }

    });
  }
  $(document).ready(function() {
    $('#editForm').on('submit', function(e) {
      e.preventDefault();

      let formData = new FormData(this);
      console.log("Form Data:", formData);

      $.ajax({
        url: '<?= base_url('update-product-category') ?>',
        method: "POST",
        data: formData,
        dataType: "JSON",
        processData: false,
        contentType: false,
        success: function(response) {
          if (response.status == true) {
            showToast(response.message);
            location.reload();
          } else {
            showToast("Error! " + response.message);
          }
        },
        error: function(xhr, status, error) {
          console.error("AJAX Error:", xhr.responseText);
          console.error("Status:", status, "Error:", error);
          alert("An error occurred while updating the product category. Check the console for details.");
        }
      });
    });

    $('#update_button').on('click', function() {
      $('#editForm').submit();
    });
  });

  function openDeleteModel(uId) {
    deleteCategoryId = uId;
    console.log(deleteCategoryId);
    $('#deleteModal').modal('show')
  }
  $(document).ready(function() {
    $('#confirmDelete').on('click', function() {
      $.ajax({
        url: '<?= base_url('delete-product-category') ?>',
        method: "POST",
        data: {
          uId: deleteCategoryId
        },
        success: function(response) {
          if (response.status == true) {
            $('#deleteModal').modal('hide');
            location.reload();
          } else {
            showToast('Error' + response.message);
          }
        }
      });
    });
  });
</script>

<script>
  const PRODUCT_CATEGORY_STATE__ACTIVE = '<?= PRODUCT_CATEGORY_STATE__ACTIVE ?>';
  const PRODUCT_CATEGORY_STATE__INACTIVE = '<?= PRODUCT_CATEGORY_STATE__INACTIVE ?>';
  const PRODUCT_CATEGORY_STATE__DELETED = '<?= PRODUCT_CATEGORY_STATE__DELETED ?>';
  $(document).ready(function() {
    function fetchCategory() {
      $.ajax({
        url: "<?= base_url('fetch/product-category') ?>",
        method: "POST",
        dataType: "JSON",
        success: function(response) {
          if (response.status) {
            $('.datatable tbody').empty();
            $.each(response.data, function(i, category) {
              let img = "<?= base_url() ?>" + category.imageUrl;
              let statusText, statusClass;
              if (category.state == PRODUCT_CATEGORY_STATE__DELETED) {
                statusText = 'Deleted';
                statusClass = 'badge bg-danger rounded';
              } else if (category.state == PRODUCT_CATEGORY_STATE__ACTIVE) {
                statusText = 'Active';
                statusClass = 'badge bg-success rounded';
              } else if (category.state == PRODUCT_CATEGORY_STATE__INACTIVE) {
                statusText = 'Inactive';
                statusClass = 'badge bg-warning text-dark rounded';
              } else {
                statusText = 'Unknown';
                statusClass = 'badge bg-secondary rounded';
              }
              $('.datatable tbody').append(`
                            <tr> <!-- Added the tr element -->
                                <td>${i + 1}</td>
                                <td>
                                   <a href="${img}" target="_blank">
                                     <img src="${img}" alt="Image" style="height: 60px; width: 90px;">
                                  </a>
                                </td>
                                <td>${category.name}</td>
                                <td>${formatDate(category.createdAt)}</td>
                                <td>${formatDate(category.updatedAt)}</td>
                                <td><span class="${statusClass}">${statusText}</span></td>                                                                                      
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info rounded-pill" title="Edit Product Category" onclick="return openEditModal('${category.uId}');" ${category.state == PRODUCT_CATEGORY_STATE__DELETED ? 'disabled' : ''}  >
                                           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                            </svg>
                                        </button>
                                        <button type="button" class="btn btn-danger btn-sm rounded-pill"  onclick="return openDeleteModel('${category.uId}');" ${category.state == PRODUCT_CATEGORY_STATE__DELETED ? 'disabled' : '' } >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                                <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                            </svg>
                                        </button>
                                  </td>
                            </tr>
                        `);
            });
            $('.datatable').dataTable();
            $('[title]').tooltip();
          }
        }
      });
    }
    fetchCategory();

    $('#addTypeBtn').on('click', function(e) {
      e.preventDefault();
      let formData = new FormData($('#uploadForm')[0]);
      formData.append('name', $('#categoryName').val());
      formData.append('categoryImage', $('#categoryImage')[0].files[0]);
      $.ajax({
        url: "<?= base_url('/add-product-category') ?>",
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
          console.log(response);
          if (response.status) {
            showToast(response.message);
            $('#uploadForm')[0].reset();
            $('#basicModal').modal('hide');
            window.location.reload();
          } else {
            alert('Error: ' + response.message);
          }
        },
        error: function(xhr, status, error) {
          console.error('Upload error: ', error);
          alert('An error occurred while uploading the file.');
        }
      });
    });
  });
</script>