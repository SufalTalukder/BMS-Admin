<style>
    .label {
        font-weight: 600;
        color: #4A4A4A;
    }

    .value {
        font-weight: 600;
        color: #333;
    }

    .card-text {
        color: #555;
        font-size: 14px;
    }

    #store_title {
        color: #333;
        font-weight: bold;

    }

    .table tbody tr:hover {
        background-color: #f5f5f5;
        /* Row hover effect */
    }

    .table tbody tr:hover td {
        background-color: #e9ecef;
        /* Column hover effect */
    }

    .table tbody td:hover {
        background-color: #d3d3d3;
        /* Change color on column hover */
    }

    .table-responsive {
        overflow-x: auto;
        /* Allows horizontal scrolling for smaller screens */
    }

    .table {
        width: 100%;
        /* Make sure the table is full width */
    }
</style>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Store Details</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url('admin/store') ?>">Store</a></li>
                <li class="breadcrumb-item">Store Details</li>
            </ol>
        </nav>
    </div>
    <?php
    $store_detail = $store_details;
    // print"<pre>" ; print_r($store_detail) ; die ; 
    ?>
    <section class="section">
        <div class="row">
            <div class="col-md-6">
                <div class="card" style="background-color:#f9f9f9; border:1px solid #ddd;">
                    <div class="card-body">

                        <h5 id="store_title" class="card-title pb-1">Store Information</h5>
                        <div class="d-flex align-items-center justify-content-start">
                            <div>
                                <?php
                                // Set the logo image URL with a default if null
                                $img = ($store_detail && $store_detail->logoUrl) ? base_url() . $store_detail->logoUrl : base_url('assets/uploads/notFound.png');
                                ?>
                                <img src="<?= $img ?>" alt="Store Image" style="height:100px; width:100px; object-fit:cover;" class="rounded">
                            </div>
                            <div class="px-2">
                                <p class="card-text">
                                    <span>GST Number:</span>&nbsp;
                                    <span class="value"><?= $store_detail->gstNo ?? 'N/A' ?></span><br>

                                    <span>Name:</span>&nbsp;
                                    <span class="value"><?= $store_detail->storeName ?? 'N/A' ?></span><br>

                                    <span>PAN Number:</span>&nbsp;
                                    <span class="value"><?= $store_detail->panNo ?? 'N/A' ?></span><br>

                                    <span>Category:</span>&nbsp;
                                    <span class="value"><?= $store_detail->categoryName ?? 'N/A' ?></span><br>

                                    <span>City:</span>&nbsp;
                                    <span class="value"><?= $store_detail->cityName ?? 'N/A' ?></span><br>

                                    <span>State:</span>&nbsp;
                                    <span class="value"><?= $store_detail->stateName ?? 'N/A' ?></span><br>

                                    <span>Address:</span>&nbsp;
                                    <span class="value"><?= $store_detail->storeAddress ?? 'N/A' ?></span><br>

                                    <span>Description:</span>&nbsp;
                                    <span class="value "><?= $store_detail->description ?? 'N/A' ?></span><br>

                                    <span class="font-weight:600; color:#4A4A4A;">Status:</span>&nbsp;
                                    <?php
                                    if ($store_detail && $store_detail->storeState == STORE_CATEGORY_ACTIVE) {
                                        echo '<span class="badge bg-success rounded">Active</span>';
                                    } elseif ($store_detail && $store_detail->storeState == STORE_CATEGORY_INACTIVE) {
                                        echo '<span class="badge bg-warning rounded">Inactive</span>';
                                    } elseif ($store_detail && $store_detail->storeState == STORE_CATEGORY_DELETED) {
                                        echo '<span class="badge bg-danger rounded">Deleted</span>';
                                    } else {
                                        echo '<span class="badge bg-secondary rounded">Unknown</span>'; // Optional: Handle unknown status
                                    }
                                    ?><br />
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <?php
                        $user_detail = $store_details;
                        ?>
                        <h5 id="store_title" class="card-title pb-1" style="color:#2e2e2e;">Owner Contact Information</h5>
                        <div class="d-flex align-items-center justify-content-start">
                            <div>
                                <?php

                                $img = ($user_detail && $user_detail->profileImageLink) ? base_url() . $user_detail->profileImageLink : base_url('assets/uploads/notFound.png');
                                ?>
                                <img src="<?= $img ?>" alt="Profile Image" style="height:100px; width:100px; object-fit:cover;" class="rounded">
                            </div>
                            <div class="px-2">
                                <p class="card-text">
                                    <span style="font-weight:600;">Name:</span>&nbsp; <?= $user_detail->name ?? 'N/A' ?><br>
                                    <span style="font-weight:600;">Phone Number:</span>&nbsp; <?= $user_detail->mobileNo ?? 'N/A' ?><br>
                                    <span style="font-weight:600;">Email:</span>&nbsp;
                                    <a href="mailto:<?= $user_detail->email ?? '#' ?>"><?= $user_detail->email ?? 'N/A' ?></a><br>
                                    <span style="font-weight:600;">Address:</span>&nbsp; <?= $user_detail->address ?? 'N/A' ?><br>
                                    <span style="font-weight:600;">Status:</span>&nbsp;
                                    <?php
                                    if ($user_detail && $user_detail->online_status == USER_STATUS_ONLINE) {
                                        echo '<span class="badge bg-info rounded">Online</span>';
                                    } else {
                                        echo '<span class="badge bg-secondary rounded">Offline</span>';
                                    }
                                    ?><br /><br>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="container mt-4">
            <div class="row">
                <div class="card-body px-0">
                    <div class="card p-3">
                        <h5 class="card-title pt-1 mb-0" style="color:#2e2e2e;">Store Offer Detail</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="title-column">#</th>
                                        <th>Title</th>
                                        <th>MRP</th>
                                        <th>Discount Type</th>
                                        <th>Discount</th>
                                        <th>Min Amount</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $store_offers = isset($store_details->offers) ? $store_details->offers : [];
                                    if (!empty($store_offers)) {
                                        foreach ($store_offers as $i => $storeOffer) {
                                    ?>
                                            <tr>
                                                <td><?= $i + 1 ?></td>
                                                <td><a href="#"><?= $storeOffer->title ?></a></td>
                                                <td>₹<?= $storeOffer->mrpPrice ?></td>
                                                <td><?= $storeOffer->dicountType ?></td>
                                                <td>₹<?= $storeOffer->discount ?></td>
                                                <td>₹<?= $storeOffer->minAmount ?></td>
                                                <td><?= date('d/m/Y', strtotime($storeOffer->startDate)) ?></td>
                                                <td><?= date('d/m/Y', strtotime($storeOffer->endDate)) ?></td>
                                                <td> <?php
                                                        if ($storeOffer->state == STORE_OFFER_ACTIVE) {
                                                            echo '<span class="badge bg-success rounded">Active</span>';
                                                        } else {
                                                            echo '<span class="badge bg-warning rounded">Inactive</span>';
                                                        }
                                                        ?><br /><br></td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>