
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Store Details</h1>
        <nav>
            <ol class="breadcrumb">
                <?php
                $u = $seller_info;
                ?>
                <li class="breadcrumb-item">
                    <a href="<?= base_url("admin/seller/") ?>">Seller Management</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?= base_url("admin/seller/") . $u['uId'] ?>">Seller Details</a>
                </li>
                <li class="breadcrumb-item">Store Details</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5>Category</h5>
                    <hr>
                    Name: <?= (!empty($store['categoryName'])) ? $store['categoryName'] : 'NA' ?>
                    <hr>
                    Create At :<?= (!empty($store['catecreatedAt'])) ? $store['catecreatedAt']  : 'NA' ?>
                    <hr>
                    Update At :<?= (!empty($store['cateUpdateAt'])) ? $store['cateUpdateAt']  : 'NA' ?>
                    <hr>
                    Status :<?= (!empty($store['cateState'])) ? $store['cateState']  : 'NA' ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5>Store Offer </h5>
                    <hr>
                    Name : <?= (!empty($store['title'])) ? $store['title']  : 'NA';  ?>
                    <hr>
                    MRP : <?= (!empty($store['mrpPrice'])) ? $store['mrpPrice']  : 'NA';  ?>
                    <hr>
                    Discount : <?= (!empty($store['discount'])) ? $store['discount']  : 'NA';  ?>
                    <hr>
                    Discount Type : <?= (!empty($store['dicountType'])) ? $store['dicountType']  : 'NA';  ?>
                    <hr>
                    Start Date : <?= (!empty($store['startDate'])) ? $store['startDate']  : 'NA';  ?>
                    <hr>
                    Start Time : <?= (!empty($store['startTime'])) ? $store['startTime']  : 'NA';  ?>
                    <hr>
                    End Date : <?= (!empty($store['endDate'])) ? $store['endDate']  : 'NA';  ?>
                    <hr>
                    Min Amount: <?= (!empty($store['minAmount'])) ? $store['minAmount']  : 'NA';  ?>
                    <hr>
                    Status : <?= (!empty($store['offerState'])) ? $store['offerState']  : 'NA';  ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5>Store Details</h5>
                    <hr>
                    Name: <?= (!empty($store['name'])) ? $store['name'] : 'NA' ?>
                    <hr>
                    Gst Number: <?= (!empty($store['gstNo'])) ? $store['gstNo'] : 'NA' ?>
                    <hr>
                    Pan Number : <?= (!empty($store['panNo'])) ? $store['panNo'] : 'NA' ?>
                    <hr>
                    Address: <?= (!empty($store['address'])) ? $store['address'] : 'NA' ?>
                    <hr>
                    State Name : <?= (!empty($store['StateName'])) ? $store['StateName'] : 'NA' ?>
                    <hr>
                    City Name: <?= (!empty($store['CityName'])) ? $store['CityName'] : 'NA' ?>
                    <hr>
                    Description : <?= (!empty($store['description'])) ? $store['description'] : 'NA' ?>
                    <hr>
                    Created At : <?= (!empty($store['createdAt'])) ? $store['createdAt'] : 'NA' ?>
                    <hr>
                    Updated At : <?= (!empty($store['updatedAt'])) ? $store['updatedAt'] : 'NA' ?>
                    <hr>
                    Status : <?= (!empty($store['state'])) ? $store['state'] : 'NA' ?>
                </div>
            </div>
        </div>
    </section>
</main>