<style>
    p strong {
        color: #6c757d;
        font-weight: 600;
        font-size: 1rem;
    }

    p {
        color: black;
        font-size: 1rem;
        line-height: 1.5;
    }
</style>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Buyer Details </h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url("admin/buyer")  ?>">Buyer Management </a></li>
                <li class="breadcrumb-item">Buyer Details</li>
            </ol>
        </nav>
    </div>
    <?php
    $buyer = $buyer;
    ?>
    <section class="section dashboard">
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3" style="min-height: 400px;">
                    <h5 class="text-center mb-4">Buyer Profile</h5>
                    <hr>
                    <div class="text-center mb-4">
                        <?php $img = (!empty($buyer['profileImageLink'])) ? base_url($buyer['profileImageLink']) : base_url('assets/uploads/notFound.png'); ?>
                        <img src="<?= $img ?>" alt="Profile Image" class="img-fluid rounded-circle" style="width: 150px; height: 150px; object-fit: cover; border: 2px solid #007bff;">
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Name:</strong> <?= (!empty($buyer['name'])) ? $buyer['name'] : 'NA'  ?></p>
                            <p><strong>Email:</strong> <a href="mailto:<?= $buyer['email'] ?? '#' ?>"><?= (!empty($buyer['email'])) ? $buyer['email'] : 'NA' ?></a></p>
                            <p><strong>Phone:</strong> <?= (!empty($buyer['mobileNo'])) ? $buyer['mobileNo'] : 'NA' ?></p>
                            <p><strong>Gender:</strong> <?= (!empty($buyer['gender'])) ? $buyer['gender']  : 'NA' ?> </p>
                            <p><strong>Online:</strong>
                                <?php
                                if ($buyer['online_status'] == USER_STATUS_ONLINE) {
                                    echo '<span class="badge text-white bg-primary rounded">Online</span>';
                                } else {
                                    echo '<span class="badge text-white bg-danger rounded">Offline</span>';
                                }
                                ?>
                            </p>
                            <p><strong>Own ReferralCode:</strong><?= (!empty($buyer['ownReferralCode'])) ? $buyer['ownReferralCode']  : 'NA' ?></p>
                        </div>
                        <div class=" col-md-6">
                                    <p><strong>Referrer ReferralCode:</strong><?= (!empty($buyer['referrerReferralCode'])) ? $buyer['referrerReferralCode'] : 'NA' ?></p>
                                    <p><strong>Address:</strong> <?= (!empty($buyer['address'])) ? $buyer['address'] : 'NA' ?></p>
                                    <p>
                                        <strong>Created At:</strong>
                                        <?= date('d/m/Y', strtotime($buyer['createdAt'])) . '<br/>' . date('h:i A', strtotime($buyer['createdAt'])) ?>
                                    </p>
                                    <p><strong>Updated At:</strong>
                                        <?= date('d/m/Y', strtotime($buyer['updatedAt'])) . '<br/>' . date('h:i A', strtotime($buyer['updatedAt'])) ?>
                                    </p>
                                    <p><strong>Status:</strong>
                                        <?php
                                        if ($buyer['state'] === BUYER_STATUS_INACTIVE) {
                                            echo '<span class="badge text-dark bg-warning rounded">Inactive</span>';
                                        } elseif ($buyer['state'] === BUYER_STATUS_ACTIVE) {
                                            echo '<span class="badge text-dark bg-success rounded">Active</span>';
                                        } elseif ($buyer['state'] === BUYER_STATUS_DELETED) {
                                            echo '<span class="badge text-dark bg-danger rounded">Delete</span>';
                                        }
                                        ?>
                                    </p>
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    </section>