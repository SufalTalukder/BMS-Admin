<style>
  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
  }

  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
  }

  input:checked+.slider {
    background-color: #2196F3;
  }

  input:focus+.slider {
    box-shadow: 0 0 1px #2196F3;
  }

  input:checked+.slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
  }


  .slider.round {
    border-radius: 34px;
  }

  .slider.round:before {
    border-radius: 50%;
  }

  .store-link {
    color: #008B8B;

  }

  .category-link {
    color: #32CD32;

  }

  .type-link {
    color: #FF8C00;

  }

  .element.style {
    width: 88.516px;
  }
</style>
<main id="main" class="main">
  <div class="button-row mb-3 d-flex justify-content-between">
    <!-- Left Side Buttons -->
    <div class="d-flex gap-2">
      <a type="button" href="<?= base_url('admin/product/download/excel/format') ?>" class="btn btn-primary">
        Download Format
      </a>
      <a type="button" href="<?= base_url('admin/product/download/excel/data') ?>" class="btn btn-success">
        Download table data
      </a>
    </div>
    <form method="post" action="<?= base_url('admin/product/upload/excel/file') ?>" enctype="multipart/form-data">
      <div class="input-group" style="max-width: 300px;">

        <input type="file" name="upload_file" class="form-control" id="importFile" required>
        <input class="btn btn-primary" name="submit" type="Submit">
      </div>
  </div>
  <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
      <?= session()->getFlashdata('success'); ?>
    </div>
  <?php endif; ?>

  <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
      <?= session()->getFlashdata('error'); ?>
    </div>
  <?php endif; ?>
  </form>

  <!-- Page Title Section -->
  <div class="pagetitle">
    <h1>Product Management</h1>
  </div>

  <!-- Data Table Section -->
  <section class="section">
    <div class="row">
      <div class="col-lg-12 p-0">
        <div class="card">
          <div class="card-body p-3">
            <table id="productTable" class="table table-middle table-striped font-12 whitespace-nowrap table-bordered  table-sm table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th><b>Name</b></th>
                  <th>Store</th>
                  <th>Category</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Data</th>
                  <th>Change listing Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $products = $product; ?>
                <?php foreach ($products as $i => $product) { ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><a href="<?= base_url('admin/product/detail/') . $product->uId ?> " title="product details"> <?= $product->name ?></a></td>
                    <td><a href="<?= base_url('admin/store')  ?>" class="store-link"><?= $product->StoreName ?></a></td>
                    <td><a href="<?= base_url('admin/product/category') ?>" class="category-link"><?= $product->categoryName ?></a></td>
                    <td><a href="<?= base_url('admin/product/type')  ?>" class="type-link"><?= $product->typeName ?></a></td>

                    <td>
                      <?php
                      if ($product->listingstatus == PRODUCT_LISTING_STATUS_INACTIVE) {
                        echo '<span class="badge text-dark bg-warning rounded">Inactive</span>';
                      } elseif ($product->listingstatus == PRODUCT_LISTING_STATUS_ACTIVE) {
                        echo '<span class="badge bg-success rounded">Active</span>';
                      } elseif ($product->listingstatus == PRODUCT_LISTING_STATUS_DELETED) {
                        echo '<span class="badge bg-danger rounded">Delete</span>';
                      }
                      ?>
                    </td>
                    <td><?= date('d/m/Y', strtotime($product->createdAt)) . '<br/>' . date('h:i A', strtotime($product->createdAt)) ?></td>
                    <td>
                      <label class="switch">
                        <input type="checkbox" <?= $product->listingstatus == PRODUCT_LISTING_STATUS_ACTIVE ? 'checked' : '' ?> onchange="toggleProductStatus('<?= $product->uId ?>', this.checked)">
                        <span class="slider round"></span>
                      </label>
                      <button type="button" class="btn btn-danger btn-sm rounded-pill" onclick=" return  openDeleteModal('<?= $product->uId  ?>')">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                          <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                          <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this item? <span style="color: red; font-weight: bold;">This action cannot be undone.</span></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function() {
    $('#productTable').DataTable();
    $(['title']).tooltip();
  });

  function openDeleteModal(uId) {
    itemIdToDelete = uId;
    $('#deleteModal').modal('show');
  }
  $('#confirmDelete').on('click', function() {
    $.ajax({
      url: '<?= base_url('delete/product') ?>',
      type: 'POST',
      data: {
        uId: itemIdToDelete
      },
      success: function(response) {
        $('#deleteModal').modal('hide');
        showToast(response.message);
        location.reload();
      },
      error: function(xhr, status, error) {
        console.error('Error deleting item:', error);
      }
    });
  });

  function toggleProductStatus(productId, isActive) {
    const status = isActive ? 'active' : 'inactive';
    $.ajax({
      url: '<?= base_url("product-toggle-status-change") ?>',
      method: "POST",
      data: {
        uId: productId,
        status: status
      },
      dataType: "json",
      success: function(response) {
        console.log(response);
        if (response.status) {
          console.log(response.status);
          showToast(response.message);
          location.reload();
        } else {
          alert('Failed to update product status');
        }
      },
      error: function() {
        alert('An error occurred while updating the product status');
      }
    });
  }
  document.addEventListener("DOMContentLoaded", function() {
    const flashMessages = document.querySelectorAll('.alert');
    flashMessages.forEach((flashMessage) => {
      setTimeout(() => {
        flashMessage.classList.add('fade-out');
      }, 3000);

      setTimeout(() => {
        flashMessage.remove();
      }, 3500);
    });
  });
</script>