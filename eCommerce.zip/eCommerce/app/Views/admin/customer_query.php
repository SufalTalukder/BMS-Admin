<main id="main" class="main">

    <div class="pagetitle">
        <h1>Customer Chat</h1>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">

                <div class="card">
                    <div class="card-body p-3 ">
                        <table id="customerQuery" class="table .table-striped .table-hover datatable  ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User</th>
                                    <th>Friend</th>

                                    <th>Message</th>
                                    <th>Create </th>


                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($FriendLists as  $i =>  $friendList) { ?>
                                    <tr>
                                        <td><?= $i + 1  ?></td>
                                        <td>
                                            <a href="<?= base_url('admin/chat/') . $friendList->chat_id ?>">
                                                <?= $friendList->userName ?>
                                            </a>
                                        </td>
                                        <td> <?= $friendList->friendName ?></td>
                                        <td><?= $friendList->message ?></td>
                                        <td><?= $friendList->created_at  ?></td>
                                        <td><?php
                                            if ($friendList->status == CHAT_FRIEND_INACTIVE) {
                                                echo '<span class="badge text-dark bg-warning rounded">Inactive</span>';
                                            } elseif ($friendList->status == CHAT_FRIEND_ACTIVE) {
                                                echo '<span class="badge bg-success rounded">Active</span>';
                                            } elseif ($friendList->status == CHAT_FRIEND_DELETED) {
                                                echo '<span class="badge bg-danger rounded">Delete</span>';
                                            }
                                            ?></td>

                                        <td>

                                        </td>
                                    </tr>
                                <? } ?>
                            </tbody>

                        </table>
                      
                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->
<script>
    $(document).ready(function() {
        $('#customerQuery').DataTable();
    });
</script>