<main id="main" class="main">
    <div class="pagetitle">
        <h1>Seller Details </h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url("admin/seller") ?>">Seller Management </a></li>
                <li class="breadcrumb-item">Seller Details</li>
            </ol>
        </nav>
    </div>

    <div class="d-flex justify-content-between">
        <div class="p-3">
            <div class="mb-2">
                Mobile : <?= $seller_info['mobileNo'] ?>
            </div>

            <div class="mb-2">
                Name :&nbsp;&nbsp; <?= (!empty($seller_info['name'])) ? ucwords($seller_info['name']) : 'NA' ?>
            </div>

            <div class="mb-2">
                Email: &nbsp;&nbsp; <?= (!empty($seller_info['email'])) ? ucwords($seller_info['email']) : 'NA' ?>
            </div>
            <div class="mb-2">
                Address: &nbsp;&nbsp; <?= (!empty($seller_info['address'])) ? ucwords($seller_info['address']) : 'NA' ?>
            </div>
        </div>
        <!-- for extra add  -->
        <!-- <div class="p-3">
            address:
        </div> -->
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> Store Details</h5>
                        <table id="storeTable" class="table datatable table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>
                                        <b>N</b>ame
                                    </th>
                                    <th>Pan No </th>
                                    <th>Gst No</th>
                                    <th>Address</th>
                                    <th>Created At </th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="9">
                                        <center>Store List Loading...</center>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> Store Product Details</h5>
                        <table id="storeProduct" class="table datatable table-hover table-sm ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>
                                        <b>N</b>ame
                                    </th>
                                    <th>Brand</th>
                                    <th>MRP</th>
                                    <th>Selling Price</th>
                                    <th>Stock Quantity </th>
                                    <th>Gst Percent</th>
                                    <th>Created At </th>
                                    <th>Listing Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="9">
                                        <center>Product List Loading...</center>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        const PRODUCT_LISTING_STATUS_ACTIVE = '<?= PRODUCT_LISTING_STATUS_ACTIVE ?>';
        const PRODUCT_LISTING_STATUS_INACTIVE = '<?= PRODUCT_LISTING_STATUS_INACTIVE ?>';
        const PRODUCT_LISTING_STATUS_DELETED = '<?= PRODUCT_LISTING_STATUS_DELETED ?>';
        $(document).ready(function () {
            let userid = '<?= $userid ?>';
            var baseUrl = "<?= base_url() ?>";
            $.ajax({
                type: "GET",
                url: "<?= base_url('/get-store-details-by-uid') ?>?userid=" + userid,
                dataType: "json",
                success: function (response) {
                    if (response.status) {
                        console.log(response.data);
                        $('#storeTable tbody').empty();

                        $.each(response.data, function (i, store) {
                            $('#storeTable tbody').append(`
                            <tr>
                                    <td>${i + 1}</td>
                                    <td title="Store Details"><a href="${baseUrl}/admin/seller/${userid}/store/${store.uId}">${store.storeName ? store.storeName : 'NA'}</a></td>
                                    <td>${store.panNo}</td>
                                    <td>${store.gstNo}</td>
                                    <td>${store.address}</td>
                                    <td>${formatDate(store.createdAt)}</td>    
                            </tr>
                            `)
                        })
                        $('[title]').tooltip();

                    } else {
                        alert(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ', error);
                    alert('An error occurred while fetching the data.');
                }
            });

            $.ajax({
                type: "GET",
                url: baseUrl + "/get-store-product-details-by-uid?userid=" + userid,
                dataType: "json",
                success: function (response) {
                    if (response.status) {

                        $('#storeProduct tbody').empty();

                        $.each(response.data, function (i, product) {
                            let statusText, statusClass;
                            if (product.listingstatus == PRODUCT_LISTING_STATUS_DELETED) {
                                statusText = 'Deleted';
                                statusClass = 'badge bg-danger rounded';
                            } else if (product.listingstatus == PRODUCT_LISTING_STATUS_ACTIVE) {
                                statusText = 'Active';
                                statusClass = 'badge bg-success rounded';
                            } else if (product.listingstatus == PRODUCT_LISTING_STATUS_INACTIVE) {
                                statusText = 'Inactive';
                                statusClass = 'badge bg-warning text-dark rounded';
                            } else {
                                statusText = 'Unknown';
                                statusClass = 'badge bg-secondary rounded';
                            }
                            $('#storeProduct tbody').append(`
                    <tr>
                        <td>${i + 1}</td>
                        <td><a href="${baseUrl}/admin/seller/${userid}/product/${product.uId}">${product.name ? product.name : 'NA'}</a></td>
                        <td>${product.brandName ? product.brandName : 'NA'}</td>
                        <td>${product.mrpPrice ? '₹' + product.mrpPrice : 'NA'}</td>
                        <td>${product.sellingPrice ? '₹' + product.sellingPrice : 'NA'}</td >
                        <td>${product.stockQty ? product.stockQty : 'NA'}</td>
                        <td>${product.gstPercent ? product.gstPercent : 'NA'}</td>
                        <td>${formatDate(product.createdAt)}</td>
                        <td><span class="${statusClass}">${statusText}</span></td>
                    </tr >
                    `);
                        });
                    } else {
                        alert(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ', error);
                    alert('An error occurred while fetching the data.');
                }
            });

        });
    </script>