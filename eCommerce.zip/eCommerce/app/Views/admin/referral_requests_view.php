<main id="main" class="main">

    <div class="pagetitle">
        <h1>Store Referral And Request </h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="table-responsive">

                            <table id="requestTable" class="table table-middle table-striped font-12 whitespace-nowrap table-bordered  table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Status</th>
                                        <th><b>ReferralCode</b></th>
                                        <th>ReferrerName</th>
                                        <th>ReferrerUserRewardType</th>
                                        <th>ReferrerUserReward</th>
                                        <th>ReferredName</th>
                                        <th>ReferredUserRewardType</th>
                                        <th>ReferredUserReward</th>
                                        <th>Create</th>
                                        <th>Update</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($rereferral_requests as $i => $referral_request) { ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td>
                                                <?php
                                                if ($referral_request->status == REWARD_STATUS_COMPLETE) {
                                                    echo '<span class="badge text-white bg-success rounded">Completed</span>'; 
                                                } elseif ($referral_request->status == REWARD_STATUS_REWARDED) {
                                                    echo '<span class="badge text-white bg-info rounded">Rewarded</span>'; 
                                                } elseif ($referral_request->status == REWARD_STATUS_PENDING) {
                                                    echo '<span class="badge text-dark bg-warning rounded">Pending</span>'; 
                                                } else {
                                                    echo '<span class="badge text-dark bg-secondary rounded">Unknown</span>'; 
                                                }
                                                ?>
                                            </td>
                                            <td><?= $referral_request->referralCode ?></td>
                                            <td><?= $referral_request->referrerName ?></td>
                                            <td><?= $referral_request->referrerUserRewardType ?></td>
                                            <td><?= $referral_request->referrerUserReward ?></td>
                                            <td><?= $referral_request->referredName ?></td>
                                            <td><?= $referral_request->referredUserRewardType ?></td>
                                            <td><?= $referral_request->referredUserReward ?></td>
                                            <td><?= date('d/m/Y', strtotime($referral_request->createdAt)) . '<br/>' . date('h:i A', strtotime($referral_request->createdAt)) ?></td>
                                            <td><?= date('d/m/Y', strtotime($referral_request->modifiedAt)) . '<br/>' . date('h:i A', strtotime($referral_request->modifiedAt)) ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        $(document).ready(function() {
            $('#requestTable').DataTable();
        });
    </script>