<main id="main" class="main">

    <div class="pagetitle">
        <h1>Buyer Product Request</h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="table-responsive">

                            <table id="requestTable" class="table table-middle table-striped font-12 whitespace-nowrap table-bordered  table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Status</th>
                                        <th><b>Store Name </b></th>
                                        <th>User Name </th>
                                        <th>Product Name</th>
                                        <th>Create</th>
                                        <th>Status</th>

                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        $(document).ready(function() {
            $('#requestTable').DataTable();
        });
    </script>