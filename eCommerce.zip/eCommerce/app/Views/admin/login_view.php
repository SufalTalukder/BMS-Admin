<div class="container">
  <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

          <div class="d-flex justify-content-center py-4">
            <a href="index.html" class="logo d-flex align-items-center w-auto">
              <img src="<?php echo base_url('assets/img/e-com.jfif') ?>" alt="">
              <span class="d-none d-lg-block">E-commerce Admin </span>
            </a>
          </div><!-- End Logo -->

          <div class="card mb-3">
            <div class="card-body">

              <div class="pt-4 pb-2">
                <h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
                <p class="text-center small">Enter your username & password to login</p>
              </div>

              <form id="loginForm" method="POST" class="row g-3 needs-validation" novalidate onsubmit="return validateForm(event);">
                <div class="col-12">
                  <label for="yourUsername" class="form-label">Username</label>
                  <div class="input-group has-validation">
                    <input type="text" name="email" class="form-control" id="emailId" required>
                    <div class="invalid-feedback">Please enter your username.</div>
                  </div>
                </div>

                <div class="col-12">
                  <label for="yourPassword" class="form-label">Password</label>
                  <input type="password" name="password" class="form-control" id="yourPassword" required>
                  <div class="invalid-feedback">Please enter your password!</div>
                </div>

                <!-- <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" value="true" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Remember me</label>
                  </div>
                </div> -->
                <div class="col-12">
                  <button class="btn btn-primary w-100" id="loginButton" type="submit">
                    <span id="loginSpinner" class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="display: none;"></span>
                    <span id="loginText">Login</span>
                  </button>
                </div>

              </form>

            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
</div>

<!-- <script>
  function validateForm(event) {
    event.preventDefault();


    const loginButton = $('#loginButton');
    const loginSpinner = $('#loginSpinner');

    loginButton.prop('disabled', true);
    loginSpinner.show();

    const email = $('#emailId').val();
    const password = $('#yourPassword').val();

    const data = {
      email: email,
      password: password
    };

    console.log('Data being sent:', JSON.stringify(data));

    $.ajax({
      url: "<?= base_url('login') ?>",
      type: "POST",
      contentType: 'application/json',
      data: JSON.stringify(data),
      success: function(response) {
        console.log('Response received:', response);
        if (response.status) {
          window.location.href = '<?= base_url('admin/dashboard') ?>';
        } else {
          Toastify({
            text: response.message || "Login failed!",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "linear-gradient(to right, #ff5f6d, #ffc371)",
            stopOnFocus: true
          }).showToast();
        }
      },
      error: function(xhr, status, error) {
        console.error('AJAX Error:', xhr, status, error);
        Toastify({
          text: "An error occurred while logging in. Please try again.",
          duration: 200,
          gravity: "top",
          position: "center",
          backgroundColor: "linear-gradient(to right, #ff5f6d, #ffc371)",
          stopOnFocus: true
        }).showToast();
      },
      complete: function() {
        loginButton.prop('disabled', false);
        loginSpinner.hide();
      }
    });

    return false;
  }
</script> -->

<script>

  function validateForm(event) {
    event.preventDefault(); 

    const loginButton = $('#loginButton');
    const loginSpinner = $('#loginSpinner');
    const loginText = $('#loginText');
    loginButton.prop('disabled', true);
    loginSpinner.show();
    loginText.text('Logging in...');
    const email = $('#emailId').val();
    const password = $('#yourPassword').val();

    const data = { email: email, password: password };

    $.ajax({
      url: "<?= base_url('login') ?>", 
      type: "POST",
      contentType: 'application/json', 
      data: JSON.stringify(data), 
      success: function(response) {
        if (response.status) {

          showToast("Login successful!", "success");
          setTimeout(function() {
            window.location.href = '<?= base_url('admin/buyer') ?>';
          }, 1500); 
        } else {
         
          showToast(response.message || "Login failed!", "error");
        }
      },
      error: function(xhr, status, error) {
        showToast("An error occurred. Please try again.", "error");
      },
      complete: function() {
        
        loginButton.prop('disabled', false);
        loginSpinner.hide();
        loginText.text('Login'); 
      }
    });

    return false; 
  }
</script>
