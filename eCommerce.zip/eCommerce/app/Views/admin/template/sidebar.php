<style>
    .sidebar .nav-link {
        color: #333;
        /* Default link color */
        padding: 10px 20px;
        display: flex;
        align-items: center;
        text-decoration: none;
        border-radius: 4px;
    }

    .sidebar .nav-link:hover {
        background-color: #0bcbe2;
        color: #fff;

    }

    .sidebar .nav-link.active {
        background-color: #0bcbe2;
        color: #fff;
    }

    .sidebar .nav-link svg {
        margin-right: 8px;
        fill: currentColor;
    }

    .nav-content {
        background-color: #e9ecef;
    }

    .nav-content .nav-link {
        padding-left: 30px;
        /* Indent for nested items */
    }

    .nav-content .nav-link:hover {
        background-color: #495057;
        color: #fff;
    }

    /* Hide chevron icons when collapsed */
    .nav-item .bi-chevron-down {
        transition: transform 0.3s ease;
    }

    .nav-item .nav-link.collapsed .bi-chevron-down {
        transform: rotate(180deg);
    }
</style>
<aside id="sidebar" class="sidebar">
    <?php
    $current_url = current_url();
    $store_active = ($current_url === base_url('admin/store'));
    $category_active = ($current_url === base_url('admin/store/category'));
    ?>
    <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_USER_MANAGEMENT) ? 'active' : '' ?>" href="<?php echo base_url('admin/buyer') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="blue" class="bi bi-person" viewBox="0 0 16 16">
                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm0 1a7 7 0 0 0-6.293 3.473C1.69 13.751 2.682 15 4 15h8c1.318 0 2.31-1.249 2.293-2.527A7 7 0 0 0 8 9z" />
                </svg>&nbsp;
                <span>User Management</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_SELLER_MANAGEMENT) ? 'active' : '' ?>" href="<?php echo base_url('admin/seller') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-badge" viewBox="0 0 16 16">
                    <path d="M8 0a5 5 0 0 0-5 5c0 1.88 1.088 3.504 2.697 4.185A2.5 2.5 0 0 0 4.5 13H6.25c.258 0 .51.085.711.227C8.2 13.387 9.7 15 11 15s2.8-1.613 3.04-1.773c.201-.142.453-.227.711-.227H11.5a2.5 2.5 0 0 0-1.197-3.815C12.912 8.504 14 6.88 14 5a5 5 0 0 0-5-5zM6.5 5a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0z" />
                    <path d="M5 11a4.978 4.978 0 0 0 1.37 3.3c.4.4.93.7 1.57.7s1.17-.3 1.57-.7A4.978 4.978 0 0 0 11 11h-6z" />
                </svg>
                <span>Seller Management</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_PRODUCT_MANAGEMENT ? 'active' : '') ?> " href="<?php echo base_url('admin/product') ?>">
                <!-- SVG icon representing a product (box) -->
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="blue" class="bi bi-box" viewBox="0 0 16 16">
                    <path d="M4.25 1a.25.25 0 0 0-.25.25V2h8V1.25a.25.25 0 0 0-.25-.25H4.25ZM2 3v11.5c0 .275.225.5.5.5h11a.5.5 0 0 0 .5-.5V3H2Zm11 1v2h-2V4h2Zm-2 3h2v3h-2V7Zm0 4h2v3h-2v-3Zm-1-3v3H6V7h4Zm-5 3H2V7h2v3Zm0-4H2V4h2v2Zm5 4v3H5v-3h4Zm1-3v3h2v-3h-2Zm-4 3H2v3h2v-3ZM4.25 2a.25.25 0 0 0-.25.25V3H12V2.25a.25.25 0 0 0-.25-.25H4.25Z" />
                </svg>&nbsp;
                <span>Product Management</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_PRODUCT_TYPE_MANAGEMENT) ? 'active' : '' ?>" href="<?= base_url('admin/product/type') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-box-seam" viewBox="0 0 16 16">
                    <path d="M1.5 0a.5.5 0 0 1 .5.5V1h10V.5a.5.5 0 0 1 1 0V1h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1v1a.5.5 0 0 1-.5.5H1a.5.5 0 0 1-.5-.5V2h1a.5.5 0 0 1 .5-.5V1h1V.5a.5.5 0 0 1 .5-.5zM1 3h14l1 10a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1L1 3zm3 4h8v1H4v-1zm0 2h8v1H4v-1zm0 2h8v1H4v-1zm10-6H1l1 9h12l1-9z" />
                    <path d="M4 9h8v1H4V9zm0 2h8v1H4v-1zm0 2h8v1H4v-1z" />
                </svg>
                <span>Product Type</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_PRODUCT_CATEGORY_MANAGEMENT) ? 'active' : '' ?>" href="<?= base_url('admin/product/category') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-folder" viewBox="0 0 16 16">
                    <path d="M2 2a1 1 0 0 1 1-1h4.5l1 1H15a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V2z" />
                    <path d="M0 2a1 1 0 0 1 1-1h4.5l1 1H15a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V2z" />
                    <path d="M4 3H1v10h14V4H5.5L4 3z" />
                    <path d="M10 9H5v1h5V9zm0 2H5v1h5v-1z" />
                </svg>
                <span>Product Category</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_STORE_PAYMENT) ? 'active' : '' ?>" href="<?= base_url('admin/store/payment') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-cash" viewBox="0 0 16 16">
                    <path d="M15 4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H1a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14zm0 1H1a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z" />
                    <path d="M13 6.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM1 7.5a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm7 1a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" />
                </svg>
                <span>Payments</span>
            </a>
        </li>




        <li class="nav-item">
            <a class="nav-link collapsed <?= $store_active ? 'active' : '' ?>" data-bs-target="#components-nav" data-bs-toggle="collapse" href="<?= base_url('admin/store') ?>">
                <i class="bi bi-menu-button-wide"></i>
                <span>Store</span>
                <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="components-nav" class="nav-content collapse <?= $store_active ? 'show' : '' ?>" data-bs-parent="#sidebar-nav">
                <li>
                    <a class="<?= $store_active ? 'active' : '' ?>" href="<?= base_url('admin/store') ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tags" viewBox="0 0 16 16">
                            <path d="M8 0a3 3 0 0 0-3 3v1H3a1 1 0 0 0-1 1v9a3 3 0 0 0 3 3h6a3 3 0 0 0 3-3V5a1 1 0 0 0-1-1h-2V3a3 3 0 0 0-3-3zm-2 3a2 2 0 1 1 4 0v1H6V3z" />
                        </svg>
                        <span> &nbsp;Store</span>
                    </a>
                </li>
                <li>
                    <a class="<?= $category_active ? 'active' : '' ?>" href="<?= base_url('admin/store/category') ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tags" viewBox="0 0 16 16">
                            <path d="M2.5 0A.5.5 0 0 0 2 1v2.5a.5.5 0 0 0 .5.5H3v2h-.5a.5.5 0 0 0-.5.5V6h-.5a.5.5 0 0 0-.5.5V8h-.5A.5.5 0 0 0 0 8.5V9h.5a.5.5 0 0 0 .5.5h2v2.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V10h2v-.5a.5.5 0 0 0-.5-.5h-1v-2h1a.5.5 0 0 0 .5-.5V5h1.5a.5.5 0 0 0 .5-.5V2.5a.5.5 0 0 0-.5-.5H2.5z" />
                        </svg>
                        <span> &nbsp;Categories</span>
                    </a>
                </li>
                <li>
                    <a class="<?= $category_active ? 'active' : '' ?>" href="<?= base_url('admin/store/offer') ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tags" viewBox="0 0 16 16">
                            <path d="M2.5 0A.5.5 0 0 0 2 1v2.5a.5.5 0 0 0 .5.5H3v2h-.5a.5.5 0 0 0-.5.5V6h-.5a.5.5 0 0 0-.5.5V8h-.5A.5.5 0 0 0 0 8.5V9h.5a.5.5 0 0 0 .5.5h2v2.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V10h2v-.5a.5.5 0 0 0-.5-.5h-1v-2h1a.5.5 0 0 0 .5-.5V5h1.5a.5.5 0 0 0 .5-.5V2.5a.5.5 0 0 0-.5-.5H2.5z" />
                        </svg>
                        <span> &nbsp;Offers</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_PRODUCT_REQUEST) ? 'active' : '' ?>" href="<?= base_url('admin/product/request') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-box-seam" viewBox="0 0 16 16">
                    <path d="M8.073.37a.5.5 0 0 1 .854 0l2.482 3.334 3.632.417a.5.5 0 0 1 .27.884l-2.646 2.42.781 3.62a.5.5 0 0 1-.739.542L8 9.267l-3.707 2.33a.5.5 0 0 1-.739-.542l.781-3.62L1.689 4.97a.5.5 0 0 1 .27-.884l3.632-.417L8.073.37zM8 1.481 5.904 4.168 2.48 4.57l2.533 2.31L4.8 10.088 8 8.345l3.2 1.743-.213-3.208 2.533-2.31-3.425-.402L8 1.481z" />
                    <path d="M5.052 6.106a.5.5 0 0 1 .696-.065L8 7.73l2.252-1.689a.5.5 0 0 1 .63.76L8.5 8.73v3.77a.5.5 0 0 1-1 0V8.73l-2.382-1.854a.5.5 0 0 1-.066-.696z" />
                </svg>
                <span>Product Request</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_PUSH_NOTIFICATION) ? 'active' : '' ?>" href="<?= base_url('admin/seller/notification') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-bell" viewBox="0 0 16 16">
                    <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.104-14.781c1.042-.268 2.21.142 2.745 1.07.534.93.335 1.783-.095 2.358-.43.576-1.062.943-1.622 1.416-.56.473-.953.987-1.08 1.663h4.048c.343 0 .678.195.802.497.124.302.052.643-.193.835C11.22 9.726 10 12 8 12c-2 0-3.22-2.274-3.606-3.14a.765.765 0 0 1-.193-.835.875.875 0 0 1 .802-.497h4.048c-.127-.676-.52-1.19-1.08-1.663-.56-.473-1.192-.84-1.622-1.416-.43-.575-.629-1.428-.095-2.358.535-.93 1.703-1.338 2.745-1.07zM8 1a2 2 0 1 1-4 0 2 2 0 0 1 4 0z" />
                </svg>
                <span>Push Notification</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_CUSTOMER_QUERY) ? 'active' : '' ?>" href="<?= base_url('admin/chat/') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16">
                    <path d="M2.678 11.894a1 1 0 0 1-.725-.314A7.5 7.5 0 1 1 13.042 4.24c-.69.69-1.31 1.243-1.87 1.652a6.5 6.5 0 1 0-6.5 6.5c.409-.56.962-1.18 1.652-1.87l-.006-.014z" />
                    <path d="M7.293 9.5a1 1 0 1 1 1.414 1.414 1 1 0 0 1-1.414-1.414zM10.5 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3-3.5a1 1 0 1 1-1.414-1.414A1 1 0 0 1 7.5 5.5zm3 0a1 1 0 1 1 1.414-1.414A1 1 0 0 1 10.5 5.5z" />
                </svg>
                <span>Customer Query</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($selected_option == SIDEBAR_OPTION_REFERRAL_REQUEST) ? 'active' : '' ?> " href="<?= base_url('admin/store/referral/requests') ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-bag" viewBox="0 0 16 16">
                    <path d="M10.5 0a2.5 2.5 0 0 1 2.5 2.5v1h-9V2.5A2.5 2.5 0 0 1 10.5 0zM5 2.5v1h6v-1a1.5 1.5 0 0 0-3 0h-1a1.5 1.5 0 0 0-3 0zM3 4v10a3 3 0 0 0 3 3h4a3 3 0 0 0 3-3V4H3zm1 0h8v10H4V4zm8.5 11a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm-7 0a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1z" />
                </svg>
                <span>Referral Requests</span>
            </a>
        </li>


    </ul>
</aside>