<?php
// $p = $seller_info;
// print "<pre>";
// print_r($p['uId']);
// die;
?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Product  Details </h1>
        <nav>
            <ol class="breadcrumb">
                <?php 
                 $u = $seller_info ; 
                ?>
                <li class="breadcrumb-item"><a href="<?= base_url("admin/seller/")?>">Seller Management </a></li> 
                <li class="breadcrumb-item"><a href="<?= base_url("admin/seller/").$u['uId']?>">Seller Details </a></li>
                <li class="breadcrumb-item">Product Details</li>
            </ol>
        </nav>
    </div>
    <section class="section dashboard">
        <div class="row mb-4">
            <h5>Product Images</h5>
            <div class="d-flex flex-wrap justify-content-start align-items-center">
                <?php $img_url = !empty($product['imageUrl']) ? $product['imageUrl'] : '\assets\Demo\sellerprofile.jfif'; ?>
               
                <img src="<?= base_url().$img_url ?>" alt="<?= $product['name'] ?>" style="width:300px; min-height: 300px; margin:20px ">
            </div>
        </div>
        <div class="row">
            <!-- <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5>Product Details</h5>
                    <hr>
                    <h6></h6>
                    <hr>
                    <h6></h6>
                    <hr>
                    <h6></h6>
                    <hr>
                    <h6></h6>
                    <hr>
                </div>
            </div> -->
            <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5>Category</h5>
                    <hr>
                    <h6>Name : <?= $product['CategoryName'] ?></h6>
                    <hr>
                    <?php $img_url = !empty($product['CategoryImage']) ? $product['CategoryImage'] : '\assets\Demo\category.jfif'; ?>

                    <img src="<?= base_url() . $img_url ?>" alt="<?= $product['CategoryName'] ?>">
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-3" style="min-height: 340px;">
                    <h5> Type </h5>
                    <hr>
                    <h6>Name : <?= $product['typeName'] ?></h6>
                    <hr>
                    <?php
                    $img_url = !empty($product['TypeImage']) ? $product['TypeImage'] : '\assets\Demo\category.jfif';
                    ?>

                    <img src="<?= base_url() . $img_url;  ?>" alt="<?= $product['typeName'] ?>">
                </div>
            </div>

            <div class="col-md-6">
                <div class="card p-3">
                    <h5>Product Details </h5>
                    <hr> Name : <?= $product['name'] ?>
                    <hr> Brand : <?= $product['brandName'] ?>
                    <hr> Title : <?= $product['title'] ?>
                    <hr> Color : <?= $product['color'] ?>
                    <hr> Available Size : <?= $product['availableSize'] ?>
                    <hr> Ideal For : <?= $product['idealFor'] ?>
                    <hr> Maximum Retail Price : <?= '₹' . $product['mrpPrice'] ?>
                    <hr> Selling : <?= '₹' . $product['sellingPrice'] ?>
                    <hr> Stock Quantity : <?= $product['stockQty'] ?>
                    <hr> Country : <?= $product['countryOfOrigin'] ?>
                    <hr> HSN Code : <?= $product['hsnCode'] ?>
                    <hr> GST Percent : <?= $product['gstPercent'] ?>
                    <hr> Manufacturer Details : <?= $product['manufacturerDetails'] ?>
                    <hr> Description : <?= $product['description'] ?>
                    <hr> Create At : <?= $product['createdAt'] ?>
                    <hr> Update At : <?= $product['updatedAt'] ?>
                </div>

            </div>

    </section>
</main>