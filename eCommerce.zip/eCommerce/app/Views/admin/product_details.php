<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php
$product = $productList;
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Product Details </h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url('admin/product') ?>">Product Management</a></li>
                <li class="breadcrumb-item">Product Details</li>
            </ol>
        </nav>
    </div>
    <section class="section">
        <div class="w3-row-padding w3-margin-top">
            <div class="w3-third">
                <?php foreach ($product['images'] as $image): ?>
                    <div class="w3-card">
                        <?php
                        // Base URL for images
                        $img = base_url($image->imageUrl);
                        $placeholderImage = base_url('assets/uploads/notFound.png'); // Path to placeholder image
                        ?>
                        <?php if (!empty($img)): ?>
                            <img src="<?php echo $img; ?>" alt="Product Image" style="width:100%; margin-bottom: 10px;">
                        <?php else: ?>
                            <p>Image Not Found</p> <!-- Message when image URL is not found -->
                            <img src="<?php echo $placeholderImage; ?>" alt="Image Not Found" style="width:100%; margin-bottom: 10px;">
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="w3-twothird">
                <div class="w3-card w3-padding">
                    <h3>Product Details</h3>
                    <p><strong>Name:</strong> <?= $product['product']->name ?? 'N/A' ?></p>
                    <p><strong>Title:</strong> <?= $product['product']->title ?? 'N/A' ?></p>
                    <p><strong>Brand:</strong> <?= $product['product']->brandName ?? 'N/A' ?></p>
                    <p><strong>Price:</strong> ₹<?= number_format($product['product']->sellingPrice ?? 0, 2) ?></p>
                    <p><strong>MRP Price:</strong> ₹<?= number_format($product['product']->mrpPrice ?? 0, 2) ?></p>
                    <p><strong>Color:</strong> <?= $product['product']->color ?? 'N/A' ?></p>
                    <p><strong>Available Sizes:</strong> <?= $product['product']->availableSize ?? 'N/A' ?></p>
                    <p><strong>Ideal For:</strong> <?= $product['product']->idealFor ?? 'N/A' ?></p>
                    <p><strong>Stock Quantity:</strong> <?= $product['product']->stockQty ?? 'N/A'; ?></p>
                    <p>
                        <strong>Stock Status:</strong>
                        <?php if ($product['product']->stock_status === PRODUCT_STOCK_STATUS_ON) {
                            echo '<span class="badge bg-primary rounded">ON</span>';
                        } else {
                            echo '<span class ="badge bg-danger rounded">OFF</span>';
                        }
                        ?>
                    </p>
                    <p><strong>Country of Origin:</strong> <?= $product['product']->countryOfOrigin ?? 'N/A' ?></p>
                    <p><strong>Manufacturer Details:</strong> <?= $product['product']->manufacturerDetails ?? 'N/A' ?></p>
                    <p><strong>HSN Code:</strong> <?= $product['product']->hsnCode ?? 'N/A' ?></p>
                    <p><strong>GST Percentage:</strong> <?= $product['product']->gstPercent ?? 'N/A' ?>%</p>
                    <p><strong>Created At:</strong> <?= date('d-m-Y H:i:s', strtotime($product['product']->createdAt ?? '')) ?></p>
                    <p>
                        <strong>Status:</strong>
                        <?php if ($product['product']->listingstatus == PRODUCT_LISTING_STATUS_ACTIVE) {
                            echo '<span class="badge text-dark bg-success rounded">Active</span>';
                        } else {
                            echo '<span class="badge bg-warning rounded">Inactive</span>';
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </section>



</main>