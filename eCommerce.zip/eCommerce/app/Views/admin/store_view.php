<style>
  #action {
    text-align: center;
    vertical-align: middle;
    padding: 0;
  }

  #action button {
    margin: 0;
    padding: 0.5rem;
    font-size: 2px;
  }
</style>

<main id="main" class="main">
  <div class="pagetitle">
    <h1>Store</h1>
  </div><!-- End Page Title -->
  <section class="section">
    <div class="row">
      <div class="col-lg-12 px-0">
        <div class="card">
          <div class="card-body p-3">
            <table id="storeTable" class="table datatable table-sm  table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th><b>Name</b></th>
                  <th>Owner</th>
                  <th>Address</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="product">
                <?php foreach ($store_list as $i => $store) { ?>
                  <?php //print"<pre>" ; print_r($store_list) ; die;  
                  ?>
                  <tr>
                    <td><?= $i + 1   ?></td>
                    <td><a href="<?= base_url('admin/store/') . $store->uId;  ?>"><?= ($store->name) ?></a></td>
                    <td style=" font-weight: bold;"><?= $store->userName ?></td>
                    <td><?= ($store->address) ?></td>
                    <td><?= date('d/m/Y', strtotime($store->createdAt)) . '<br/>' . date('h:i A', strtotime($store->createdAt)) ?></td>
                    <td>
                      <?php if ($store->state == STORE_INACTIVE) {
                        echo '<span class="badge text-dark bg-warning rounded">Inactive</span>';
                      } elseif ($store->state == STORE_ACTIVE) {
                        echo '<span class="badge bg-success rounded">Active</span>';
                      } elseif ($store->state == STORE_DELETED) {
                        echo '<span class="badge bg-danger rounded">Delete</span>';
                      } ?>
                    </td>
                    <td id="action">
                      <button type="button" onclick="return openDeleteModal('<?= $store->uId ?>')" class="btn btn-danger btn-sm rounded-pill">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                          <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                          <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                <?php } ?>
              </tbody> <!-- End tbody -->
            </table>
            <!-- End Table with stripped rows -->
          </div>
        </div>
      </div>
    </div>
  </section>
</main>
<!-- ========= Start  Delete Model =====  -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this item? <span style="color: red; font-weight: bold;">This action cannot be undone.</span></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
      </div>
    </div>
  </div>
</div>
<!-- ========= End  Delete Model =====  -->



<script>
  let StoreDeleteUid;
  function openDeleteModal(uId) {
    StoreDeleteUid = uId;
    $('#deleteModal').modal('show');
  }
  $('#confirmDelete').on('click', function() {
    $.ajax({
      url: '<?= base_url('delete/store') ?>',
      method: "POST",
      dataType: "JSON",
      data: {
        uId: StoreDeleteUid,
      },
      success: function(response) {
        $('#deleteModal').modal('hide');
        showToast(response.message);
        location.reload();
      }
    });
  });

  $(document).ready(function() {
    $('#storeTable').DataTable();
    $(['title']).tooltip();
  });
</script>