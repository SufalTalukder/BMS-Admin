<main id="main" class="main">
    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Seller Management</h5>
                        <!-- Table with stripped rows -->
                        <table id="table" class="table datatable table-hover table-bordered table-sm table-striped  display ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>
                                        <b>N</b>ame
                                    </th>
                                    <th>Email</th>
                                    <th>Mobile No </th>
                                    <th>Create At</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="showSeller">

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- ========= Start  Delete Model =====  -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content text-center">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this item? <span style="color: red; font-weight: bold;">This action cannot be undone.</span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <!-- ========= End  Delete Model =====  -->
</main>
<script>
    const SELLER_STATUS_ACTIVE = '<?= SELLER_STATUS_ACTIVE ?>';
    const SELLER_STATUS_INACTIVE = '<?= SELLER_STATUS_INACTIVE ?>';
    const SELLER_STATUS_DELETED = '<?= SELLER_STATUS_DELETED ?>';
    let sellerDelete;

    $(document).ready(function() {
        function fetchSeller() {
            $.ajax({
                url: "<?= base_url('fetch/seller') ?>",
                type: "POST",
                dataType: "JSON",
                success: function(response) {
                    console.log(response);
                    if (response.status) {
                        let count = 1;
                        $('.datatable tbody').empty();

                        $.each(response.data, function(index, seller) {
                            let statusText, statusClass;
                            if (seller.state == SELLER_STATUS_DELETED) {
                                statusText = 'Deleted';
                                statusClass = 'badge bg-danger rounded';
                            } else if (seller.state == SELLER_STATUS_ACTIVE) {
                                statusText = 'Active';
                                statusClass = 'badge bg-success rounded';
                            } else if (seller.state == SELLER_STATUS_INACTIVE) {
                                statusText = 'Inactive';
                                statusClass = 'badge bg-warning text-dark rounded';
                            } else {
                                statusText = 'Unknown';
                                statusClass = 'badge bg-secondary rounded';
                            }
                            $('.datatable tbody').append(`
                                    <tr>
                                        <td>${count}</td>
                                        <td><a href="<?= base_url('admin/seller/') ?>${seller.uId}" >${seller.name}</a></td>
                                        <td>${seller.email}</td>
                                        <td>${seller.mobileNo}</td>                              
                                        <td>${formatDate(seller.createdAt)}</td>
                                        <td><span class="${statusClass}">${statusText}</span></td>
                                        <td>
                                             <button type="button" class="btn btn-danger btn-sm rounded-pill" onclick="return openDeleteModal('${seller.uId}');" ${seller.state == '<?= SELLER_STATUS_DELETED ?>' ? 'disabled' : '' } >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                       <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                                       <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                                </svg>
                                             </button>
                                        </td>
                                    </tr>
                            `);
                            count++;
                        })
                        $('#table').dataTable();
                    }
                }
            })
        }
        fetchSeller();
    })

    function openDeleteModal(uId) {
        sellerDelete = uId;
        $('#deleteModal').modal('show');
    }
    $('#confirmDelete').on('click', function() {
        $.ajax({
            url: '<?= base_url('delete/seller') ?>',
            method: 'POST',
            dataType: 'JSON',
            data: {
                uId: sellerDelete,
            },
            success: function(response) {
                $('#deleteModal').modal('hide');
                showToast(response.message);
                location.reload();
            }
        })

    })
</script>