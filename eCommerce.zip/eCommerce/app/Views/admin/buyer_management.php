<main id="main" class="main">
    <div class="pagetitle">
        <h1>Buyer</h1>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12 px-0">
                <div class="card">
                    <div class="card-body p-3">
                        <table id="table" class="table table-hover ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><b>N</b>ame</th>
                                    <th>Email</th>
                                    <th>Mobile NO</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="buyer">
                                <td colspan="5">
                                    <center>Buyer List Loading...</center>
                                </td>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- ========= Start  Delete Model =====  -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this item? <span style="color: red; font-weight: bold;">This action cannot be undone.</span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
            </div>
        </div>
    </div>
</div>
<!-- ========= End  Delete Model =====  -->

<script>
    const DELETE = '<?= BUYER_STATUS_DELETED ?>';
    const BUYER_ONLINE = '<?= USER_STATUS_ONLINE ?>';
    let DeleteUid;

    $(document).ready(function() {
        function fetchBuyer() {
            $.ajax({
                url: "<?php echo base_url('fetch/buyer'); ?>",
                type: "POST",
                dataType: "JSON",
                success: function(response) {
                    if (response.status) {
                        $('#buyer').empty();
                        $.each(response.data, function(index, buyer) {
                            let statusBadge = buyer.online_status === BUYER_ONLINE ?
                                '<span class="badge bg-primary text-white">Online</span>' :
                                '<span class="badge bg-danger text-white">Offline</span>';
                            $('#buyer').append(`<tr>   
                                                    <td>${index + 1}</td>                         
                                                    <td><a href="<?php echo base_url('admin/buyer/') ?>${buyer.uId}">${buyer.name}</a></td>
                                                    <td>${buyer.email}</td>
                                                    <td>${buyer.mobileNo}</td>
                                                    <td>${statusBadge}</td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm rounded-pill" 
                                                            onclick="return openDeleteModal('${buyer.uId}');" 
                                                            ${buyer.state == DELETE ? 'disabled' : ''}>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                                                <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                                            </svg>
                                                        </button>
                                                    </td>
                                                 </tr>
                                                 `);
                        });
                        $('#table').dataTable();
                    }
                },
                error: function(error) {
                    console.error("Error fetching buyers:", error);
                }
            });
        }
        $(document).on('click', '.view-info', function() {
            const uId = $(this).data('uid');
            show_buyer_data(uId);
        });
        fetchBuyer();
    });


    function openDeleteModal(uId) {
        DeleteUid = uId;
        $('#deleteModal').modal('show');
    }
    $('#confirmDelete').on('click', function() {
        $.ajax({
            url: '<?= base_url('delete/buyer'); ?>',
            method: "POST",
            dataType: "JSON",
            data: {
                uId: DeleteUid,
            },
            success: function(response) {
                $('#deleteModal').modal('hide');
                showToast(response.message);
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error('Error deleting item:', error);
            }
        });
    })
</script>