<main id="main" class="main">

    <div class="pagetitle">
        <h1 style="color:Red;">Store Offers </h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="table-responsive">

                            <table id="requestTable" class="table table-middle table-striped font-12 whitespace-nowrap table-bordered  table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Store Name </th>
                                        <th>Image</th>
                                        <th><b>Title</b></th>
                                        <th>Product</th>
                                        <th>description</th>
                                        <th>Discount Type</th>
                                        <th>Discount</th>
                                        <th>Min Amount</th>
                                        <th>Start Date</th>
                                        <th>Start Time</th>
                                        <th>End Date</th>
                                        <th>End Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach ($store_offers as $i =>  $storeOffer) { ?>

                                        <tr>
                                            <td><?= $i +  1  ?></td>
                                            <td><?= $storeOffer['StoreName'] ?></td>
                                            <td>
                                                <?php $img = (!empty($storeOffer['imageUrl'])) ? base_url($storeOffer['imageUrl']) : 'NA'   ?>
                                                <a href="<?= $img ?>" ><img src="<?= $img ?>" width="40px" height="40px"></a>
                                            </td>
                                            <td><?= $storeOffer['title'] ?></td>
                                            <td>
                                                <select name="product" id="productId" onchange="redirectToProductDetail(this.value)">
                                                    <option value="">Select Product</option>
                                                    <?php foreach ($storeOffer['product'] as &$product) { ?>
                                                        <option value="<?= base_url('admin/product/detail/') . $product->productId ?>">
                                                            <?= $product->ProductName ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </td>
                                            <td><?= $storeOffer['description'] ?></td>
                                            <td><?= $storeOffer['discountType'] ?></td>
                                            <td><?= $storeOffer['discount'] ?></td>
                                            <td><?= '₹' . $storeOffer['minAmount'] ?></td>
                                            <td>
                                                <?php
                                                $startDateTimeUTC = new DateTime($storeOffer['startDate'] . ' ' . $storeOffer['startTime'], new DateTimeZone('UTC'));
                                                echo $startDateTimeUTC->format('d-m-Y');
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                echo $startDateTimeUTC->format('h:i A');
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                $endDateTimeUTC = new DateTime($storeOffer['endDate'] . ' ' . $storeOffer['endTime'], new DateTimeZone('UTC'));
                                                echo $endDateTimeUTC->format('d-m-Y');
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                echo $endDateTimeUTC->format('h:i A');
                                                ?>
                                            </td>
                                            </td>
                                            <td> <?php
                                                    if ($storeOffer['state'] == STORE_OFFER_ACTIVE) {
                                                        echo '<span class="badge text-white bg-success rounded">Active</span>';
                                                    } elseif ($storeOffer['state'] == STORE_OFFER_INACTIVE) {
                                                        echo '<span class="badge text-white bg-info rounded">Inactive</span>';
                                                    } elseif ($storeOffer['state'] == STORE_OFFER_DELETED) {
                                                        echo '<span class="badge text-white bg-danger rounded">Delete</span>';
                                                    } else {
                                                        echo '<span class="badge text-dark bg-secondary rounded">Unknown</span>';
                                                    }
                                                    ?></td>
                                            <td>
                                                <button type="button" class="btn btn-danger btn-sm rounded-pill" onclick=" return  openDeleteModal('<?= $storeOffer['uId'] ?>')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                                        <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                                    </svg>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content text-center">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this item? <span style="color: red; font-weight: bold;">This action cannot be undone.</span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn btn-danger" id="confirmDelete">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#requestTable').DataTable();
        });

        function redirectToProductDetail(url) {
            if (url) {
                window.location.href = url;
            }
        }

        function openDeleteModal(uId) {
            itemIdToDelete = uId;
            $('#deleteModal').modal('show');
            return false;
        }

        $('#confirmDelete').on('click', function() {
            $.ajax({
                url: '<?= base_url('delete/store-offer') ?>',
                type: 'POST',
                data: {
                    uId: itemIdToDelete
                },
                success: function(response) {
                    $('#deleteModal').modal('hide');
                    showToast(response.message);
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error('Error deleting item:', error);
                }
            });
        });
    </script>