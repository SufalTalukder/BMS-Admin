<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #444;
            margin-bottom: 15px;
        }

        h1 {
            text-align: center;
            font-size: 2em;
        }

        h2 {
            font-size: 1.5em;
            margin-top: 20px;
        }

        p {
            margin-bottom: 15px;
            line-height: 1.6;
        }

        ul {
            list-style: disc;
            margin: 10px 0 20px 20px;
        }

        .section {
            margin-bottom: 30px;
        }

        footer {
            text-align: center;
            font-size: 0.9em;
            color: #666;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Privacy Policy</h1>
    
    <div class="section">
        <h2>1. Introduction</h2>
        <p>Welcome to our Privacy Policy page. Here, we explain how we collect, use, and protect your information when you use our services. By using our services, you agree to the collection and use of information in accordance with this policy.</p>
    </div>

    <div class="section">
        <h2>2. Information We Collect</h2>
        <p>We may collect the following types of information:</p>
        <ul>
            <li><strong>Personal Data:</strong> Such as your name, email address, phone number, etc., that you voluntarily provide to us.</li>
            <li><strong>Usage Data:</strong> Information on how you access and use our services, including your IP address, browser type, and usage patterns.</li>
        </ul>
    </div>

    <div class="section">
        <h2>3. How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
            <li>Provide and maintain our services.</li>
            <li>Notify you about changes to our services.</li>
            <li>Allow you to participate in interactive features of our services when you choose to do so.</li>
            <li>Monitor usage to improve the quality and functionality of our services.</li>
            <li>Communicate with you, including customer support and service updates.</li>
        </ul>
    </div>

    <div class="section">
        <h2>4. Sharing Your Information</h2>
        <p>We do not share your personal data with third parties except in the following cases:</p>
        <ul>
            <li>With service providers who help us in providing and managing our services.</li>
            <li>When required by law or to respond to legal requests.</li>
            <li>In connection with the sale, merger, or acquisition of our company.</li>
        </ul>
    </div>

    <div class="section">
        <h2>5. Security of Your Information</h2>
        <p>We strive to use commercially acceptable means to protect your personal data, but please remember that no method of transmission over the internet or method of electronic storage is 100% secure.</p>
    </div>

    <div class="section">
        <h2>6. Your Data Protection Rights</h2>
        <p>Depending on your location, you may have the following rights regarding your personal data:</p>
        <ul>
            <li>The right to access, update, or delete the information we have on you.</li>
            <li>The right to object to processing of your data.</li>
            <li>The right to data portability.</li>
            <li>The right to withdraw consent.</li>
        </ul>
    </div>

    <div class="section">
        <h2>7. Changes to Our Privacy Policy</h2>
        <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>
    </div>

    <div class="section">
        <h2>8. Contact Us</h2>
        <p>If you have any questions about our Privacy Policy, please contact us at: <a href="mailto:support@example.com">support@example.com</a></p>
    </div>

    <footer>
        &copy; 2023 Your Company Name. All Rights Reserved.
    </footer>
</div>

</body>
</html>
