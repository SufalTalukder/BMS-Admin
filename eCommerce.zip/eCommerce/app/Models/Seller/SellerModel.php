<?php

namespace App\Models\Seller;

use CodeIgniter\Model;

class SellerModel extends Model
{

  public function get_system_preference_data($condition)
  {
    $data = $this->db->table('system_preferance')->where($condition)->get()->getRow();
    return (!empty($data->value)) ? $data->value : NULL;
  }

  public function save_user($data)
  {
    $inserted = $this->db->table('user_accounts')->insert($data);

    return $inserted;
  }

  public function get_user_account_data($condition)
  {
    return $this->db->table('user_accounts')->where($condition)->get()->getRow();
  }

  public function update_user_account_data($data, $condition)
  {
    return $this->db->table('user_accounts')->set($data)->where($condition)->update();
  }

  public function get_user_data_by_email_mobile($PhoneEmail)
  {
    $sql = "select id ,name , uId, email,password,mobileNo,userType,state  from `user_accounts` where 
      (`email`='" . $PhoneEmail . "' and `email`!='') or (`mobileNo`='" . $PhoneEmail . "' and `mobileNo`!='') ";
    $query = $this->db->query($sql)->getRow();;
    return $query;
  }

  public function save_otp($data)
  {
    $inserted = $this->db->table('otp_list')->insert($data);
    //  return $this->db->insert('user_accounts', $data);
    return $inserted;
  }

  public function get_otp_data($otp)
  {
    $sql = "select *   from `otp_list` where  `otp`='" . $otp . "' and `isVerify`='I' order by id desc limit 0,1  ";
    $query = $this->db->query($sql)->getRow();
    return $query;
  }
  public function update_otp_data($otp)
  {
    $sql = "update `otp_list` set `isVerify`='V'  where  `otp`='" . $otp . "' and `isVerify`='I'    ";
    $query = $this->db->query($sql);
    return $query;
  }

  public function save_store_details($data)
  {
    $inserted = $this->db->table('store')->insert($data);
    return $inserted;
  }

  public function save_document($data)
  {
    $inserted = $this->db->table('user_document')->insert($data);
    return $inserted;
  }

  public function save_bank_details($data)
  {
    $inserted = $this->db->table('bank_account')->insert($data);

    return $inserted;
  }

  public function save_product($data)
  {
    $inserted = $this->db->table('product')->insert($data);

    return $inserted;
  }



  public function get_product_details($condition)
  {
    return $this->db->table('product')->where($condition)->get()->getRow();
  }

  public function get_save_product_list_by_id($condition)
  {
    $builder = $this->db->table('save_product')->where($condition)->get()->getRow();

    return $builder;
  }

  public function update_product_listing_status($listingStatus, $storeId, $productId)
  {
    // Build the query to update only the 'listingstatus' column
    $builder = $this->db->table('product');
    $builder->set('listingstatus', $listingStatus);
    $builder->where('storeId', $storeId);
    $builder->where('uId', $productId);

    // Execute the update query
    $result = $builder->update();

    // Return the result
    return $result;
  }


  public function get_product_list_storewise($storeId)
  {
    $conditions = [
      'listingstatus' => 'ACTIVE',
      'storeId' => $storeId,
    ];
    $builder = $this->db->table('product');
    $builder->select(['uId as productId', 'name', 'brandName', 'title', 'description', 'color', 'mrpPrice', 'sellingPrice']);
    $builder->where($conditions);
    $query = $builder->get()->getResult();
    return $query;
  }

  public function get_user_details($userId)
  {

    $conditions = [
      'state' => 'ACTIVE',
      'uId' => $userId,
    ];


    $builder = $this->db->table('user_accounts');
    $builder->select(['uId as userId', 'name', 'mobileNo', 'email', 'address', 'online_status', 'profileImageLink']);
    $builder->where($conditions);
    $user_details = $builder->get()->getRow();


    $storeDetails = $this->db->table('store')
      ->select('uId AS storeId')

      ->where(['userId' => $userId])
      ->get()->getRow();

    if (!empty($storeDetails->store_id)) {
      $user_details->storeId = $storeDetails->store_id;
    } else {
      $user_details->storeId = "";
    }

    if (!empty($user_details->profileImageLink)) {
      $user_details->profileImageLink = base_url($user_details->profileImageLink);
    } else {
      $user_details->profileImageLink = base_url('assets/uploads/profile_image/no-image-found.png');
    }

    if (!empty($user_details->userId))

      return $user_details;
  }

  public function get_seller_products_list($store_id)
  {
    $products_list = $this->db->table('product AS P')
      ->select('P.uId AS id,
                                          PC.name AS category,
                                          P.name,
                                          P.title,
                                          P.description,
                                          P.sellingPrice AS price,
                                          P.stockQty AS stock_quantity,
                                          P.listingstatus AS listing_status')
      ->join('product_category AS PC', 'PC.uId = P.categoryId')
      ->where('storeId', $store_id)
      ->get()->getResult();

    foreach ($products_list as $i => $product_details) {
      $product_image = $this->db->table("product_image")
        ->select('imageUrl')
        ->where('prodId', $product_details->id)
        ->get()->getRow();

      if (!empty($product_image->imageUrl) && file_exists(FCPATH . $product_image->imageUrl)) {
        $product_details->image = base_url($product_image->imageUrl);
      } else {
        $product_details->image = base_url('assets/uploads/product_images/no-image-found.png');
      }

      $product_details->price = floatval($product_details->price);
      $product_details->stock_quantity = intval($product_details->stock_quantity);
      $product_details->listing_status = ($product_details->listing_status == 'ACTIVE') ? true : false;
    }

    return $products_list;
  }


  public function get_store_offer($storeId)
  {
    $activeList = [];
    $inactiveList = [];
    $deletedList = [];
    $conditions = ['storeId' => $storeId];

    $builder = $this->db->table('store_offer');
    $builder->select([
      'uId as offerId',
      'title',
      'applicableOnProduct',
      'mrpPrice',
      'startDate',
      'startTime',
      'endDate',
      'endTime',
      'minAmount',
      'description',
      'dicountType',
      'discount',
      'startDate',
      'endDate',
      'imageUrl',
      'state'
    ]);
    $builder->where($conditions);
    $builder->orderBy('startDate', 'DESC');
    $query = $builder->get()->getResult();

    foreach ($query as $i => $row) {
      if ($row->state == 'ACTIVE') {
        $activeList[] = [
          'offerId' => $row->offerId,
          'title' => $row->title,
          'description' => $row->description,
          'image' => base_url($row->imageUrl),
          'dicountType' => $row->dicountType,
          'applicableOnProduct' => $row->applicableOnProduct,
          'mrpPrice' => $row->mrpPrice,
          'discount' => $row->discount,
          'minAmount' => $row->minAmount,
          'startDate' => $row->startDate,
          'startTime' => $row->startTime,
          'endDate' => $row->endDate,
          'endTime' => $row->endTime,
        ];

        // $activeList[$i]['offerId'] = $row->offerId;
        // $activeList[$i]['title'] = $row->title;
        // $activeList[$i]['description'] = $row->description;
        // $activeList[$i]['dicountType'] = $row->dicountType;
        // $activeList[$i]['discount'] = $row->discount;
        // $activeList[$i]['startDate'] = $row->startDate;
        // $activeList[$i]['endDate'] = $row->endDate;
      } elseif ($row->state == 'INACTIVE') {
        $inactiveList[] = [
          'offerId' => $row->offerId,
          'title' => $row->title,
          'description' => $row->description,
          'image' => base_url($row->imageUrl),
          'dicountType' => $row->dicountType,
          'applicableOnProduct' => $row->applicableOnProduct,
          'mrpPrice' => $row->mrpPrice,
          'discount' => $row->discount,
          'minAmount' => $row->minAmount,
          'startDate' => $row->startDate,
          'startTime' => $row->startTime,
          'endDate' => $row->endDate,
          'endTime' => $row->endTime,
        ];

        // $activeList[$i]['offerId'] = $row->offerId;
        // $inactiveList[$i]['title'] = $row->title;
        // $inactiveList[$i]['description'] = $row->description;
        // $inactiveList[$i]['dicountType'] = $row->dicountType;
        // $inactiveList[$i]['discount'] = $row->discount;
        // $inactiveList[$i]['startDate'] = $row->startDate;
        // $inactiveList[$i]['endDate'] = $row->endDate;
      } elseif ($row->state == 'DELETED') {
        $deletedList[] = [
          'offerId' => $row->offerId,
          'title' => $row->title,
          'description' => $row->description,
          'image' => base_url($row->imageUrl),
          'dicountType' => $row->dicountType,
          'applicableOnProduct' => $row->applicableOnProduct,
          'mrpPrice' => $row->mrpPrice,
          'discount' => $row->discount,
          'minAmount' => $row->minAmount,
          'startDate' => $row->startDate,
          'startTime' => $row->startTime,
          'endDate' => $row->endDate,
          'endTime' => $row->endTime,
        ];

        // $activeList[$i]['offerId'] = $row->offerId;
        // $deletedList[$i]['title'] = $row->title;
        // $deletedList[$i]['description'] = $row->description;
        // $deletedList[$i]['dicountType'] = $row->dicountType;
        // $deletedList[$i]['discount'] = $row->discount;
        // $deletedList[$i]['startDate'] = $row->startDate;
        // $deletedList[$i]['endDate'] = $row->endDate;
      }
    }

    $offerList = [
      'activeList' => $activeList,
      'inactiveList' => $inactiveList,
      'deletedList' => $deletedList,
    ];

    return $offerList;
  }


  public function save_offer($data)
  {
    $inserted = $this->db->table('store_offer')->insert($data);
    return $inserted;
  }

  public function add_store_offer_By_addProduct($offerstoredata)
  {

    $inserted = $this->db->table('store_product_offer')->insert($offerstoredata);
    return $inserted;
  }


  public function get_store_offer_details($condition)
  {
    return $this->db->table('store_offer')->where($condition)->get()->getRow();
  }

  public function edit_offer($data, $condition)
  {
    $builder = $this->db->table('store_offer');
    $builder->set($data);
    $builder->where($condition);
    $updated = $builder->update();
    return $updated;
  }

  public function get_requested_product_list($storeId)
  {
    $resultData = [];
    $sql = "SELECT uId, name, title, description 
              FROM `product` 
              WHERE `uId` IN (SELECT productId 
                              FROM customer_product_request 
                              WHERE storeId = '" . $storeId . "');";
    $query = $this->db->query($sql)->getResult();

    foreach ($query as $i => $row) {
      $productId = $query[$i]->uId;


      $productImage = $this->get_product_images($productId);
      if (!empty($productImage)) {
        $productImageArr = array_column($productImage, 'prodImageUrl');
        $image = $productImageArr[0];
      } else {
        $image = null;
      }
      $customerList = $this->interested_buyer_list_pruduct_wise($productId);
      $resultData[$i]['uId'] = $row->uId;
      $resultData[$i]['title'] = $row->title;
      $resultData[$i]['name'] = $row->name;
      $resultData[$i]['description'] = $row->description;
      $resultData[$i]['image'] = base_url($image);
      $resultData[$i]['customer'] = $customerList;
    }
    if (!empty($customerList)) {
      return $resultData;
    } else {
      return false;
    }
  }

  public function get_seller_referral_requests_by_store_id($storeId)
  {
    $response = [
      'status' => false,
      'message' => 'Error Occurred! Failed to get referral requests.',
      'data' => []
    ];

    $seller_details = $this->db->table('store AS S')
      ->select('U.ownReferralCode AS referralCode, U.userType')
      ->join('user_accounts AS U', 'U.uId = S.userId')
      ->where('S.uId', $storeId)->get()->getRow();
    if (!empty($seller_details->referralCode)) {
      $referral_requests = $this->db->table('referral_requests AS RR')
        ->select('RR.uId AS referral_request_id,
                                                U1.name AS referrer_name,
                                                U1.email AS referrer_email,
                                                U1.mobileNo AS referrer_mobile,
                                                U2.name AS referred_name,
                                                U2.email AS referred_email,
                                                U2.mobileNo AS referred_mobile,
                                                DATE_FORMAT(RR.createdAt, "%d/%m/%Y") AS referral_date')
        ->join('user_accounts AS U1', 'U1.uId = RR.referrerUserId')
        ->join('user_accounts AS U2', 'U2.uId = RR.referredUserId')
        ->where([
          'RR.status' => REFERRAL_REQUESTS_STATUS_COMPLETE,
          'RR.type' => $seller_details->userType,
          'RR.referralCode' => $seller_details->referralCode
        ])->get()->getResult();


      if (!empty($referral_requests)) {
        $response = ['status' => true, 'message' => 'Referral Requests Get Successfully.', 'data' => $referral_requests];
      } else {
        $response = ['status' => true, 'message' => 'No Referral Requests Found.', 'data' => []];
      }
    } else {
      $response['message'] = 'Error Occurred! Store owner details not found.';
    }

    return $response;
  }

  public function get_seller_referral_rewards_by_store_id($storeId)
  {
    $response = [
      'status' => false,
      'message' => 'Error Occurred! Failed to get referral rewards.',
      'data' => []
    ];

    $seller_details = $this->db->table('store AS S')
      ->select('U.ownReferralCode AS referralCode, U.userType')
      ->join('user_accounts AS U', 'U.uId = S.userId')
      ->where('S.uId', $storeId)->get()->getRow();

    if (!empty($seller_details->referralCode)) {
      $referral_requests = $this->db->table('referral_requests AS RR')
        ->select('RR.uId AS referral_request_id,
                      U1.name AS referrer_name,
                      U1.email AS referrer_email,
                      U1.mobileNo AS referrer_mobile,
                      IF (RR.referrerUserRewardType = "PERCENT",
                          CONCAT(RR.referrerUserReward, "%"),
                          CONCAT("₹", RR.referrerUserReward)) AS referrer_reward,
                      RR.referrerUserReward,  
                      U2.name AS referred_name,
                      U2.email AS referred_email,
                      U2.mobileNo AS referred_mobile,
                      IF (RR.referredUserRewardType = "PERCENT",
                          CONCAT(RR.referredUserReward, "%"),
                          CONCAT("₹", RR.referredUserReward)) AS referred_reward,
                      DATE_FORMAT(RR.createdAt, "%d/%m/%Y") AS referral_date')
        ->join('user_accounts AS U1', 'U1.uId = RR.referrerUserId')
        ->join('user_accounts AS U2', 'U2.uId = RR.referredUserId')
        ->where([
          'RR.status' => REFERRAL_REQUESTS_STATUS_REWARDED,
          'RR.type' => $seller_details->userType,
          'RR.referralCode' => $seller_details->referralCode
        ])->get()->getResult();

      if (!empty($referral_requests)) {
        $total_earnings = array_reduce($referral_requests, function ($total, $reward) {
          return $total + (float) $reward->referrerUserReward;
        }, 0);


        $response = [
          'status' => true,
          'message' => 'Referral Rewards Get Successfully.',
          'data' => $referral_requests,
          'total_earnings' => '₹' . number_format($total_earnings, 2)
        ];
      } else {
        $response = ['status' => true, 'message' => 'No Referral Rewards Found.', 'data' => []];
      }
    } else {
      $response['message'] = 'Error Occurred! Store owner details not found.';
    }

    return $response;
  }


  public function add_seller_referral_reward($requestId,  $data)
  {
    $sql = $this->db->table('referral_requests')->set($data)->where('uId', $requestId)->update();
    return $sql;
  }

  public function add_product_image($image_data)
  {
    return $this->db->table('product_image')->insert($image_data);
  }
  public function add_store_image($imageData)
  {
    return $this->db->table('store_image')->insert($imageData);
  }


  public function save_product_images($image_data)
  {
    // print_r($image_data);
    return $this->db->table('save_product_images')->insert($image_data);
  }

  public function get_product_images($prodId)
  {
    $conditions = [
      'state' => 'ACTIVE',
      'prodId' => $prodId,
    ];
    $builder = $this->db->table('product_image');
    $builder->select(['imageUrl as prodImageUrl']);
    $builder->where($conditions);
    $query = $builder->get()->getResult();
    return $query;
  }

  public function interested_buyer_list_pruduct_wise($productId)
  {
    $sql = "select uId,name,mobileNo,email, CONCAT('" . base_url() . "', profileImageLink) AS profileImageLink   from `user_accounts` where  `uId` in(
      select userId from customer_product_request where productId='" . $productId . "'
      )  ";
    $query = $this->db->query($sql)->getResult();
    return $query;
  }


  public function get_recent_transactions($storeId, $sortBy = 'DESC')
  {

    $sortBy = strtoupper($sortBy);
    if ($sortBy !== 'ASC' && $sortBy !== 'DESC') {
      $sortBy = 'DESC';
    }

    $baseUrl = base_url();
    $sql = "SELECT  p.uId AS paymentId,  p.payAmount,  p.createdAt,  p.status,  u.name AS customerName,
                    u.profileImageLink    FROM  `store_payment` AS p 
                      LEFT JOIN  user_accounts AS u ON p.userId = u.uId 
            WHERE   p.storeId = '" . $storeId . "'  AND p.state = 'ACTIVE'  ORDER BY  p.createdAt " . $sortBy;
    $query = $this->db->query($sql);
    $results = $query->getResult();
    foreach ($results as $result) {
      $result->profileImageLink = $baseUrl . $result->profileImageLink;
    }
    return $results;
  }


  // public function get_dashboard_data($storeId, $categoryId = null, $typeId = null)
  // {
  //   $resultData = [];

  //   $storeDetails = $this->get_store_details($storeId);
  //   $builder = $this->db->table('product');
  //   $builder->select("SUM(IF(listingstatus='ACTIVE', 1, 0)) AS TotActiveProduct, SUM(IF(listingstatus='INACTIVE', 1, 0)) AS TotSavedProduct");
  //   $builder->where('storeId', $storeId);
  //   $productSummery = $builder->get()->getRow();
  //   // $builder = $this->db->table('product p');
  //   $builder = $this->db->table('product p');
  //   $builder->select('p.uId AS productId, p.name, p.brandName, p.title, p.description, 
  //                     p.color, p.availableSize, p.idealFor, p.stockQty, p.mrpPrice, p.manufacturerDetails, p.hsnCode,
  //                     p.sellingPrice, p.gstPercent ,  p.countryOfOrigin ,  p.stockQty
  //                     AS stock, p.listingstatus, p.stock_status, p.createdAt, 
  //                     pc.uId AS categoryId , pc.name AS categoryName, pt.uId AS categoryTypeId ,  
  //                     pt.name AS categoryType , sf.store_offer_id AS storeOfferId ,sf.title As offerName , sf.description AS offerDescription 
  //                     ');

  //   $builder->join('store_product_offer sf', 'sf.prodId = p.uId', 'left');
  //   $builder->join('product_category pc', 'pc.uId = p.categoryId', 'left');
  //   $builder->join('product_type pt', 'pt.uId = p.typeId', 'left');
  //   $builder->where('p.storeId', $storeId);
  //   $builder->whereIn('p.listingstatus', ['ACTIVE', 'INACTIVE']);

  //   if ($categoryId) {
  //     $builder->where('p.categoryId', $categoryId);
  //   }
  //   if ($typeId) {
  //     $builder->where('p.typeId', $typeId);
  //   }

  //   $builder->orderBy('p.id', 'DESC');
  //   $builder->limit(10, 0);

  //   $newlyProductList = $builder->get()->getResult();

  //   foreach ($newlyProductList as $product) {

  //     $product_image = $this->db->table('product_image')
  //       ->select('uId,imageUrl')
  //       ->where('prodId', $product->productId)
  //       ->get()->getResult();
  //     $imageList = [];
  //     if (!empty($product_image)) {
  //       foreach ($product_image as $img) {
  //         $imageList[] = [
  //           'url' => base_url($img->imageUrl),
  //           'id' => $img->uId
  //         ];
  //       }
  //     } else {
  //     }
  //     $product->images = $imageList;
  //     $product->inStock = ($product->stockQty > 0) ? true : false;
  //   }



  //   $resultData['storeName'] = $storeDetails->name;
  //   $resultData['TotActiveProduct'] = $productSummery->TotActiveProduct;
  //   $resultData['TotSavedProduct'] = $productSummery->TotSavedProduct;
  //   $resultData['newProducts'] = $newlyProductList;

  //   return $resultData;
  // }


  public function get_dashboard_data($storeId, $categoryId = null, $typeId = null)
  {
    $resultData = [];

    // Store Details
    $storeDetails = $this->get_store_details($storeId);

    // Published Products Query
    $publishedBuilder = $this->db->table('product p');
    $publishedBuilder->select('p.uId AS productId, p.name, p.brandName, p.title, p.description, 
                                p.color, p.availableSize, p.idealFor, p.stockQty, p.mrpPrice, p.manufacturerDetails, 
                                p.sellingPrice, p.gstPercent, p.hsnCode, p.countryOfOrigin, p.stockQty AS stock, 
                                p.listingstatus, p.stock_status, p.createdAt, 
                                pc.uId AS categoryId, pc.name AS categoryName, 
                                pt.uId AS categoryTypeId, pt.name AS categoryType,
                                sf.store_offer_id AS storeOfferId, sf.title AS offerName, sf.description AS offerDescription,
                                '); // Add a marker for product type
    $publishedBuilder->join('store_product_offer sf', 'sf.prodId = p.uId', 'left');
    $publishedBuilder->join('product_category pc', 'pc.uId = p.categoryId', 'left');
    $publishedBuilder->join('product_type pt', 'pt.uId = p.typeId', 'left');
    $publishedBuilder->where('p.storeId', $storeId);
    $publishedBuilder->whereIn('p.listingstatus', ['ACTIVE', 'INACTIVE']);

    if ($categoryId) {
      $publishedBuilder->where('p.categoryId', $categoryId);
    }
    if ($typeId) {
      $publishedBuilder->where('p.typeId', $typeId);
    }

    $publishedBuilder->orderBy('p.id', 'DESC');
    $publishedBuilder->limit(10, 0);
    $publishedProducts = $publishedBuilder->get()->getResult();

    // Attach images to published products
    foreach ($publishedProducts as $product) {
      $product_images = $this->db->table('product_image')
        ->select('uId, imageUrl')
        ->where('prodId', $product->productId)
        ->get()->getResult();

      $imageList = [];
      foreach ($product_images as $img) {
        $imageList[] = [
          'url' => base_url($img->imageUrl),
          'id' => $img->uId
        ];
      }

      $product->images = $imageList;
      $product->inStock = ($product->stockQty > 0);
    }

    // Saved Products Query
    $savedBuilder = $this->db->table('save_product sp');
    $savedBuilder->select('sp.uId AS productId, sp.name, sp.brandName, sp.title, sp.description, 
                           sp.color, sp.availableSize, sp.idealFor, sp.stockQty, sp.mrpPrice, 
                           sp.sellingPrice, sp.gstPercent, sp.hsnCode, sp.countryOfOrigin, sp.stockQty AS stock, 
                           sp.listingstatus, sp.stock_status, sp.createdAt, sp.manufacturerDetails, 
                           pc.uId AS categoryId, pc.name AS categoryName, 
                           pt.uId AS categoryTypeId, pt.name AS categoryType,
                          '); // Add a marker for product type
    $savedBuilder->join('product_category pc', 'pc.uId = sp.categoryId', 'left');
    $savedBuilder->join('product_type pt', 'pt.uId = sp.typeId', 'left');
    $savedBuilder->where('sp.storeId', $storeId);
    $savedBuilder->where('sp.status', 'PUBLISHED');
    $savedBuilder->orderBy('sp.id', 'DESC');
    $savedBuilder->limit(10, 0);
    $savedProducts = $savedBuilder->get()->getResult();

    // Attach images to saved products
    foreach ($savedProducts as $product) {
      $product_images = $this->db->table('save_product_images')
        ->select('uId, imageUrl')
        ->where('savePid', $product->productId)
        ->get()->getResult();

      $imageList = [];
      foreach ($product_images as $img) {
        $imageList[] = [
          'url' => base_url($img->imageUrl),
          'id' => $img->uId
        ];
      }

      $product->images = $imageList;
      $product->inStock = ($product->stockQty > 0);
    }

    // Combine Published and Saved Products
    $allProducts = array_merge($publishedProducts, $savedProducts);

    // Sort by createdAt date if needed
    usort($allProducts, function ($a, $b) {
      return strtotime($b->createdAt) - strtotime($a->createdAt); // Sort descending by date
    });

    // Result Data
    $resultData['storeName'] = $storeDetails->name;
    $resultData['TotActiveProduct'] = count($publishedProducts);
    $resultData['TotSavedProduct'] = count($savedProducts);
    $resultData['allProducts'] = $allProducts;

    return $resultData;
  }

  public function save_list_show($storeId, $categoryId = null, $typeId = null)
  {
    $resultData = [];

    // Get store details
    $storeDetails = $this->get_store_details($storeId);

    // print_r($storeDetails ) ; die ;


    $builder = $this->db->table('product');
    $builder->select("SUM(IF(listingstatus='ACTIVE', 1, 0)) AS TotActiveProduct, SUM(IF(listingstatus='INACTIVE', 1, 0)) AS TotSavedProduct");
    $builder->where('storeId', $storeId);
    $productSummery = $builder->get()->getRow();

    // print_r($productSummery);die ; 

    $builder = $this->db->table('product p');

    // print_r( $builder) ; 

    $builder = $this->db->table('product p');
    $builder->select('p.uId AS productId, p.name, p.brandName, p.title, p.description, 
                      p.color, p.availableSize, p.idealFor, p.stockQty, p.mrpPrice, 
                      p.sellingPrice, p.stockQty AS stock, p.listingstatus, p.stock_status,
                      pc.name AS categoryName, pt.name AS categoryType');

    $builder->join('product_category pc', 'pc.uId = p.categoryId', 'left');
    $builder->join('product_type pt', 'pt.uId = p.typeId', 'left');
    $builder->where('p.storeId', $storeId);
    $builder->where('status', 'PUBLISHED');
    $builder->whereIn('p.listingstatus', ['ACTIVE', 'INACTIVE']);


    // echo $builder->getCompiledSelect();  
    // die();

    if ($categoryId) {
      $builder->where('p.categoryId', $categoryId);
    }
    if ($typeId) {
      $builder->where('p.typeId', $typeId);
    }

    $builder->orderBy('p.id', 'DESC');
    $builder->limit(10, 0);

    $newlyProductList = $builder->get()->getResult();

    // echo $builder->getCompiledSelect();  
    // die();
    // print_r($newlyProductList) ; die ; 


    foreach ($newlyProductList as $product) {
      $product_image = $this->db->table('product_image')
        ->select('imageUrl')
        ->where('prodId', $product->productId)
        ->get()->getRow();

      $imageList = [];

      if (!empty($product_image)) {
        $product->image = base_url($product_image->imageUrl);
        $imageList[] = base_url($product_image->imageUrl);
      } else {

        $imageList[] = base_url('assets/uploads/product_images/no-image-found.png');
      }

      $product->images = $imageList;
      $product->inStock = ($product->stockQty > 0) ? true : false;
      // $product->live = ($product->listingstatus === 'ACTIVE') ? true : false;
    }


    $resultData['storeName'] = $storeDetails->name;
    $resultData['TotActiveProduct'] = $productSummery->TotActiveProduct;
    $resultData['TotSavedProduct'] = $productSummery->TotSavedProduct;
    $resultData['newProducts'] = $newlyProductList;

    return $resultData;
  }


  public function get_stores_list_by_user_id($userId)
  {
    return $this->db->table("store")->where("userId", $userId)->get()->getResult();
  }

  public function get_store_details($storeId)
  {
    $conditions = [
      'state' => 'ACTIVE',
      'uId' => $storeId,
    ];
    $builder = $this->db->table('store');
    $builder->select(['uId as storeId', 'name', 'panNo', 'address', 'pinCode', 'logoUrl']);
    $builder->where($conditions);
    $query = $builder->get()->getRow();
    return $query;
  }

  //<!------------------------- Store save and draft ..   -------------------->
  public function saved_product_list_storewise($storeId)
  {

    $productTable = 'product';
    $offerTable = 'store_offer';


    $builder = $this->db->table($productTable);
    $builder->select([
      "$productTable.uId as productId",
      "$productTable.name",
      "$productTable.brandName",
      "$productTable.title",
      "$productTable.description",
      "$productTable.color",
      "$productTable.mrpPrice",
      "$productTable.sellingPrice",
      "$productTable.countryOfOrigin",
      "$productTable.manufacturerDetails",
      "$productTable.hsnCode",
      "$offerTable.title as offerTitle",
      "$offerTable.description as offerDescription"
    ]);
    $builder->join($offerTable, "$productTable.storeId = $offerTable.storeId", 'left');
    $builder->where([
      "$productTable.listingstatus" => 'ACTIVE',
      "$productTable.storeId" => $storeId,
    ]);

    $products_list = $builder->get()->getResult();


    foreach ($products_list as $product_details) {
      $product_image = $this->db->table('product_image')
        ->select('imageUrl')
        ->where('prodId', $product_details->productId)
        ->get()->getRow();
      $product_details->image = (!empty($product_image->imageUrl)) ? base_url($product_image->imageUrl) : base_url('assets/uploads/product_images/no-image-found.png');
    }


    return $products_list;
  }

  public function saved_push_notification_storewise($data)
  {
    $inserted = $this->db->table('push_notification')->insert($data);
    return $inserted;
  }

  public function get_push_notifications_list($storeId, $searchText = '', $sortBy = '')
  {
    // Sort options (latest, newest, oldest)
    $sortOptions = [
      'LATEST' => 'DESC',
      'NEWEST' => 'DESC',
      'OLDEST' => 'ASC'
    ];

    // Default to LATEST if no sortBy is provided
    $sortBy = !empty($sortBy) ? $sortBy : 'LATEST';
    $sortDirection = isset($sortOptions[$sortBy]) ? $sortOptions[$sortBy] : 'DESC';

    // Build query for retrieving push notifications
    $push_notifications = $this->db->table('push_notification')
      ->select('uId AS id,
                    notificationTitle AS title,
                    notificationDescription AS description,
                    userType AS type,
                    distanceUnder AS distance,
                    CONCAT("' . base_url() . '", imageUrl) AS image,
                    createdAt AS DateTime')
      ->where([
        'storeId' => $storeId,
        'state !=' => 'DELETED'
      ])
      ->orderBy('createdAt', $sortDirection);


    if (!empty($searchText)) {
      $push_notifications->groupStart()
        ->like('notificationTitle', $searchText)
        ->orLike('notificationDescription', $searchText)
        ->groupEnd();
    }


    $push_notifications_list = $push_notifications->get()->getResult();


    if (!empty($push_notifications_list)) {
      $list_of_push_notifications = [];
      foreach ($push_notifications_list as $details) {
        // Format type
        $details->type = ucwords(strtolower(str_replace('_', ' ', $details->type)));
        $list_of_push_notifications[] = $details;
      }

      $response = [
        'status' => true,
        'message' => 'Push Notifications retrieved successfully.',
        'data' => $list_of_push_notifications
      ];
    } else {
      $response = [
        'status' => false,
        'message' => 'No Push Notifications found!'
      ];
    }

    return $response;
  }



  public function get_push_notification_data($condition)
  {
    return $this->db->table('push_notification')->where($condition)->get()->getRow();
  }

  public function edit_push_notification($data, $condition)
  {
    $builder = $this->db->table('push_notification');
    $builder->set($data);
    $builder->where($condition);
    $updated = $builder->update();

    return $updated;
  }

  public function delete_push_notification($storeId, $notificationId)
  {
    $condition = ['uId' => $notificationId, 'storeId' => $storeId];


    $push_notifications = $this->db->table('push_notification');

    if ($push_notifications->where($condition)->countAll() > 0) {
      $push_notifications->set([
        'state' => 'DELETED',
        'updatedAt' => date('Y-m-d H:i:s')
      ])->where($condition)->update();
      $response = ['status' => true, 'message' => 'Push Notification Deleted.'];
    } else {
      $response = ['status' => false, 'message' => 'Push Notification Not Found!'];
    }

    return $response;
  }

  public function delete_store_offer($storeId, $offerId)
  {
    $condition = ['uId' => $offerId, 'storeId' => $storeId];
    $store_offer = $this->db->table('store_offer');

    if ($store_offer->where($condition)->countAllResults() > 0) {
      $store_offer->where($condition)->delete();

      $response = ['status' => true, 'message' => 'Store Offer Deleted.'];
    } else {
      $response = ['status' => false, 'message' => 'Not Found!!!'];
    }

    return $response;
  }
  public function deactivate_store_offer($OfferIdsList)
  {

    if (!is_array($OfferIdsList) || empty($OfferIdsList)) {
      return false;
    }

    $builder = $this->db->table('store_offer');

    $builder
      ->whereIn('uId', $OfferIdsList)
      ->update(['state' => STORE_OFFER_INACTIVE]);
    return $builder;
  }

  public function activate_store_offer($offerIdsList)
  {

    $sql = $this->db->table('store_offer')
      ->set('state', STORE_OFFER_ACTIVE)
      ->whereIn('uId', $offerIdsList)
      ->update();
    return $sql;
  }

  public function get_user_profile_by_id($userId)
  {

    return $this->db->table('user_accounts')->where('uId', $userId)->get()->getRow();
  }

  public function update_user_profile($data, $userId)
  {
    $builder = $this->db->table('user_accounts');
    $builder->set($data);
    $builder->where('uId', $userId);
    $updated = $builder->update();

    // print_r($updated) ; die ; 

    return $updated;
  }
  public function sellerSignOut($data, $condition)
  {
    // return $this->db->table('user_accounts')->where($condition)->get()->getRow();
    return $this->db->table('user_accounts')->where($condition)->set($data)->update();
  }

  public function delete_product($productId)
  {

    $condition = ['uId' => $productId];
    $product = $this->db->table('product');

    if ($product->where($condition)->countAllResults() > 0) {
      $product->where($condition)->delete();

      $response = ['status' => true, 'message' => 'Store Offer Deleted.'];
    } else {
      $response = ['status' => false, 'message' => 'Not Found!!!'];
    }

    return $response;
  }

  public function update_user_online_status_change($userId, $OnlineStatus)
  {
    $builder = $this->db->table('user_accounts');
    $builder->set('online_status', $OnlineStatus);
    $builder->where('uId', $userId);

    $result = $builder->update();

    return $result;
  }

  public function update_stock_status($stockStatus, $storeId, $productId)
  {

    $builder = $this->db->table('product');
    $builder->set('stock_status', $stockStatus);
    $builder->where('storeId', $storeId);
    $builder->where('uId', $productId);

    $result = $builder->update();

    return $result;
  }

  public function save_new_product_list($data)
  {
    return $this->db->table('save_product')->insert($data);
  }

  public function get_save_product_list($storeId, $categoryId = null, $typeId = null)
  {
    $resultData = [];

    $storeDetails = $this->get_store_details($storeId);

    $builder = $this->db->table('save_product');
    $builder->select("SUM(IF(listingstatus='ACTIVE', 1, 0)) AS TotActiveProduct, SUM(IF(listingstatus='INACTIVE', 1, 0)) AS TotSavedProduct");
    $builder->where('storeId', $storeId);
    $productSummery = $builder->get()->getRow();

    $builder = $this->db->table('save_product sp');



    $builder = $this->db->table('save_product sp');
    $builder->select('sp.uId AS saveId, sp.name, sp.brandName, sp.title, sp.description, 
                        sp.color, sp.availableSize, sp.idealFor, sp.stockQty, sp.mrpPrice, 
                        sp.sellingPrice,sp.gstPercent , sp.hsnCode ,  sp.countryOfOrigin , sp.stockQty AS stock, sp.listingstatus, 
                        sp.stock_status,sp.createdAt,sp.manufacturerDetails , sp.status,
                        pc.uId AS categoryId ,   pc.name AS categoryName, pt.uId AS categoryTypeId ,pt.name AS categoryType,
                        sf.store_offer_id AS offerId , sf.title As offerName , sf.description AS offerDescription');
    $builder->join('store_product_offer sf', 'sf.prodId = sp.uId', 'left');
    $builder->join('product_category pc', 'pc.uId = sp.categoryId', 'left');
    $builder->join('product_type pt', 'pt.uId = sp.typeId', 'left');
    $builder->where('sp.storeId', $storeId);
    $builder->where('status', 'SAVED');
    $builder->whereIn('sp.listingstatus', ['ACTIVE', 'INACTIVE']);
    $builder->orderBy('sp.id', 'DESC');
    $builder->limit(10, 0);
    $newlyProductList = $builder->get()->getResult();

    foreach ($newlyProductList as $product) {
      $product_image = $this->db->table('save_product_images')
        ->select('uId,imageUrl')
        ->where('savePid', $product->saveId)
        ->get()->getResult();
      $imageList = [];
      if (!empty($product_image)) {
        foreach ($product_image as $img) {
          $imageList[] = [
            'url' => base_url($img->imageUrl),
            'id' => $img->uId
          ];
        }
      } else {
      }


      $product->images = $imageList;


      $product->inStock = ($product->stockQty > 0);
    }


    $resultData['storeName'] = $storeDetails->name;
    $resultData['TotActiveProduct'] = $productSummery->TotActiveProduct;
    $resultData['TotSavedProduct'] = $productSummery->TotSavedProduct;
    $resultData['newProducts'] = $newlyProductList;

    return $resultData;
  }

  public function get_product_category_list()
  {

    $sql = "SELECT `uId`,`name` FROM product_category  ";
    $query = $this->db->query($sql);
    $result = $query->getResult();

    return $result;
  }

  public function get_product_type_list()
  {
    $sql = "SELECT `uId` , `name` FROM product_type  WHERE `state` = 'ACTIVE' ";
    $query = $this->db->query($sql);
    $result = $query->getResult();

    return $result;
  }
  public function update_save_stock_status_change($stockStatus, $storeId, $saveId,)
  {

    $builder = $this->db->table('save_product');

    $builder->set('stock_status', $stockStatus);
    $builder->where('storeId', $storeId);
    $builder->where('uId', $saveId);



    $result = $builder->update();

    return $result;
  }

  public function update_save_listingStatus_change($listingstatus, $storeId, $saveId)
  {
    $builder = $this->db->table('save_product');

    $builder->set('listingstatus', $listingstatus);
    $builder->where('storeId', $storeId);
    $builder->where('uId', $saveId);

    $result = $builder->update();

    return $result;
  }

  public function get_product_offer_list()
  {

    $builder = $this->db->table('store_offer')
      ->select('uId, title ,description ,mrpPrice, dicountType , discount , 
                    startDate,startTime,endDate,endTime,minAmount,imageUrl,state')
      ->where('state', 'ACTIVE')
      ->orderBy('id', 'DESC ')
      // ->limit('20')
      ->get();
    $result = $builder->getResult();

    return $result;
  }

  public function get_country()
  {

    $builder = $this->db->table('country')
      ->select('uId , country_name ')
      ->get()
      ->getResult();

    return $builder;
  }
  public function get_gst_list()
  {
    $sql = $this->db->table('gst_list')
      ->select(' gstPercent')
      ->get()
      ->getResult();

    return $sql;
  }
  public function fetch_product_by_uid($productId)
  {

    $condition = ['uId' => $productId];

    $query = $this->db->table('product')->where($condition)->get()->getRow();

    // print_r($query); die; 
    return $query;
  }

  public function update_product($productData, $productId)
  {

    $builder = $this->db->table('product');
    $builder->set($productData);
    $builder->where('uId', $productId);
    $updated = $builder->update();
    // print_r($updated) ; die ; 
    return $updated;
  }
  public function update_product_offer($offerData, $productId)
  {
    $sql = $this->db->table('store_product_offer')->set($offerData)->where('prodId', $productId)->update();
    // print_r($sql) ; die ; 
    return $sql;
  }

  public function get_image_details($productId, $imageId)
  {

    // print_r("Product ID: $productId\n");
    // print_r("Image ID: $imageId\n");

    $builder = $this->db->table('product_image')
      ->select('imageUrl')
      ->where('prodId', $productId)
      ->where('uId', $imageId);
    $query = $builder->get();
    $result = $query->getRow();

    // // Debugging: Print the query result
    // print_r("Query Result: ");
    // print_r($result);

    return $result;
  }


  public function delete_product_image($imageId)
  {
    $sql = $this->db->table('product_image')
      ->where('uId', $imageId)
      ->delete();
    return $sql;
  }

  public function update_store_offers($data, $offerId)
  {
    $update_offers = $this->db->table('store_offer')->set($data)->where('uId', $offerId)->update();
    return $update_offers;
  }

  public function get_all_product_name($storeId)
  {
    $sql = $this->db->table('product')->select('uId , name')->where('storeId', $storeId)->orderBy('createdAt', 'DESC')->get()->getResultArray();
    return $sql;
  }

  public function deleteAll_push_notification($notificationId)
  {
    $sql = $this->db->table('push_notification')
      ->set('state', 'DELETED')
      ->whereIn('uId', $notificationId)
      ->update();
    return $sql;
  }
  public function store_category_list()
  {
    $sql = $this->db->table('store_category')
      ->where('state', STORE_CATEGORY_ACTIVE)
      ->orderBy('createdAt', 'DESC')
      ->get()
      ->getResult();
    return $sql;
  }
  public function save_product_update($data, $saveId)
  {
    $sql = $this->db->table('save_product')->set($data)->where('uId', $saveId)->update();
    return $sql;
  }
  public function save_product_offer_update($saveOffer, $saveId)
  {
    $sql = $this->db->table('store_product_offer')->set($saveOffer)->where('prodId', $saveId)->update();
    return $sql;
  }

  public function delete_product_images_by_ids($imageId)
  {

    $sql = $this->db->table('save_product_images')->whereIn('uid', $imageId)->delete();
    return $sql;
  }
  public function get_image_paths_by_ids($imageIds)
  {

    if (empty($imageIds) || !is_array($imageIds)) {
      return [];
    }
    $query = $this->db->table('save_product_images')
      ->select('imageUrl')
      ->whereIn('uid', $imageIds)
      ->get()
      ->getResult();
    $paths = [];
    if (!empty($query)) {
      foreach ($query as $row) {
        $paths[] = $row->imageUrl;
      }
    }
    return $paths;
  }
  public function save_product_publish($saveId)
  {
    $publish_product = $this->db->table('save_product')->set('status', 'PUBLISHED')->where('uId', $saveId)->update();
    return $publish_product;
  }
  public function get_buyers_with_fcm_tokens()
  {
    $buyer = $this->db->table('user_accounts')
      ->select('uId, name, fcm_token')
      ->where('userType', 'BUYER')
      ->where('fcm_token !=', null)
      ->orderBy('createdAt', 'DESC')
      ->get()->getResult();
    return $buyer;
  }

  public function send_again_push_notification($uId)
  {
    $sql = $this->db->table('push_notification')->select('*')->where('uId', $uId)->get()->getRow();
    return $sql;
  }

  public function get_product_details_for_stock_status_change($condition)
  {
    $sql = $this->db->table('product')->where($condition)->get()->getRow();
    return $sql;
  }
}
