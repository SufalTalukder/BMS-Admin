<?php

namespace App\Models\Seller;

use CodeIgniter\Model;

class ChatFriendModel extends Model
{
    protected $table = 'chat_friend';
    protected $primaryKey = 'id';
    protected $allowedFields = ['chat_id', 'user_id', 'friend_id', 'unread_count', 'created_at', 'last_message_at'];

    public function getChatList($userId)
    {
        return $this->where('user_id', $userId)
            ->orWhere('friend_id', $userId)
            ->findAll();
    }
    public function sendFriendRequest($userId, $friendId)
    {

        $existingRequest = $this->where('userId', $userId)
            ->where('friendId', $friendId)
            ->orWhere('userId', $friendId)
            ->where('friendId', $userId)
            ->first();

        if ($existingRequest) {
            return "Friendship request already exists or is pending.";
        }


        $this->insert([
            'userId' => $userId,
            'friendId' => $friendId,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        $this->insert([
            'userId' => $friendId,
            'friendId' => $userId,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return true;
    }


    public function acceptFriendRequest($userId, $friendId)
    {

        $this->where('userId', $friendId)
            ->where('friendId', $userId)
            ->where('status', 'pending')
            ->set(['status' => 'accepted'])
            ->update();

        $this->where('userId', $userId)
            ->where('friendId', $friendId)
            ->where('status', 'pending')
            ->set(['status' => 'accepted'])
            ->update();

        return true;
    }


    public function rejectFriendRequest($userId, $friendId)
    {
        // Delete the pending request
        $this->where('userId', $friendId)
            ->where('friendId', $userId)
            ->where('status', 'pending')
            ->delete();

        $this->where('userId', $userId)
            ->where('friendId', $friendId)
            ->where('status', 'pending')
            ->delete();

        return true;
    }


    public function areFriends($userId, $friendId)
    {

        return $this->where('userId', $userId)
            ->where('friendId', $friendId)
            ->where('status', 'accepted')
            ->orWhere('userId', $friendId)
            ->where('friendId', $userId)
            ->where('status', 'accepted')
            ->countAllResults() > 0;
    }
}
