<?php

namespace App\Models\Seller;

use CodeIgniter\Model;

class UserAccountModel extends Model
{
    protected $table = 'user_accounts';

    protected $primaryKey = 'id';
    protected $allowedFields = [
        'id',
        'uId',
        'name',
        'mobileNo',
        'email',
        'password',
        'userType',
        'gender',
        'online_status',
        'address',
        'ownReferralCode',
        'referrerReferralCode',
        'profileImageLink',
        'createdAt',
        'updatedAt',
        'state',
        'fcm_token'

    ];
}
