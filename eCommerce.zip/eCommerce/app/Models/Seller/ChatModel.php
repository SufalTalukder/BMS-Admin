<?php

namespace App\Models\Seller;

use CodeIgniter\Model;

class ChatModel extends Model
{
    protected $table            = 'chat';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id', 'uId', 'chat_id', 'sender_user_id', 'receiver_user_id' , 'type', 'content','unread_count' , 'is_read', 'created_at', 'status'];

    public function getMessagesByChatId($chatId)
    {
        $query = $this->db->table('chat')
            ->select('chat_id , sender_user_id , type , content')
            ->where('chat_id',$chatId)
            ->get()
            ->getResult();
        return  $query; 

    }
}
