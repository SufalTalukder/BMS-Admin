<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class UserModel extends model
{

    protected $table = 'user_accounts';

    protected $primaryKey = 'id';
    protected $allowedFields = [
        'id',
        'uId',
        'name',
        'mobileNo',
        'email',
        'password',
        'userType',
        'gender',
        'state',
        'address',

    ];

    public function get_all_user()
    {
        $sql = "SELECT * FROM `user_accounts`";
        $query = $this->db->query($sql);
        return $query->getResult();
    }

    public function get_only_buyer_user()
    {
        $sql = $this->db->table('user_accounts')
            ->select('*')
            ->where('userType', 'BUYER')
            ->whereIn('state', [BUYER_STATUS_ACTIVE, BUYER_STATUS_INACTIVE])
            ->get()
            ->getResult();

        return $sql;
    }

    public function get_buyer_details_by_id($uId)
    {
        return $this->db->table('user_accounts')
            ->where('uId', $uId)
            ->get()
            ->getRowArray();
    }

    public function get_only_seller_user()
    {
        $sql = $this->db->table('user_accounts')
            ->select('*')
            ->where('userType', 'SELLER')
            ->orderBy('createdAt', 'DESC')  // Order by created_at in descending order
            ->get()
            ->getResult();

        return $sql;
    }

    public function get_seller_by_uId($userid)
    {
        $sql = $this->db->table('user_accounts')->select('*')->where('uId', $userid)->get()->getRowArray();
        return $sql;
    }

    public function get_single_seller_store_details($userid)
    {

        $query = $this->db->table('user_accounts as us')
            ->join('store as st', 'us.uId = st.userId', 'LEFT')
            ->select('us.name as userName, st.panNo, st.uId , st.address, st.name as storeName, st.createdAt ,st.gstNo')
            ->where('us.uId', $userid)
            ->get()
            ->getResultArray();
        return $query;
    }

    public function get_single_seller_store_product_details($userid)
    {
        $query = $this->db->table('user_accounts as us')
            ->join('store as s', 'us.uId = s.userId', 'LEFT')
            ->join('product as pd', 's.uId = pd.storeId', 'LEFT')
            ->select('pd.uId,pd.name, pd.brandName, pd.mrpPrice, pd.listingstatus ,pd.stockQty ,pd.sellingPrice ,pd.idealFor ,pd.gstPercent ,pd.createdAt')
            ->where('us.uId', $userid)
            ->orderBy('pd.createdAt', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();
        return $query;
    }

    public function get_product_details_by_uid($prodId)
    {

        $query = $this->db->table('product as P')
            ->join('product_category as PC', 'P.categoryId = PC.uId', 'LEFT')
            ->join('product_type as PT', 'P.typeId = PT.uId', 'LEFT')
            ->join('product_image as PI', 'P.uId = PI.prodId', 'LEFT')
            ->select('P.*, PC.name AS CategoryName, PC.imageUrl AS CategoryImage,
                                      PT.name AS typeName, PT.imageUrl AS TypeImage , PI.imageUrl')
            ->where('P.uId', $prodId)
            ->get()
            ->getRowArray();

        return $query;
    }

    public function get_store_details_by_uid($storeid)
    {

        $sql = $this->db->table('store as ST')
            ->join('store_category as SC', 'ST.storeCatId = SC.uId', 'LEFT')
            ->join('store_offer as SF', 'ST.uId = SF.storeId', 'LEFT')
            ->join('state as SE', 'ST.stateId = SE.uId ', 'LEFT')
            ->join('city as C', 'SE.uId = C.stateId ', 'LEFT')
            ->select('ST.* , SC.categoryName , SC.createdAt as catecreatedAt, SC.updatedAt as cateUpdateAt , 
                        SC.state as cateState , 
                        SF.title,
                        SF.applicableOnProduct,
                        SF.description,
                        SF.mrpPrice,
                        SF.dicountType,
                        SF.discount,
                        SF.startDate,
                        SF.startTime,
                        SF.endDate,
                        SF.minAmount,
                        SF.imageUrl,
                        SF.state as offerState,
                        SE.name as StateName,
                        C.name as CityName 
                        ')
            ->where('ST.uId', $storeid)
            ->get()
            ->getRowArray();

        return $sql;
    }
    public function delete_buyer_by_uId($uId)
    {
        $sql = $this->db->table('user_accounts')->set('state', BUYER_STATUS_DELETED)->where('uId', $uId)->update();
        return $sql;
    }
    public function  delete_seller_by_uId($uId)
    {
        $sql = $this->db->table('user_accounts')->set('state', SELLER_STATUS_DELETED)->where('uId', $uId)->update();
        return $sql;
    }
}
