<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class ProductModel extends model
{

    protected $table = 'product';

    protected $primaryKey = 'id';

    protected $allowedFields = [
        'id',
        'uId',
        'storeId',
        'categoryId',
        'typeId',
        'name',
        'brandName',
        'listingstatus',
        'title',
        'description',
        'color',
        'availableSize',
        'idealFor',
        'mrpPrice',
        'sellingPrice',
        'stockQty',
        'stock_status',
        'countryOfOrigin',
        'manufacturerDetails',
        'hsnCode',
        'gstPercent',
        'createdAt',
        'updatedAt',
    ];


    public function get_all_product_list()
    {
        $sql = "SELECT * FROM `product`";
        $query = $this->db->query($sql);
        return $query->getResult();
        die;
    }

    public function get_product_type_list()
    {
        $sql = $this->db->table('product_type PT')
            ->select('PT.* , PC.name AS categoryName')
            ->join('product_category PC ', 'PC.uId = PT.categoryId', 'LEFT')
            ->orderBy('createdAt', 'desc')
            ->orderBy('state', STATE_ENUM_ACTIVE)
            ->get()
            ->getResult();
        return $sql;
    }
    public function get_product_category_list()
    {
        $sql  = $this->db->table('product_category')->select('*')->orderBy('createdAt', 'desc')->get()->getResult();
        return $sql;
    }
    public function get_product_category_by_uid($uId)
    {

        $sql = $this->db->table('product_category')->select('*')->where('uId', $uId)->get()->getRow();
        return $sql;
    }


    // This function using bulk excel sheet insert store product offer // 

    public function add_store_offer_By_addProduct($OfferProductData)
    {
        $inserted =  $this->db->table('store_product_offer')->insert($OfferProductData);
        return $inserted;
    }
    public function saveProduct($productData)
    {
        return $this->insert($productData);
    }

    public function addCategory($data)
    {
        $sql = $this->db->table('product_category')->set($data)->insert();
        return $sql;
    }

    public function addProductType($data)
    {
        $sql = $this->db->table('product_type')->set($data)->insert();
        return $sql;
    }

    public function get_product_category()
    {
        $sql = $this->db->table('product_category')
            ->select('uId,name')
            ->where('state', PRODUCT_CATEGORY_STATE__ACTIVE)
            ->orderBy('createdAt', 'DESC')
            ->get();
        return $sql->getResult();
    }


    public function getProducts() // For Admin Panel Product Bulk list View Table 
    {
        $sql = $this->db->table('product')
            ->select('*')
            ->orderBy('createdAt', 'DESC')
            ->limit(10, 0)
            ->get()
            ->getResultArray();

        return $sql;
    }

    public function get_product_type_by_uid($uId)
    {
        $sql = $this->db->table('product_type')->select('*')->where('uId', $uId)->get()->getRow();
        return $sql;
    }
    public function update_product_type($uId, $data)
    {
        $productUpdate = $this->db->table('product_type')->set($data)->where('uId', $uId)->update();
        return $productUpdate;
    }
    public function delete_product_type($uId)
    {
        $deleteProductType = $this->db->table('product_type')->set('state', PRODUCT_TYPE_STATE_DELETED)->where('uId', $uId)->update();
        return $deleteProductType;
    }
    public function update_product_category($data, $uId)
    {
        $sql = $this->db->table('product_category')->set($data)->where('uId', $uId)->update();
        return $sql;
    }
    public function delete_product_category($uId)
    {
        $sql = $this->db->table('product_category')->set('state', PRODUCT_CATEGORY_STATE__DELETED)->where('uId', $uId)->update();
        return $sql;
    }

    public function get_product_details()
    {


        $product = $this->db->table('product AS P')
            ->select('P.* , ST.name AS StoreName  , PC.name AS categoryName , PT.name AS typeName')
            ->join('store AS ST ',  'ST.uId = P.storeId', 'LEFT')
            ->join('product_category AS PC ', 'PC.uId = P.categoryId', 'LEFT')
            ->join('product_type AS PT ', 'PT.uId = P.typeId', 'LEFT')
            ->orderBy('createdAt', 'DESC')
            ->get()
            ->getResult();
        return $product;
    }
    public function update_product_status($prodUid, $status)
    {

        return $this->db->table('product')
            ->set('listingstatus', $status)
            ->where('uId', $prodUid)
            ->update();
    }
    public function get_product_details_with_images($uId)
    {

        $product = $this->db->table('product')->select('*')->where('uId', $uId)->get()->getRow();
        $images = $this->db->table('product_image')->select('imageUrl')->where('prodId', $uId)->get()->getResult();
        $arr = ['product' => $product, 'images' => $images];
        return $arr;
    }


    public function product_delete($uId)
    {
        $deleteProduct = $this->db->table('product')->where('uId', $uId)->delete();
        return $deleteProduct;
    }
}
