<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class StoreModel extends model
{

    protected $table = 'store_category';

    protected $primaryKey = 'id';
    protected $allowedFields = [
        'id',
        'uId',
        'name',
        'imageUrl',
        'createdAt',
        'updatedAt',
        'state'

    ];

    public function get_all_store_category()
    {
        $sql = $this->db->table('store_category')->select('*')->get()->getResult();
        return $sql;
    }

    public function add_store_category($data)
    {
        $query = $this->db->table('store_category')->insert($data);
        return $query;
    }
    public function get_category_by_uid($uId)
    {
        $query = $this->db->table('store_category')->where('uId', $uId)->get()->getResultArray();
        return $query;
    }

    public function update_category($uId, $data)
    {
        $sql = $this->db->table('store_category')->where('uId', $uId)->set($data)->update();
        return $sql;
    }
    public function delete_category($cateId)
    {

        $sql = $this->db->table('store_category')->set([
            'state' => 'DELETED'
        ])->where('uId', $cateId)->update();
        return $sql;
    }

    public function get_store()
    {
        $sql = $this->db->table('store as ST')
            ->select('ST.*, UA.name as userName')
            ->join('user_accounts as UA', 'UA.uId = ST.userId', 'left')
            ->orderBy('ST.createdAt', 'DESC')
            ->get();
        return $sql->getResult();
    }
    public function get_store_detail_by_uid($storeId)
    {

        $store = $this->db->table('store AS ST')
            ->select('ST.*, ST.name AS storeName ,ST.address AS storeAddress ,ST.state AS storeState , 
                     SC.categoryName, SC.state AS categoryStatus, UA.* , 
                     city.name AS cityName , state.name AS stateName')
            ->join('user_accounts AS UA', 'UA.uId = ST.userId', 'LEFT')
            ->join('store_category AS SC', 'SC.uId = ST.storeCatId', 'LEFT')
            ->join('state', 'state.uId = ST.stateId', 'LEFT')
            ->join('city', 'city.uId = ST.cityId')
            ->where('ST.uId', $storeId)
            ->get()
            ->getRow();

        $offers = $this->db->table('store_offer AS SF')
            ->select('SF.*')
            ->where('SF.storeId', $storeId)
            ->orderBy('startDate', 'DESC')
            ->limit(10)
            ->get()
            ->getResult();
        if ($store) {
            $store->offers = $offers;
        }
        return $store;
    }
    public  function get_store_payment_details()
    {
        $storePayment = $this->db->table('store_payment AS SP')
            ->select('SP.* , ST.name AS storeName , U.name AS userName')
            ->join('store AS ST', 'ST.uId = SP.storeId', 'LEFT')
            ->join('user_accounts AS U', 'U.uId = SP.userId', 'LEFT')
            ->orderBy('createdAt', 'DESC')
            ->get()
            ->getResult();
        return $storePayment;
    }
    public function get_referral_requests_details()
    {

        $sql = $this->db->table('referral_requests AS RR')
            ->select('RR.* , UA.name AS referrerName , U.name AS referredName')
            ->join('user_accounts AS UA', 'UA.uId = RR.referrerUserId')
            ->join('user_accounts AS U ', 'U.uId = RR.referredUserId')
            ->get()
            ->getResult();
        return $sql;
    }
    public function delete_store_by_uId($uId)
    {
        $sql = $this->db->table('store')->set('state', STORE_DELETED)->where('uId', $uId)->update();
        return $sql;
    }

    public function get_store_offer_detail()
    {
        $getStoreOffer = $this->db->table('store_offer AS SF')
            ->select('SF.*, S.name AS StoreName')
            ->join('store AS S', 'SF.storeId = S.uId', 'LEFT')
            ->get()
            ->getResult();


        $finalOffers = [];
        if (!empty($getStoreOffer)) {
            foreach ($getStoreOffer as $offer) {

                $productIds = explode(',', $offer->applicableOnProduct);
                $productNames = $this->db->table('product')
                    ->select('name AS ProductName , uId AS productId')
                    ->whereIn('uId', $productIds)
                    ->get()
                    ->getResult();

                $finalOffers[] = [
                    'id' => $offer->id,
                    'uId' => $offer->uId,
                    'storeId' => $offer->storeId,
                    'title' => $offer->title,
                    'description' => $offer->description,
                    'mrpPrice' => $offer->mrpPrice,
                    'discountType' => $offer->dicountType,
                    'discount' => $offer->discount,
                    'startDate' => $offer->startDate,
                    'startTime' => $offer->startTime,
                    'endDate' => $offer->endDate,
                    'endTime' => $offer->endTime,
                    'minAmount' => $offer->minAmount,
                    'imageUrl' => $offer->imageUrl,
                    'state' => $offer->state,
                    'StoreName' => $offer->StoreName,
                    'product' => $productNames,
                ];
            }
        }

        return $finalOffers;
    }

    public function store_offer_delete($uId)
    {
        $deleteOffer = $this->db->table('store_offer')->set('state', STORE_OFFER_DELETED)->where('uId', $uId)->update();
        return $deleteOffer;
    }
}
