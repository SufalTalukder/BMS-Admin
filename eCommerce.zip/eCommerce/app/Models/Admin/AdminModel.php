<?php 

namespace App\Models\Admin;

use CodeIgniter\Model;

class AdminModel extends model {

    protected $table = 'admin';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'email',
        'password',
       
    ];

}