<?php

namespace App\Models\Buyer;

use CodeIgniter\Model;

class BuyerModel extends Model
{

  public function get_user_account_data($condition)
  {
    return $this->db->table('user_accounts')->where($condition)->get()->getRow();
  }
  public function save_user($data)
  {
    $inserted =  $this->db->table('user_accounts')->insert($data);
    //  return $this->db->insert('user_accounts', $data);
    return $inserted;
  }

  public function get_user_data_by_email_mobile($emailMobile)
  {
    $sql = "select id , uId, email,password,mobileNo,userType,state  from `user_accounts` where 
      (`email`='" . $emailMobile . "' and `email`!='') or (`mobileNo`='" . $emailMobile . "' and `mobileNo`!='') ";
    $query = $this->db->query($sql)->getRow();;
    return $query;
  }

  public function save_otp($data)
  {
    $inserted =  $this->db->table('otp_list')->insert($data);
    //  return $this->db->insert('user_accounts', $data);
    return $inserted;
  }

  public function get_otp_data($otp)
  {
    $sql = "select *   from `otp_list` where  `otp`='" . $otp . "' and `isVerify`='I' order by id desc limit 0,1  ";
    $query = $this->db->query($sql)->getRow();
    return $query;
  }

  public function update_otp_data($otp)
  {
    $sql = "update `otp_list` set `isVerify`='V'  where  `otp`='" . $otp . "' and `isVerify`='I'    ";
    $query = $this->db->query($sql);
    return $query;
  }

  public function get_user_data_by_uId($uId)
  {
    $sql = "select id , uId,name, email,password,mobileNo,userType,state  from `user_accounts` where `uId`='" . $uId . "'   ";
    $query = $this->db->query($sql)->getRow();
    return $query;
  }

  public function get_user_data_by_store_id($store_id)
  {
    $SQL = "SELECT U.* 
              FROM user_accounts AS U 
              INNER JOIN store AS S
                         ON S.userId = U.uId
              WHERE S.state = 'ACTIVE'
                    AND S.uId = '$store_id';";
    $user_data = $this->db->query($SQL)->getRow();
    return $user_data;
  }

  public function add_new_referral_request($data)
  {
    return $this->db->table('referral_requests')->insert($data);
  }

  public function get_referral_request_details($condition)
  {
    return $this->db->table('referral_requests')
      ->where($condition)
      ->orderBy('createdAt', 'DESC')
      ->get()->getRow();
  }

  public function update_referral_request_data($data, $condition)
  {
    return $this->db->table('referral_requests')
      ->set($data)
      ->where($condition)
      ->update();
  }

  public function save_password($password, $userId)
  {
    $sql = "update `user_accounts` set   `password`='" . $password . "'  where `uId`='" . $userId . "'    ";
    $query = $this->db->query($sql);
    return $query;
  }


  public function get_category_list()
  {
    $builder = $this->db->table('product_category');
    $base_url = base_url();
    $builder->select(['uId as categoryId', 'name', "CONCAT('$base_url' , imageUrl) AS image", 'state']);
    $builder->where('state', STATE_ENUM_ACTIVE);
    $query = $builder->get();
    return $query->getResult();
  }
  public function get_store_list($store_detail = null, $user_id = null)
  {

    $base_url = base_url();
    $builder = $this->db->table('store AS ST');
    if ($user_id === null) {
      throw new Exception("User ID is required");
    }
    $builder->select([
      'ST.uId AS storeId',
      'ST.name',
      'ST.panNo',
      'ST.address',
      'ST.pinCode',
      'UA.mobileNo AS userMobile',
      'SC.categoryName AS categoryName',
      "CONCAT(
        ROUND(
            6371 * ACOS(
                COS(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                COS(RADIANS(CAST(ST.latitude AS DECIMAL(10, 8)))) *
                COS(RADIANS(CAST(UA.longitude AS DECIMAL(10, 8))) - RADIANS(CAST(ST.longitude AS DECIMAL(10, 8)))) + 
                SIN(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                SIN(RADIANS(CAST(ST.latitude AS DECIMAL(10, 8))))
            ), 2
        ), ' KM' 
    ) AS distance",
      "CONCAT('$base_url', logoUrl) AS storeLogo",
    ]);

    $builder->join('user_accounts AS UA', 'UA.uId = ' . $this->db->escape($user_id), 'LEFT');
    $builder->join('store_category AS SC', 'SC.uId = ST.storeCatId', 'LEFT');
    $builder->where('ST.state', STORE_ACTIVE);
    $builder->orderBy('distance', 'ASC');
    if (!empty($store_detail)) {
      $builder->groupStart()
        ->like('ST.name', $store_detail, 'both')
        ->orLike('ST.address', $store_detail, 'both')
        ->groupEnd();
    }
    $query = $builder->get();
    return $query->getResult();
  }

  public function get_store_details($storeId, $userId)
  {
    $base_url = base_url();

    $conditions = [
      'S.state' => STORE_ACTIVE,
      'S.uId' => $storeId,
    ];


    $store = $this->db->table('store AS S')
      ->select("S.uId, S.userId,  S.name AS storeName ,  S.description, S.address, 
                UA.mobileNo AS mobileNumber , SC.categoryName AS categoryName ,       CONCAT(
        ROUND(
            6371 * ACOS(
                COS(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                COS(RADIANS(CAST(S.latitude AS DECIMAL(10, 8)))) *
                COS(RADIANS(CAST(UA.longitude AS DECIMAL(10, 8))) - RADIANS(CAST(S.longitude AS DECIMAL(10, 8)))) + 
                SIN(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                SIN(RADIANS(CAST(S.latitude AS DECIMAL(10, 8))))
            ), 2
        ), ' KM' 
    ) AS distance , CONCAT( '$base_url'  , logoUrl) AS StoreLogo ")

      ->join('user_accounts AS UA', 'UA.uId =' . $this->db->escape($userId), 'LEFT')

      ->join('store_category AS SC', 'SC.uId = S.storeCatId', 'LEFT')
      ->where($conditions)
      ->get()
      ->getRow();

    if ($store) {

      $store->totalProducts = $this->db->table('product')
        ->where([
          'storeId' => $store->uId,
          'listingstatus' => STATE_ENUM_ACTIVE,
          'stock_status' => 'ON'
        ])

        ->countAllResults();


      $storeImagesRaw = $this->db->table('store_image')
        ->select('imageUrl')
        ->where('storeId', $store->uId)
        ->orderBy('createdAt', 'ASC')
        ->limit(4)
        ->get()
        ->getResultArray();

      $store->storeImages = array_map(function ($image) use ($base_url) {
        return $base_url . $image['imageUrl'];
      }, $storeImagesRaw);

      $store->storeOffers = $this->db->table('store_offer')
        ->select("title, 
          description, 
          dicountType,  
           CASE 
              WHEN dicountType = 'FLAT' THEN CONCAT('₹', ROUND(CAST(discount AS DECIMAL(10,2)), 0))
              WHEN dicountType = 'PERCENTAGE' THEN CONCAT(ROUND(CAST(discount AS DECIMAL(10,2)), 0), '% off')
              ELSE ROUND(CAST(discount AS DECIMAL(10,2)), 0)
          END AS discount, 
          endDate AS validTill, 
          CONCAT('$base_url', imageUrl) AS imageUrl")

        ->where('storeId', $store->uId)
        ->get()
        ->getResult();
      $store->allProducts = $this->db->table('product AS P')
        ->select("P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, 
                        P.color, CONCAT('₹' ,P.mrpPrice) AS mrpPrice ,  CONCAT('₹' ,P.sellingPrice) AS sellingPrice, P.isSaved AS FavoritesList, 
                        P.stock_status AS StockStatus, PT.name AS typename")
        ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
        ->where('P.storeId', $store->uId)
        ->orderBy('P.createdAt', 'DESC')
        ->limit(5)
        ->get()
        ->getResult();

      foreach ($store->allProducts as &$product) {
        $productImagesRaw = $this->db->table('product_image')
          ->select('imageUrl')
          ->where('prodId', $product->productId)
          ->get()
          ->getResultArray();

        $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
        $product->StockStatus = $product->StockStatus === "ON" ? true : false;
        $product->images = array_map(function ($image) use ($base_url) {
          return $base_url . $image['imageUrl'];
        }, $productImagesRaw);
      }


      $store->popularProducts = $this->db->table('product AS P')
        ->select("P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, 
                  P.color, CONCAT('₹' ,P.mrpPrice) AS mrpPrice ,  CONCAT('₹' ,P.sellingPrice) AS sellingPrice, P.isSaved AS FavoritesList, 
                  P.stock_status AS StockStatus, PT.name AS typename")
        ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
        ->where('P.storeId', $store->uId)
        ->orderBy('P.createdAt', 'DESC')
        ->limit(5)
        ->get()
        ->getResult();

      foreach ($store->popularProducts as &$product) {
        $productImagesRaw = $this->db->table('product_image')
          ->select('imageUrl')
          ->where('prodId', $product->productId)
          ->get()
          ->getResultArray();

        $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
        $product->StockStatus = $product->StockStatus == "ON" ? true : false;
        $product->images = array_map(function ($image) use ($base_url) {
          return $base_url . $image['imageUrl'];
        }, $productImagesRaw);
      }
    }

    return  $store;
  }


  public function get_product_list_storewise($storeId)
  {
    $conditions = [
      'listingstatus' => 'ACTIVE',
      'storeId' => $storeId,
    ];
    $builder = $this->db->table('product');
    $builder->select(['uId as productId', 'storeId', 'name', 'brandName', 'title', 'description', 'color', 'mrpPrice', 'sellingPrice']);
    $builder->where($conditions);
    $query = $builder->get()->getResult();
    return $query;
  }

  public function get_store_offer($storeId)
  {
    $conditions = [
      'state' => 'ACTIVE',
      'storeId' => $storeId,
    ];
    $base_url = base_url();
    $builder = $this->db->table('store_offer');
    $builder->select([
      'endDate as validTill',
      'storeId',
      'description',
      'title',
      " CASE 
        WHEN dicountType = 'FLAT' THEN CONCAT('₹', ROUND(CAST(discount AS DECIMAL(10,2)), 0) , ' off')
        WHEN dicountType = 'PERCENTAGE' THEN CONCAT(ROUND(CAST(discount AS DECIMAL(10,2)), 0), ' % off')
        ELSE ROUND(CAST(discount AS DECIMAL(10,2)), 0)
    END AS discount",
      "CONCAT( '$base_url'  ,imageUrl) AS OfferImage "
    ]);
    $builder->where($conditions);
    $query = $builder->get()->getResult();
    return $query;
  }


  public function get_product_details($productId, $userId)
  {

    $base_url = base_url();
    $conditions = [
      'listingstatus' => STATE_ENUM_ACTIVE,
      'uId' => $productId,
    ];
    $builder = $this->db->table('product');
    $builder->select([
      'uId as productId',
      'storeId',
      'name',
      'brandName',
      'title',
      'description',
      'color',
      'isSaved AS favoritesList',
      "CONCAT('₹', FORMAT(mrpPrice, 2)) AS mrpPrice",
      "CONCAT('₹', FORMAT(sellingPrice, 2)) AS sellingPrice",
    ]);

    $builder->where($conditions);
    $query = $builder->get()->getRow();
    if ($query) {
      $query->favoritesList = $query->favoritesList == 1 ? true : false;
      $store = $this->db->table('store AS S') // Alias added
        ->select("
                  S.name AS storeName, 
                  S.userId, 
                  UA1.mobileNo AS UserMobileNo, 
                  CONCAT(
                      ROUND(
                          6371 * ACOS(
                              COS(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                              COS(RADIANS(CAST(S.latitude AS DECIMAL(10, 8)))) *
                              COS(RADIANS(CAST(UA.longitude AS DECIMAL(10, 8))) - RADIANS(CAST(S.longitude AS DECIMAL(10, 8)))) + 
                              SIN(RADIANS(CAST(UA.latitude AS DECIMAL(10, 8)))) * 
                              SIN(RADIANS(CAST(S.latitude AS DECIMAL(10, 8))))
                          ), 2
                      ), ' KM'
                  ) AS distance,
                  CONCAT('$base_url', S.logoUrl) AS storeLogo
                  ")
        ->join('user_accounts AS UA', 'UA.uId = ' . $this->db->escape($userId), 'LEFT') // Fixing undefined variable
        ->join('user_accounts AS UA1', 'UA1.uId = S.userId', 'LEFT')
        ->where('S.uId', $query->storeId)
        ->get()
        ->getRow();
      $query->storeName = $store ? $store->storeName : null;
      $query->sellerUserId = $store ? $store->userId : null;
      $query->UserMobileNo = $store ? $store->UserMobileNo : null;
      $query->distance = $store ? $store->distance : null;
      $query->StoreImage = $store ? $store->storeLogo : null;
      $offers = $this->db->table('store_offer')
        ->select("
                  dicountType,
                  CASE 
                      WHEN dicountType = 'FLAT' THEN CONCAT('₹', ROUND(CAST(discount AS DECIMAL(10,2)), 0) , ' off')
                      WHEN dicountType = 'PERCENTAGE' THEN CONCAT(ROUND(CAST(discount AS DECIMAL(10,2)), 0), ' % off')
                      ELSE ROUND(CAST(discount AS DECIMAL(10,2)), 0)
                  END AS discount
              ")
        ->where('storeId', $query->storeId)
        ->where("FIND_IN_SET('{$query->productId}', applicableOnProduct) >", 0)
        ->get()
        ->getResult();
      $query->storeOffer = $offers;
      $images = $this->db->table('product_image')
        ->select("CONCAT('$base_url', imageUrl) AS imageUrl")
        ->where('prodId', $query->productId)
        ->get()
        ->getResult();
      $query->images = array_column($images, 'imageUrl');
    }
    return $query;
  }



  public function get_product_images($prodId)
  {
    $conditions = [
      'state' => 'ACTIVE',
      'prodId' => $prodId,
    ];
    $builder = $this->db->table('product_image');
    $builder->select(['imageUrl as prodImageUrl']);
    $builder->where($conditions);
    $query = $builder->get()->getResult();
    return $query;
  }


  public function get_user_details($userId)
  {
    $conditions = [
      'state' => 'ACTIVE',
      'uId' => $userId,
    ];
    $builder = $this->db->table('user_accounts');
    $base_url = base_url();
    $builder->select([
      'uId as userId',
      'name',
      'mobileNo',
      'email',
      'address',
      "CONCAT('$base_url', profileImageLink) AS profileImage",
      'latitude',
      'longitude'
    ]);
    $builder->where($conditions);
    $query = $builder->get()->getRow();
    return $query;
  }

  public function save_pay_amount($data)
  {
    $inserted =  $this->db->table('store_payment')->insert($data);
    //  return $this->db->insert('user_accounts', $data);
    return $inserted;
  }

  public function get_recent_transactions($userId)
  {
    $base_url = base_url();
    $sql = "select p.uId as paymentId, p.storeId,p.finalAmount, DATE(p.createdAt) as payDate, TIME(p.createdAt) as payTime,
      s.name as storeName, CONCAt('$base_url' , s.logoUrl) AS StoreLogo    from `store_payment` as p
      left join store as s on p.storeId=s.uId
      where p.userId='" . $userId . "' and p.state='ACTIVE'  order by p.id desc limit 0,10  ";
    $query = $this->db->query($sql)->getResult();
    return $query;
  }

  public function search_product($keyword)
  {
    $sql = "SELECT 
            p.uId AS productId, 
            p.storeId, 
            p.name, 
            p.brandName, 
            p.title, 
            p.description, 
            p.color, 
            p.mrpPrice, 
            p.sellingPrice, 
            p.isSaved AS FavoritesList,
            (
                SELECT pt.name 
                FROM product_type pt 
                WHERE pt.uId = p.typeId 
                LIMIT 1
            ) AS typeName,
            (
                SELECT sf.discount 
                FROM store_offer sf 
                WHERE sf.storeId = p.storeId 
                ORDER BY sf.discount DESC 
                LIMIT 1
            ) AS productDiscount
        FROM `product` AS p
        WHERE 
            (
                p.name LIKE '%" . $this->db->escapeLikeString($keyword) . "%' 
                OR p.brandName LIKE '%" . $this->db->escapeLikeString($keyword) . "%' 
                OR p.title LIKE '%" . $this->db->escapeLikeString($keyword) . "%' 
                OR p.description LIKE '%" . $this->db->escapeLikeString($keyword) . "%' 
                OR p.color LIKE '%" . $this->db->escapeLikeString($keyword) . "%'
                OR p.mrpPrice LIKE '%" . $this->db->escapeLikeString($keyword) . "%'
                OR EXISTS (
                    SELECT 1 
                    FROM product_type pt 
                    WHERE pt.uId = p.typeId 
                    AND pt.name LIKE '%" . $this->db->escapeLikeString($keyword) . "%'
                )
                OR EXISTS (
                    SELECT 1 
                    FROM store_offer sf 
                    WHERE sf.storeId = p.storeId 
                    AND sf.discount LIKE '%" . $this->db->escapeLikeString($keyword) . "%'
                )
            )
            AND p.listingstatus = 'ACTIVE'";
    $query = $this->db->query($sql)->getResult();
    foreach ($query as &$product) {
      $product->FavoritesList = $product->FavoritesList == "1" ? true : false;
    }
    return $query;
  }

  public function edit_profile($data, $userId)
  {
    $updateBuyer = $this->db->table('user_accounts')->set($data)->where('uId', $userId)->update();
    return $updateBuyer;
  }
  public function get_recommended_product_list()
  {

    $products = $this->db->table('product AS P')
      ->select("P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, P.color, 
                   CONCAT('₹' ,P.mrpPrice ) AS mrpPrice, COnCAT('₹' , P.sellingPrice) AS sellingPrice, P.isSaved AS FavoritesList , PT.name AS TypeName, 
                ")
      ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
      ->where('P.listingstatus', STATE_ENUM_ACTIVE)
      ->orderBy('P.createdAt', 'DESC')
      ->limit(10, 0)
      ->get()
      ->getResult();

    foreach ($products as &$product) {
      $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
    }
    return $products;
  }

  public function deals_of_the_day()
  {
    $products = $this->db->table('product AS P')
      ->select("P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, P.color, 
             CONCAT('₹' ,P.mrpPrice ) AS mrpPrice, COnCAT('₹' , P.sellingPrice) AS sellingPrice, P.isSaved AS FavoritesList , PT.name AS TypeName, 
            ")
      ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
      ->where('P.listingstatus', STATE_ENUM_ACTIVE)
      ->orderBy('P.createdAt', 'DESC')
      ->limit(1)
      ->get()
      ->getResult();
    foreach ($products as &$product) {
      $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
    }
    return $products;
  }



  public function insert_banner($data)
  {
    $insertQuery = $this->db->table('buyer_app_banner')->insert($data);
    return $insertQuery;
  }
  public function Banner_list()
  {
    $base_url = base_url();
    $selectQuery = $this->db
      ->table('store_offer')
      ->select("uId, CONCAT('$base_url' , imageUrl) AS imagePath")
      ->orderBy('startDate', 'DESC')
      ->get()
      ->getResult();
    return $selectQuery;
  }
  public function add_product_favorites_list($data)
  {
    $insertQuery = $this->db->table('favorites_product')->insert($data);
    return $insertQuery;
  }
  public function get_favorites_product_by_user_id($userId)
  {
    $base_url = base_url();
    $query = $this->db->table('favorites_product AS FP')
      ->select("
            FP.uId AS favoritesId,
            FP.productId AS productId,
            FP.storeId AS storeId,
            P.name AS ProductName,
            P.brandName,
            P.title,
            P.description,
            P.color,
            CONCAT('₹' ,P.mrpPrice) AS mrpPrice,
            cONCAT('₹' ,P.sellingPrice) AS sellingPrice,
            PI.prodId AS imageProdId,
            PT.name AS TypeName , 
            CONCAT('$base_url', PI.imageUrl) AS productImage
        ")
      ->join('product AS P', 'P.uId = FP.productId', 'LEFT')
      ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
      ->join('product_image AS PI', 'PI.prodId = P.uId', 'LEFT')
      ->where('FP.userId', $userId)
      ->orderBy('FP.created_at', 'DESC')
      ->orderBy('PI.createdAt', 'DESC')
      ->get()
      ->getResultArray();
    $products = [];
    foreach ($query as $row) {
      $favoritesId = $row['favoritesId'];
      if (!isset($products[$favoritesId])) {
        $products[$favoritesId] = [
          'productId'     => $row['productId'],
          'storeId'       => $row['storeId'],
          'ProductName'   => $row['ProductName'],
          'TypeName' => $row['TypeName'],
          'brandName'     => $row['brandName'],
          'title'         => $row['title'],
          'description'   => $row['description'],
          'color'         => $row['color'],
          'mrpPrice'      => $row['mrpPrice'],
          'sellingPrice'  => $row['sellingPrice'],
          'productImages' => [],
        ];
      }
      if (!empty($row['productImage'])) {
        $products[$favoritesId]['productImages'][] = $row['productImage'];
      }
    }
    $products = array_values($products);
    return $products;
  }
  public function remove_product_favorites_list($conditions)
  {
    try {
      $deleteQuery = $this->db->table('favorites_product')->where($conditions)->delete();
      // print_r('Last Query: ' . $this->db->getLastQuery());
      return $deleteQuery;
    } catch (\Exception $e) {
      // print_r('Error: ' . $e->getMessage());
      return false;
    }
  }
  public function popular_product()
  {
    $products = $this->db->table('product AS P')
      ->select('P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, P.color, 
                   P.mrpPrice, P.sellingPrice, P.isSaved AS FavoritesList , PT.name AS TypeName, 
                ')
      ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
      ->where('P.listingstatus', STATE_ENUM_ACTIVE)
      ->orderBy('P.createdAt', 'ASC')
      ->limit(10, 0)
      ->get()
      ->getResult();

    foreach ($products as &$product) {
      $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
    }
    return $products;
  }
  public function product_filter() {}

  public function get_favorite_by_product_user($userId, $productId)
  {
    return $this->db->table('favorites_product')
      ->where('userId', $userId)
      ->where('productId', $productId)
      ->get()
      ->getRowArray();
  }

  public function similar_product()
  {
    $products = $this->db->table('product AS P')
      ->select("P.uId AS productId, P.storeId, P.name, P.brandName, P.title, P.description, P.color, 
                 CONCAT('₹' , P.mrpPrice)AS mrpPrice, CONCAT( '₹'  ,  P.sellingPrice )sellingPrice, P.isSaved AS FavoritesList , PT.name AS TypeName, 
              ")
      ->join('product_type AS PT', 'PT.uId = P.typeId', 'LEFT')
      ->where('P.listingstatus', STATE_ENUM_ACTIVE)
      ->orderBy('P.createdAt', 'ASC')
      ->limit(10, 0)
      ->get()
      ->getResult();

    foreach ($products as $product) {
      $product->FavoritesList = $product->FavoritesList == 1 ? true : false;
    }
    return $products;
  }

  public function filter_stores_by_location($searchTerm, $userLat, $userLng, $radius)
  {
    $base_url = base_url();
    $builder = $this->db->table('store AS S ');

    $builder->join('store_category AS SC ', 'S.storeCatId = SC.uId', 'LEFT');
    $builder->select([
      'S.uId AS storeId',
      'S.name AS storeName',
      'S.address',
      "CONCAT('$base_url'  ,  S.logoUrl) AS StoreLogo",
      'SC.categoryName AS CategoryName',
      "(
              ROUND(
                  6371 * 
                  acos(
                      cos(radians($userLat)) * 
                      cos(radians(S.latitude)) * 
                      cos(radians(S.longitude) - radians($userLng)) + 
                      sin(radians($userLat)) * 
                      sin(radians(S.latitude))
                  ), 
                  2
              )
          ) AS distance"
    ]);
    $builder->like('S.address', $searchTerm, 'both');
    $builder->having('distance <=', $radius);
    $builder->orderBy('distance', 'ASC');

    $query = $builder->get();
    return $query->getResult();
  }
}
